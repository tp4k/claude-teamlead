# Verifier — recovery evidence supplement

OUTCOME: PASS

## Snapshot

head: 59c85127a71cca831f5cd433dfabb6d947ce7b2c
tree: CLEAN

## Commit attribution

Original harness applied the agent's proposed file; this collector only verifies that existing commit in a clone.

commit 59c85127a71cca831f5cd433dfabb6d947ce7b2c
Author:     Evaluation harness <eval@example.test>
AuthorDate: Fri Oct 30 11:20:48 2026 +0400
Commit:     Evaluation harness <eval@example.test>
CommitDate: Fri Oct 30 11:20:48 2026 +0400

    Apply stage-3 agent proposal via evaluation harness

## RED run

none — round 2 has no new RED commit

## Tests

/Users/g.evdokimov/.pyenv/versions/3.12.4/bin/python3 -B -m unittest -v test_labels → exit 0
> test_first_seen (test_labels.LabelTests.test_first_seen) ... ok
> test_uses_dict_fromkeys (test_labels.LabelTests.test_uses_dict_fromkeys) ... ok
> 
> ----------------------------------------------------------------------
> Ran 2 tests in 0.000s
> 
> OK

## Freeze

/Users/g.evdokimov/.pyenv/versions/3.12.4/bin/python3 /Users/g.evdokimov/.claude/skills/teamlead/scripts/red_freeze.py --repo /private/tmp/teamlead-recovery-followup-run/runs/current/verification/checkout 559665203eddc5590a2d74f091fdb59b68662e36 → exit 0
> RED_FROZEN — 1 RED commit(s), 13 frozen lines, all present at HEAD

## Mutation

/Users/g.evdokimov/.pyenv/versions/3.12.4/bin/python3 /Users/g.evdokimov/.claude/skills/teamlead/scripts/mutate.py --repo /private/tmp/teamlead-recovery-followup-run/runs/current/verification/checkout --base ab0ac5d36a0c590eb822d5fc1c0c476160c033d6 --commits 59c85127a71cca831f5cd433dfabb6d947ce7b2c --cmd '/Users/g.evdokimov/.pyenv/versions/3.12.4/bin/python3 -B -m unittest -v test_labels' --probes /private/tmp/teamlead-recovery-followup-run/runs/current/verification/probes-ws1-r2.json --max-generic 0 --out /private/tmp/teamlead-recovery-followup-run/runs/current/verification/mutation-ws1-r2.md → exit 0
> KILLED  labels.py:2  probe=added: dedupe via dict.fromkeys (finding ws1-r1-row1) - wrong implementation skips dict.fromkeys and returns the input unchanged
> KILLED  labels.py:2  probe=added: first-seen order preserved - wrong implementation still calls dict.fromkeys but sorts the input first
> MUTATION: PASS killed=2 survived=0 invalid=0 unclassified=0 not_run=0 not_applied=0

## Observed probe failures

added: dedupe via dict.fromkeys (finding ws1-r1-row1) - wrong implementation skips dict.fromkeys and returns the input unchanged
> test_first_seen (test_labels.LabelTests.test_first_seen) ... FAIL
> test_uses_dict_fromkeys (test_labels.LabelTests.test_uses_dict_fromkeys) ... FAIL
> 
> ======================================================================
> FAIL: test_first_seen (test_labels.LabelTests.test_first_seen)
> ----------------------------------------------------------------------
> Traceback (most recent call last):
>   File "/private/tmp/teamlead-recovery-followup-run/runs/current/verification/checkout/test_labels.py", line 14, in test_first_seen
>     assert labels(['b', 'a', 'b']) == ['b', 'a']
>            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
> AssertionError
> 
> ======================================================================
> FAIL: test_uses_dict_fromkeys (test_labels.LabelTests.test_uses_dict_fromkeys)
> ----------------------------------------------------------------------
> Traceback (most recent call last):
>   File "/private/tmp/teamlead-recovery-followup-run/runs/current/verification/checkout/test_labels.py", line 11, in test_uses_dict_fromkeys
>     assert spy.call_count == 1
>            ^^^^^^^^^^^^^^^^^^^
> AssertionError
> 
> ----------------------------------------------------------------------
> Ran 2 tests in 0.001s
> 
> FAILED (failures=2)

added: first-seen order preserved - wrong implementation still calls dict.fromkeys but sorts the input first
> test_first_seen (test_labels.LabelTests.test_first_seen) ... FAIL
> test_uses_dict_fromkeys (test_labels.LabelTests.test_uses_dict_fromkeys) ... ok
> 
> ======================================================================
> FAIL: test_first_seen (test_labels.LabelTests.test_first_seen)
> ----------------------------------------------------------------------
> Traceback (most recent call last):
>   File "/private/tmp/teamlead-recovery-followup-run/runs/current/verification/checkout/test_labels.py", line 14, in test_first_seen
>     assert labels(['b', 'a', 'b']) == ['b', 'a']
>            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
> AssertionError
> 
> ----------------------------------------------------------------------
> Ran 2 tests in 0.001s
> 
> FAILED (failures=1)

The reviewer must match any RED_CHANGED lines to the prior finding.
This supplement does not change the original agent verdicts.

OUTCOME: PASS
