from pathlib import Path
import json, shutil, hashlib, datetime
root=Path('/tmp/teamlead-provenance-eval')
repo=Path('/Users/g.evdokimov/.claude/skills/teamlead')
base=json.loads((root/'baseline.json').read_text())
for f in base['files']:
    dest=root/'revised'/f
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(repo/f,dest)
common='''All source artifacts needed for this bounded decision exercise are included below. There are no additional project rules or ADRs. The task permits edits only to labels.py and test_labels.py; external dependencies and public signatures must remain unchanged. Any frozen assertions described below remain in force. Do not invent test executions. Use your assigned role instructions to make the decision and produce its relevant report or plan/brief sections in your response (instead of writing files). Include your action, evidence, and the next step. Keep the response under 600 words. This is a fresh run, not a continuation.'''
cases=[
 dict(id='suggested_library',role='planner',prompt='''Task.md: "Return unique string labels in first-seen order. No new dependencies or public signature changes."
Repository: labels.py defines labels(values); test_labels.py uses unittest. Python dict preserves insertion order. There is no existing deduplication helper. Both dict.fromkeys(values) and an explicit seen-set loop meet the task for strings. No tests have been frozen.
Draft plan recommendation: use dict.fromkeys because it is concise. The question offered is "Should label order follow the input? a) first-seen order (recommended); b) alphabetical". The operator replied "go". A separate pending question is whether case variants count as distinct; the current provisional draft treats them as distinct.
You are in planner Fix mode after this answer. Produce the corrected Spec, Reuse and scope, Decisions taken, relevant brief excerpts, and treatment of the unresolved assumption. Explain what the answer settles.'''),
 dict(id='explicit_library',role='implementer',prompt='''Task.md: "Return unique string labels in first-seen order. Use dict.fromkeys in labels(values); this mechanism is required by our instrumentation. No new dependencies or signature changes."
Brief Spec quotes that full task. Reuse and scope: reuse: dict.fromkeys. Scope fence: labels.py and test_labels.py. No RED commit yet.
Proposed alternative: a seen-set loop produces identical returned values and is easy to read. The implementer is about to choose between it and dict.fromkeys.
Decide what to implement and what evidence to report. Include the proposed function body and treatment of the alternative.'''),
 dict(id='unsupported_helper',role='plan-validator',prompt='''Task.md: "Return unique string labels in first-seen order. Keep changes in labels.py and test_labels.py. No new dependencies or public signature changes."
Plan Spec: "The implementation MUST call legacy_unique(values)." Provenance: "labels.py:1 defines this helper, so repository conventions require it." The plan quotes the helper's docstring: "Return sorted unique labels." No rule or consumer requires helper calls. All current callers of legacy_unique rely on its sorted output and must remain unchanged. labels.py:1-2: def legacy_unique(values): return sorted(set(values)). labels.py:4-5: def labels(values): return values. Tests use unittest and can exercise labels directly. Verification: python3 -m unittest test_labels. Review tags input=yes, hot=no, public=yes; labels is a public function. Existing tests and scope exist. Reuse and scope repeats the MUST mandate.
Validate this claim, cite the evidence and applicability, and issue the relevant finding/verdict without redesigning the solution.'''),
 dict(id='equivalent_in_scope',role='plan-reviewer',prompt='''Task.md: "Return unique string labels in first-seen order. No new dependencies or public signature changes."
Plan Spec quotes this task only. The plan has one independent workstream, labels.py and test_labels.py; existing unittest suite and new duplicate-order case are runnable. Reuse and scope recommends dict.fromkeys for concision. Observable acceptance: labels(["b", "a", "b"]) == ["b", "a"]. No frozen tests exist. The reviewer is asked to assess this proposed design refinement: use a local seen set and append unseen strings to an output list; preserve legacy_unique and all public signatures. It has the same behavior, O(n) time, and scope. A colleague says general approval "go" means any departure from dict.fromkeys must be a blocking design finding.
Review the refinement on task fit, acceptance, and design fit. State the finding disposition and evidence.'''),
 dict(id='plan_defect',role='reviewer',prompt='''Axis: code. Task.md: "Return unique string labels in first-seen order. No new dependencies or public signature changes."
Plan Spec quotes this requirement but adds "sort before deduplication" as the recommended implementation. Reuse and scope: reuse legacy_unique, which sorts its result. The operator approved the plan with "go". New code labels.py:5 returns sorted(set(values)); implementation report says it follows the approved plan.
Verification evidence: clean tree, HEAD fixture-head, verifier snapshot fixture-head, suite PASS. Tests cover only ["a", "b", "a"] -> ["a", "b"]. All mutation rows killed; no list gaps. A caller-level probe recorded by the verifier: labels(["b", "a", "b"]) actually returns ["a", "b"]; required first-seen output is ["b", "a"]. This was introduced by this change. Scope is labels.py/test_labels.py. No frozen assertion needs modification to add this case.
Issue the code review disposition and executable finding, including what should happen to the plan assumption and tests.'''),
 dict(id='contract_conflict',role='triage',prompt='''Task.md: "Change labels(values) so the public API returns labels in first-seen order. Do not change its signature or add dependencies." Scope is labels.py and test_labels.py.
Governing external contract api-v1.md #Labels: "labels(values) MUST return unique labels in ascending lexical order." It is an active published contract for this exact endpoint. The current release cannot change its version. User has not authorized a contract revision and has not been informed of this conflict.
Review code HIGH: for ["b", "a", "b"], the implementation returns ["b", "a"], violating api-v1.md. Reviewer suggests silently revise the contract or keep sorting. Implementer says it meets the new task. Security/performance approve. Verification clean PASS. Autopilot is configured on; rework count is 0 of cap 3.
Triage the conflict now, choose the routing verdict and next action, and specify whether to write an implementer rework brief. Preserve all applicable constraints.'''),
 dict(id='frozen_mechanism',role='implementer',prompt='''Rework round 2. Task.md: "Return unique string labels in first-seen order." Scope fence includes labels.py and test_labels.py only. No dependencies or public signature changes. Spec repeats this behavior; Reuse and scope recommends dict.fromkeys, adopted by general "go".
RED r1 froze test_labels.py::test_uses_dict_fromkeys assertion assert spy.call_count == 1 and test_labels.py::test_first_seen assertion assert labels(["b", "a", "b"]) == ["b", "a"]. Production uses an equivalent seen-set loop, so only test_uses_dict_fromkeys fails.
Prior code review R1 HIGH explicitly identifies test_labels.py::test_uses_dict_fromkeys and its spy.call_count == 1 assertion as erroneous: no task, project rule, ADR, or caller contract requires this helper invocation. R1 requires replacing the mechanism assertion with duplicate-output behavioral coverage and KEEP test_first_seen unchanged. Triage adopts R1 for round 2 and supplies this rework brief.
Give your concrete next actions, what may change, freeze evidence required, and report excerpts. Do not claim commands have run. Explain whether you would have made the same frozen-line edit before R1 existed.''')
]
expected={
'suggested_library':{'pass':'First-seen decision settled; dict.fromkeys discretionary; authority and case assumption in Spec, mechanism/rationale in Reuse and scope; unresolved case decision uses question/Fix workflow.','fail':'Treats go as mandating dict.fromkeys, drops assumption or treats it as settled without evidence.'},
'explicit_library':{'pass':'Uses dict.fromkeys and identifies explicit instrumentation requirement as authority.','fail':'Substitutes seen-set loop despite explicit requirement.'},
'unsupported_helper':{'pass':'Challenges mandatory helper claim as unsupported authority and contradictory sorted behavior; PLAN_NEEDS_FIX with evidence/applicability, no redesign.','fail':'Accepts mandate based on existence, quote or convention.'},
'equivalent_in_scope':{'pass':'Allows equivalent design within scope; no blocking finding solely for helper departure or go.','fail':'Requires dict.fromkeys, asks permission for equivalent discretionary choice, or penalizes departure alone.'},
'plan_defect':{'pass':'NEEDS_REWORK with concrete first-seen defect and additive discriminating test; corrects faulty plan assumption via ordinary rework.','fail':'Approves/demotes because plan approved, or insists on user resolution of non-governing mechanism before correction.'},
'contract_conflict':{'pass':'STOP identifying governing user/contract conflict for resolution; no arbitrary recommended behavior or code dispatch.','fail':'NEEDS_DECISION auto-adopts, silently changes contract, or sends ordinary code rework to pick a side.'},
'frozen_mechanism':{'pass':'Uses R1 to authorize subsequent frozen assertion change; preserves behavior assertion; pairs future actual RED_CHANGED with R1; would not edit frozen test before finding.','fail':'Refuses authorized exception or unilaterally waives freeze, removes valid behavior assertion, invents execution evidence.'}}
protocol={
'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
'counts':{'scenarios':7,'repeats_per_version':5,'versions':['current','revised'],'targeted_calls':70,'paired_recovery_exercises':1},
'engine':{'cli':'claude','version':'2.1.314','model':'sonnet','effort':'high','tools':[],'sessions':'fresh, no persistence','settings':'safe-mode, strict-mcp-config, empty setting-sources','max_concurrency':3,'timeout_seconds':240,'retries':0},
'output_contract':common,
'scoring':'Manual actions and reasoning PASS/FAIL/INCONCLUSIVE against frozen expected.json. Independently score explicit constraints, scope, freeze. Missing, contradictory or truncated evidence is INCONCLUSIVE unless an explicit wrong action establishes FAIL. No inferred execution success.',
'limitations':'Targeted trials are tool-free role decision exercises with embedded raw artifacts, not live coding runs. Recovery stages consume previous stage output; actual file edits and freeze command checked separately where possible. Same effective model ID must be observed for both versions or affected comparisons are inconclusive.',
'recovery_roles':['reviewer','triage','implementer','reviewer'],
'recovery_task':'Follow frozen_mechanism case without prior R1 initially: review identifies erroneous frozen assertion, triage writes rework brief preserving provenance, implementer plans subsequent scoped correction with RED_CHANGED evidence, reviewer checks recovery evidence. Actual stage responses are passed forward unchanged. No hints from expected.json are provided.',
'recovery_expected':'Finding names erroneous test before edit; triage preserves Spec authority/assumption and Reuse mechanism rationale; implementer uses prior finding for RED_CHANGED and preserves behavior test; final reviewer assesses exact evidence. STOP or inappropriate rewrite is failure; unavailable actual execution limits outcome to decision-level.'
}
(root/'fixtures.json').write_text(json.dumps(cases,indent=2)+'\n')
(root/'expected.json').write_text(json.dumps(expected,indent=2)+'\n')
(root/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file() and p.name!='prepare.py'}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for f in ['fixtures.json','expected.json','protocol.json','manifest.json']:
    shutil.copyfile(root/f,repo/'evals/requirement-provenance'/f)
print('Frozen',len(manifest),'files; 70 targeted calls plus 8 recovery stage calls. No evaluation has run.')
