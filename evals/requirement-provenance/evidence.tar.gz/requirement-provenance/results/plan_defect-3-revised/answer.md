# Code review, round 1 (axis: code)

I did not run any commands or write a report file. This review rests on the supplied artifacts only.

**Verdict: NEEDS_REWORK**

**Coverage:** Task.md requires unique labels in first-seen order. That requirement is violated at `labels.py:5` (finding 1). The no-new-dependencies and no-signature-change constraints hold.

## Probes

`list: n/a brief + 0 added; off-list clauses: 1; LIST_GAP: 1`

- Criterion "output in first-seen order" `[off-list]` → no mutation row exists for it → NOT PROBED. Every reported row was killed, but none pins ordering. A realistic wrong implementation, the shipped `sorted(set(values))`, passes every test. The only test input is `["a","b","a"]`, which is already in sorted order. I cannot cite a `file::test_name` here without inventing one. Name the existing test covering that input when fixing.
- The verifier's caller-level probe shows `labels(["b","a","b"])` returns `["a","b"]` where `["b","a"]` is required. I treat that as observed proof.

## Findings

| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| HIGH | `labels.py:5` | task.md: "unique string labels in first-seen order" | `sorted(set(values))` returns sorted order, so `["b","a","b"]` yields `["a","b"]`. This regression is introduced by this change. → Replace the body at line 5 with an order-preserving dedup, e.g. `return list(dict.fromkeys(values))`. This adds no dependency and leaves the signature unchanged. Do not call `legacy_unique`, because it sorts. KEEP the public signature and the existing `["a","b","a"] -> ["a","b"]` assertion. |
| HIGH | `test_labels.py` | Observable acceptance (1b) and test plan | No test distinguishes first-seen order from sorted order. → ADD a RED commit containing only tests, before the production fix, with `assert labels(["b","a","b"]) == ["b","a"]`. Optionally add a case with interleaved, non-sorted first appearances, e.g. `["c","a","c","b","a"] -> ["c","a","b"]`. KEEP all existing assertions untouched. The diff should be additions only. The new test must fail against the current `sorted(set(...))` code, and the verifier should record that failure in `## RED run`. |
| MEDIUM | `$RUN/probes-ws<N>-r<M>.json` | `LIST_GAP`: ordering clause has no probe | → ADD a probe with intent "output preserves first-seen order". Its patch replaces the dedup expression with `sorted(set(values))`. It must be killed by the new ordering test. |

## Plan assumption and disposition

- **Plan's "sort before deduplication" and reuse of `legacy_unique`:** These are discretionary mechanisms, and they contradict the user's explicit requirement in task.md. The operator's "go" adopted the plan but did not give the recommendation authority over task.md. Plan conformance does not excuse an observable defect.
- **Plan correction:** Triage should record the Spec assumption as faulty and superseded. The plan's Spec should drop the sort and `legacy_unique` guidance and state first-seen order as the controlling behavior. The implementer should not treat the old text as binding.
- **Not a STOP:** There is no unresolved conflict among governing requirements. The fix is in scope (`labels.py` and `test_labels.py` only), and no external dependency or public signature change is needed.
- **Frozen assertions:** None need modification. The existing `["a","b","a"]` assertion stays as is, so there is no `RED_CHANGED` concern. The new test is additive.

## Notes

- `dict.fromkeys` requires hashable items, the same constraint as `set`. Behavior for unhashable input is unchanged.

## Verification

per verifier-r1: PASS. Clean tree, HEAD `fixture-head` matching the snapshot. The suite PASS is accepted as suite evidence but does not cover ordering, so it does not exonerate finding 1. No commands of my own were run.

## Next step

Send the findings to the implementer. They add the tests-only RED commit first, then the one-line `dict.fromkeys` fix, then the added probe. Request fresh verification, and have triage amend the plan's Spec assumption.

```
VERDICT: NEEDS_REWORK rows=3 notes=1
file: not written (exercise requested response-text output)
```