# Review report: code axis, round 1

**Verdict: NEEDS_REWORK**

**Coverage:** I checked the unique, first-seen requirement and the scope limit (`labels.py` and `test_labels.py` only). The `labels(values)` signature is unchanged and no dependencies were added. The only failure is in the table below. I did not run any commands, and the supplied artifacts are not a git checkout, so `git show --stat` on the RED commit was not possible.

## Probes
list: 0 brief + 0 added; off-list clauses: 1; LIST_GAP: 0

- Duplicate-skip guard (`if value not in seen`, `labels.py:5`) → NOT PROBED: the verifier skipped the mutation gate ("Not executed") and no probes file was supplied.

I cannot grade probes without a mutation report.

## Findings

| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| HIGH | `labels.py:1-8` | Frozen RED test `test_uses_dict_fromkeys` (`test_labels.py:11`) and the brief's `reuse: dict.fromkeys` | The implementation uses a manual `set` loop and never calls `dict.fromkeys`. The verifier ran the suite at HEAD `89678d9…` and got exit 1 (`.F`): `spy.call_count == 1` fails. GREEN is not reached. The RED lines are frozen (`RED_FROZEN`, 13 lines) and no finding authorizes changing them. → In `labels.py` only, replace the body with `return list(dict.fromkeys(values))` and keep the `def labels(values):` signature. Do not edit `test_labels.py`. KEEP both tests, including `test_first_seen` (`== ['b', 'a']`) and the `spy.call_count == 1` assertion. |
| MEDIUM | verifier evidence (`tree`, `mutation`) | Code-axis evidence requirement | The verifier recorded `tree: ""`, not `CLEAN`. I cannot confirm that HEAD `89678d9…` matches the shared HEAD or that the tree was empty under `git status --porcelain=v1 --untracked-files=all`. The mutation gate also did not run because the suite failed. → After the fix above, request fresh verification. It must record `tree: CLEAN` and the HEAD SHA, include `## RED run`, and run the mutation gate. The probes file must cover the `dict.fromkeys` call and first-seen order. |

## Notes
- `test_uses_dict_fromkeys` pins an implementation mechanism. `task.md` requires only unique labels in first-seen order. The brief calls `dict.fromkeys` "recommended" ("keep because" cites `task.md`, which does not mandate it). I am not asking to weaken it, because a frozen assertion can only change through an authorizing finding. The coordinator may decide separately whether to relax it.
- No test covers empty input or an input with no duplicates. I am not filing a finding: `list(dict.fromkeys(...))` handles both, and the spec does not call them out. Non-string inputs are explicitly out of scope.

## Verification
per verifier report: FAIL. `python3 -B -m unittest test_labels` exited 1, with `test_uses_dict_fromkeys` failing. The freeze check passed (`RED_FROZEN`). The RED run shows an individual failure for each new test (`FF`).

## Next action
The implementer makes the one-line `labels.py` change. The verifier then reruns RED, the suite, the freeze check and mutation with clean-tree evidence. Round-2 review will cover only these findings and the lines changed by that commit.

```
VERDICT: NEEDS_REWORK rows=2 notes=2
file: not written (exercise requested an inline report)
```