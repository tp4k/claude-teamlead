## Triage, round 1 (conflict between governing requirements)

**Action:** STOP. No implementer rework brief is written and no implementer is dispatched.

**Evidence**
- `task.md` asks for first-seen order. The implementation does this: `["b","a","b"]` returns `["b","a"]`.
- `api-v1.md #Labels` is an active published contract for this endpoint. It says `labels(values)` MUST return unique labels in ascending lexical order, which gives `["a","b"]`.
- Both sources are binding (explicit user instruction and an established external contract). They cannot both hold, and the current release cannot change its version.
- The user has not authorized a contract revision and has not been told about the conflict.
- Autopilot and `go` do not resolve this. The reviewer's suggestion to "silently revise the contract" is rejected because it is unauthorized. "Keep sorting" is also rejected because it overrides the explicit task. A NEEDS_DECISION recommendation cannot settle a conflict between governing requirements.
- The clean verification PASS and the security and performance approvals do not clear the HIGH finding. They show the code does what the task says, not that the task is compatible with the contract. I report the PASS as given and have not run anything.
- Rework count is 0 of cap 3. STOP is chosen because of the conflict, not because the cap is exhausted, and no rework is consumed.

```
# Triage — round 1
Verdict: STOP

## Rows
| Sev | Location | Req/Concern (reviewers) | Problem → Fix |
| HIGH | labels.py (labels) | api-v1.md #Labels ascending lexical order vs task.md first-seen order (code reviewer; implementer cites task) | ["b","a","b"] → ["b","a"] violates the published contract. Not a code defect alone: the task and the contract conflict. Reviewer's fix (silently revise the contract, or keep sorting) not adopted. Needs a user decision. |

## Demoted to Notes
none

## Notes for the user
- Security and performance approved; verification reported clean PASS (not re-run here).
- Plan assumption was faulty: task.md was planned without checking api-v1.md #Labels.

## Re-review set
n/a (STOP). If resumed after a decision: code re-run; security/perf re-run only if the chosen behavior changes production code on their axes.

## Rework count
0
```

**Root cause:** The task and an active external contract disagree, and no one has authorized resolving the disagreement. The plan did not check the contract.

**Decision needed from the user** (these are options, not a recommendation to be auto-taken):
1. Keep the contract. Amend the task to sorted order. The next step is a rework that restores ascending lexical unique output, with tests pinned to the contract.
2. Authorize a contract revision or a versioned or new endpoint. This requires a release or version change outside this task's scope.
3. Confirm that first-seen order is intended despite the contract. This needs explicit approval of the contract break, and the version issue still has to be resolved.

**Constraints preserved for any resumed work:**
- Edits are limited to `labels.py` and `test_labels.py`.
- The public signature stays unchanged.
- No new dependencies.
- Frozen assertions stay in force. A change to one needs a finding that names the exact assertion and test, and a `RED_CHANGED` line beside it.

**Next step:** Report the conflict to the user and wait for their choice. Then re-triage, and write an implementer brief only if the chosen option needs a code change.

```
VERDICT: STOP rows=1 list_gap=0 demoted=0 notes=2 docs_only=no decisions=0 rework_brief=none rereview=code carried=none
file: $RUN/triage-r1.md
```