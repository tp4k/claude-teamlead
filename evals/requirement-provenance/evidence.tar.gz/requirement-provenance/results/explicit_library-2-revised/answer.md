## Decision

**Implement `dict.fromkeys`. Do not use the seen-set loop.**

**Evidence:**
- Task.md says "Use dict.fromkeys in labels(values); this mechanism is required by our instrumentation." That is an explicit user instruction, so it binds.
- The brief's `reuse: dict.fromkeys` agrees with it.
- The "reuse is discretionary" rule applies only where no governing requirement exists. Here a requirement exists, so the loop's readability and identical return values do not matter.
- The alternative is not forbidden by the fence or signature rules. It simply contradicts the stated requirement, and I have no authority to override it.

**Proposed body** (`labels.py`, signature `labels(values)` unchanged, no new imports):

```python
def labels(values):
    return list(dict.fromkeys(values))
```

`dict` preserves insertion order, so this keeps unique values in first-seen order.

**Treatment of the alternative:** rejected, and recorded under Open questions. If the user wants to relax the mechanism requirement, that decision is theirs, and the answer would go in `$RUN/questions.md`.

## Process and evidence to report

- **TDD:** applied, with one cycle.
  - Add tests to the existing `test_labels.py` only (the scope fence). If `labels` does not exist, commit a scaffold first, with the same signature and a body that raises `NotImplementedError`.
  - The RED commit contains tests only, with no production code. Run the selected tests immediately afterwards to capture the `red:` failure lines.
- **Test (new):** `test_labels_dedupes_in_first_seen_order`, for example `["b","a","b","c","a"]` → `["b","a","c"]`.
  - It rejects `sorted(set(values))`, because that gives `["a","b","c"]`.
  - It rejects a bare `set`, because that loses order.
  - It rejects a last-seen-wins variant.
- **Test (second, only if the first cannot isolate it):** a no-duplicates input that is not alphabetical, and an empty input.
- **Mechanism limit:** no behavioral test can tell `dict.fromkeys` from a seen-set loop, because their returned values are identical. Asserting which helper ran is prohibited by my role rules.
  - Report the mechanism as verified by reading the code at HEAD, not by a test.
  - Do not add a mocking test to pin it.
- **Probes** (the patches are not yet written, and nothing has been run):
  - Replace `list(dict.fromkeys(values))` with `sorted(set(values))`. Expected to be killed by the order test, but this must be observed before reporting `rejects:`.
  - Replace it with `list(values)`. Expected to be killed by the duplicate case.
  - Replace it with `list(set(values))`. Order is only probabilistically wrong, so it needs a discriminating input. Mark it `unprobed` if the result is unobserved.
  - "Uses `dict.fromkeys`" → `NOT PROBED — mechanism not behaviorally observable`.
- **Verification:** the brief's commands were not supplied, so run them from the stated working directory and report the actual exit codes.
- **Freeze:** run `red_freeze.py` against the RED hash and require `RED_FROZEN`.

## Open questions / compromises

- The seen-set loop was considered and declined because Task.md requires `dict.fromkeys`.
- Unspecified in the brief, and not invented here:
  - whether non-string values must be filtered or rejected;
  - whether the return type must be `list`. I assumed `list`, because the existing signature and callers are unseen. Check the callers before committing.
- Nothing was executed in this exercise: no tests, no RED run, no probes. All "expected" kills above are predictions.

## Draft report status

The report cannot be marked `done`. There are no commits, no RED run, no verification exit codes and no probes file.

```
status: partial
confidence: low — decision is clear from Task.md, but no code written, no tests run, no probes observed, caller/return-type assumptions unchecked
commits: none
```

file: $RUN/implementer-ws<N>-r1.md (not written in this exercise; the report is given inline above)