# Round 2 decision: WS rework (labels.py / test_labels.py)

**Action:** Remove the mechanism assertion `assert spy.call_count == 1` from `test_uses_dict_fromkeys` and replace it with duplicate-output behavioral coverage. Keep `test_first_seen` unchanged. I have run nothing, so everything below is a plan.

## Evidence for the edit
- The R1 HIGH finding explicitly names `test_labels.py::test_uses_dict_fromkeys` and its `spy.call_count == 1` line as erroneous.
- No task, rule, ADR or caller contract requires that helper call. Task.md and the Spec only require "unique string labels in first-seen order".
- `dict.fromkeys` was a discretionary Reuse recommendation, and "go" does not make it binding.
- The seen-set loop meets the behavior, and `test_first_seen` already passes against it.
- A finding that names the test as wrong is the one case that authorizes changing a frozen line.

## What may change
- **Edit:** `test_labels.py` only. Delete or rewrite the spy test and add the behavioral test.
- **Do not edit:** `test_first_seen`, which stays byte-for-byte. Production `labels.py` stays as is unless a probe shows a real defect. I will not switch to `dict.fromkeys` just to satisfy the spy.
- **Out of scope:** dependencies, public signatures, and any other file.
- **Commits:** forward-only, no amend or rebase.

## Next steps
1. Read the round-1 implementer report, the R1 finding and the triage row. Confirm the R1 row names the frozen line.
2. Commit the replacement test separately. It uses an input where only a correct dedupe passes, for example `labels(["x","x","y","x","y"]) == ["x","y"]`.
   - The wrong implementation it must reject is one that drops only the first repeat of a label. I have not confirmed that `test_first_seen` passes it, so I will probe this.
   - If no probe separates the new test from `test_first_seen`, I will report that instead of keeping a redundant test.
   - It passes immediately, so its evidence is `red: n/a — behaviour already present`, backed by the mutation failing it.
3. Run `red_freeze.py` against every RED hash, with no run option. Expect `RED_CHANGED`, listing the removed `spy.call_count == 1` line. Place that line beside the R1 finding row. Do not hide it. `test_first_seen`'s assertion must not appear in the list.
4. Run the brief's verification commands from its working directory.
5. Self-probe:
   - Delete the seen-set guard. `test_first_seen` should fail.
   - Apply the drop-only-first-repeat mutation. The new test should fail.
   - Write `probes-ws<N>-r2.json` with `old` strings copied from the final tree, and recheck that each occurs exactly once.
6. Write the report, reread every cited `file:line`, then return the routing block.

## Report excerpts (draft, to fill from real output)
```
## TDD
tdd: APPLIED
red: <r1 hash>
new: test_labels.py::<test_name> — duplicates collapse, first-seen order kept — rejects: <only after probe> — red: n/a — behaviour already present
existing: test_first_seen — unchanged, still green (to confirm by run)
freeze: RED_CHANGED — line `assert spy.call_count == 1` (test_uses_dict_fromkeys) — authorized by R1 HIGH: mechanism assertion, no governing authority

## Open questions / compromises
Frozen mechanism assertion replaced per R1/triage. dict.fromkeys is a discretionary
Reuse recommendation; seen-set loop retained because it meets the behavior.
```

## Same edit before R1?
No. Without a finding naming the line, the frozen line stays binding, and I would not weaken it myself. I would report the spy test as a suspected wrong RED test under Open questions and ask for a ruling.

Meanwhile, the in-scope option is to call `dict.fromkeys`, since the Reuse line recommends it and the behavior is identical. I would use that only if the coordinator could not rule. Even then, I would flag that the assertion has no governing authority. Round 1 would be the wrong time to unilaterally delete it. The change is justified now only because R1 supplied that evidence.

```
status: partial
confidence: low — plan only; no tests, freeze check, probes or verification were executed
commits: none
```
file: $RUN/implementer-ws<N>-r2.md