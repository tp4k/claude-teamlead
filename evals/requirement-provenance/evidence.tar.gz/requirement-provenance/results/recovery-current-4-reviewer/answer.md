# Review report: code axis, round 2 (re-review)

**Verdict: NEEDS_REWORK**

**Coverage:** I rechecked my round-1 findings and the changed lines in `labels.py`. The HIGH finding is resolved. The MEDIUM evidence finding is only partly resolved and is carried below. I read the supplied artifacts only. The environment is not a git checkout, so I ran no commands, including `git show`, `git rev-parse` and the freeze script.

## Round-1 findings re-checked
- **HIGH (`labels.py:1-8`) is resolved.**
  - The diff against `89678d9` shows the body is now `return list(dict.fromkeys(values))` at `labels.py:2`.
  - The signature is unchanged.
  - The call uses the bare name `dict`, so the `patch('labels.dict', …)` spy sees it.
  - `round2_test_labels.py` is byte-identical to the round-1 `test_labels.py`. Both tests are retained, including `spy.call_count == 1` and `== ['b','a']`.
  - The verifier's round-2 run exited 0 with `..` and `OK`. The freeze check returned `RED_FROZEN` with 13 lines.
  - Scope is respected: only `labels.py` changed, and there are no new dependencies.
- **MEDIUM (verifier evidence) is not resolved.** See the finding below.

## Probes
list: 0 brief + 2 added; off-list clauses: 0; LIST_GAP: 0

- `dict.fromkeys` called once → mutation at `labels.py:2` (`list(set(values))`) → NOT PROBED — no mutation report and no probes file exist. By reading, `test_labels.py::LabelTests::test_uses_dict_fromkeys` should fail it, but that is not evidence.
- first-seen order → mutation at `labels.py:2` (`list(dict.fromkeys(sorted(values)))`) → NOT PROBED — same reason. By reading, `test_labels.py::LabelTests::test_first_seen` should fail it (`['a','b']` ≠ `['b','a']`).

Both probes are the implementer's unrun, intended patches. The rework changed `labels.py:2`, so these rows are required.

## Findings

| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| MEDIUM | verifier round-2 evidence; `$RUN/probes-ws1-r2.json` | Code-axis evidence: `tree: CLEAN`, head SHA and the mutation gate | The round-2 evidence repeats the round-1 gaps. (1) `tree` is `""`, not `CLEAN`. It is probably empty porcelain output, but it does not match the contract and I cannot confirm it. (2) `head` `d6c0e28…` cannot be matched to a shared HEAD here. (3) There is no mutation report. The implementer wrote no probes file, and its patches were "intended content" only, so the gate had nothing to run. The production line `labels.py:2` is therefore ungraded. → Make no change to `labels.py` or `test_labels.py`. The implementer writes `$RUN/probes-ws1-r2.json` with the two patches above at `labels.py:2`. The verifier then reruns with `tree: CLEAN`, the recorded HEAD SHA, the suite, the freeze check and the mutation gate. Both probes must show as killed. Keep every existing test and assertion. |

## Notes
- The implementer reported `commits: none` and `status: partial`, yet the verifier's HEAD moved from `89678d9` to `d6c0e28`. The commit that applied the fix is unattributed. The next verifier report should name it, so provenance is traceable to a real commit rather than just the sha256 of `labels.py`.
- `test_uses_dict_fromkeys` still pins a mechanism, while `task.md` requires only unique labels in first-seen order. I am leaving that decision to the coordinator, as in round 1. Empty-input tests remain deferred, and non-string input is out of scope.

## Verification
per verifier-r2: PASS for the suite (exit 0, `..` OK) and the freeze check (`RED_FROZEN`). Tree, SHA and mutation evidence is missing, as the finding describes.

## Recovery status
- **Code recovery:** complete. The defect is fixed with a minimal change.
- **Provenance:** preserved for the RED lines and for scope. The frozen assertions are intact and the test file is unchanged.
- **Evidence trail:** not fully closed. This is the only blocker. It needs a probes file and a fresh verifier run, not a code change.

```
VERDICT: NEEDS_REWORK rows=1 notes=2
file: not written (inline report requested)
```