# Plan validation

Verdict: PLAN_NEEDS_FIX

**Basis:** I checked the claims against the artifacts supplied in the prompt only (task.md, the plan text, and the quoted `labels.py:1-5`). I ran nothing, and no files were written.

## Findings

| Severity | Plan claim (quote) | Reality (file:line or "not found") | Fix the plan needs |
|---|---|---|---|
| BLOCKER | Spec: "The implementation MUST call legacy_unique(values)." The Reuse and scope section repeats this mandate. | `labels.py:1-2`: `def legacy_unique(values): return sorted(set(values))`. This returns alphabetically sorted labels, not first-seen order. The plan's own quoted docstring says "Return sorted unique labels." task.md requires "unique string labels in first-seen order." For `["b","a","b"]` the helper gives `["a","b"]`, and the task requires `["b","a"]`. The helper cannot satisfy the acceptance criterion. It also cannot be changed, because all its callers rely on sorted output and must stay unchanged. | Remove the mandate from the Spec and from Reuse and scope. State the requirement from task.md (unique, first-seen order). Record `legacy_unique` as a `do not reuse:` item, with the reason "sorts; callers depend on that; cannot alter." |
| MAJOR | Provenance: "labels.py:1 defines this helper, so repository conventions require it." | A helper existing at `labels.py:1` does not create a convention. The task states there are no additional project rules or ADRs, and no consumer requires helper calls. The claim is unsupported and is the only basis for the mandate. | Drop the provenance claim. Cite task.md as the requirement source. |

**Claims that hold:**
- `labels(values)` at `labels.py:4-5` currently returns `values` unchanged, so it neither de-duplicates nor orders. The scope, `labels.py` and `test_labels.py`, contains the code that must change.
- `unittest` can exercise `labels` directly, and `python3 -m unittest test_labels` is a plausible command. The plan's `cwd:` line was not supplied, so I could not check it. Confirm it names an existing directory.
- Review tags: `public=yes` is correct, since `labels` is public. `input=yes` stands. `hot=no` has no contradicting evidence, because no benchmark or hot path was cited. No tag needs an upgrade.

**Test-input note (factual, for acceptance feasibility):** the tests need an input where sorted order differs from first-seen order, with duplicates (for example `["b","a","b"]`). Already-sorted inputs such as `["a","b"]` would pass under the wrong, helper-based behavior and so cannot distinguish it.

## Smaller / none

The plan has a single change, `labels()` plus its tests. Nothing in it rests on symmetry or future-proofing, and no `keep because:` stream is present.

Smaller: none — already minimal, because the edit is one function plus its tests, and both files are required by task.md.

## Coverage

Checked the single workstream: spec, provenance, reuse/scope, review tags, verification command and test-input adequacy. Problems are in the table.

## Next step

Send the BLOCKER and MAJOR rows to the planner for the step-6b Fix round. The planner should replace the mandate with the task.md requirement and mark `legacy_unique` as `do not reuse:`. Pass 2 is needed only if that round adds new paths.

```
PLAN_NEEDS_FIX blockers=1 majors=1 minors=0
file: $RUN/plan-validation.md
```