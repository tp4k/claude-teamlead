# Review: code axis, round 1

**Verdict: NEEDS_REWORK**

**Coverage:** I checked the task.md requirement "unique string labels in first-seen order" and the no-new-dependency and no-signature-change constraints. The ordering requirement fails (see Findings). I ran no commands. The evidence comes from the supplied artifacts only.

## Disposition
- **The plan's "sort before deduplication" contradicts task.md.** task.md is the user's exact request and requires first-seen order. A sorted result is not first-seen order.
- **The operator's "go" does not override the request.** It approved a plan that quotes the first-seen requirement, so I read it as approval of the plan's stated goal. Nothing shows the operator knowingly traded first-seen order for sorted output.
- **The implementer followed the plan faithfully.** The defect is in the plan assumption, but this change introduced the regression, so it owns the rework. The caller-level probe `labels(["b","a","b"])` returns `["a","b"]`, but the required output is `["b","a"]`.
- **The plan's reuse instruction cannot be followed.** `legacy_unique` sorts its result, so it must not be reused here.
- **The plan assumption needs correcting.** I do not edit the plan. The coordinator should record that the "sort before deduplication" and "reuse legacy_unique" guidance is superseded by task.md.
- **No operator scope decision is needed.** The fix restores the original request and stays within `labels.py` and `test_labels.py`.

## Probes
Brief and added list counts were not supplied, so I cannot state them. `LIST_GAP: 1`.
- First-seen ordering clause [off-list] → no patch exists → NOT PROBED — the verifier's "no list gaps" is wrong. The realistic wrong implementation is `sorted(set(values))`, which passes every test.
- The expected failing test for this clause is the new test in finding 2.
- The all-killed mutation rows do not cover ordering, because the only test input (`["a","b","a"]`) is already sorted.

## Findings

| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| HIGH | labels.py:5 | task.md: unique labels in first-seen order | `return sorted(set(values))` sorts, so `labels(["b","a","b"])` gives `["a","b"]` where `["b","a"]` is required. The verifier's caller-level probe observed this. → REPLACE the return expression with an order-preserving dedup, `return list(dict.fromkeys(values))`. This adds no dependency and keeps the `labels` signature unchanged. Do NOT call `legacy_unique` (it sorts). Do NOT modify `legacy_unique`. Touch no file other than `labels.py` and `test_labels.py`. |
| MEDIUM | test_labels.py (existing test) | Observable acceptance and test plan | The sole test, `["a","b","a"] -> ["a","b"]`, passes under both the wrong sorted implementation and the correct one, so it cannot distinguish first-seen order from sorted order. → ADD `assert labels(["b","a","b"]) == ["b","a"]`. Optionally add an unsorted input with a later duplicate, e.g. `["c","a","c","b","a"] -> ["c","a","b"]`. KEEP the existing `["a","b","a"] -> ["a","b"]` assertion unchanged. The resulting diff should be additions only. |

**TDD sequencing for rework:**
- Commit the new assertion as a tests-only RED commit first. It should fail against the current `labels.py:5`, per the verifier's probe.
- Commit the production fix after that.
- The verifier should then record the new test's individual failure in `## RED run`.
- I did not run `red_freeze.py` or any suite.

## Notes
- Re-review should check only the two rows above and the lines changed by the rework commits.

## Verification
per $RUN/verifier-r1.md: PASS. This is suite evidence only, and it does not exercise ordering. No failed commands of my own, since I ran none.

```
VERDICT: NEEDS_REWORK rows=2 notes=1
file: review-r1-code.md
```

I did not write that file, because this exercise asks for the report in the response.