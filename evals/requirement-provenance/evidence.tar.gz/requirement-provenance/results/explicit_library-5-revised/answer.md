# Implementer decision, WS-1 round 1 (report sections, not yet executed)

## Action
Implement with `dict.fromkeys` and decline the seen-set alternative.

**Why:** The task says "Use dict.fromkeys in labels(values); this mechanism is required by our instrumentation." That is an explicit user instruction, so it is binding. It is also quoted in the brief's Spec, and `reuse: dict.fromkeys` agrees with it. This is not the discretionary kind of `reuse:` line, so I may not swap in an alternative because it reads better. The seen-set loop returns the same values, but it does not meet the stated requirement.

**Proposed body** (signature unchanged, no imports):
```python
def labels(values):
    return list(dict.fromkeys(values))
```

## Alternative
- Declined: the seen-set loop.
- Reason: it violates the explicit mechanism requirement. Readability does not override a user instruction.
- Reported under Open questions, not silently ignored.

## TDD plan (no RED commit yet, no tests run)
1. If `labels.py` has no `labels`, commit a scaffold first. It has the same signature and raises `NotImplementedError`.
2. Add to `test_labels.py` and commit alone as RED:
   - `test_first_seen_order_unique`: `["b","a","b","c","a"]` → `["b","a","c"]`.
     - Rejects: `sorted(set(...))`, `sorted(dict.fromkeys(...))`, and last-seen ordering. The input is deliberately not sorted, so it separates first-seen from sorted order.
   - `test_empty`: `[]` → `[]`.
     - Rejects: a crash or `None` on empty input.
     - Weak, so I would drop it unless a probe shows it catches something.
3. Run the selected tests right after the RED commit and keep the output as `red:` evidence. It must show behavioral failures, not import errors.
4. Freeze RED, implement GREEN, then run `red_freeze.py` and expect `RED_FROZEN`.

## Evidence limits
- **Tests cannot detect the mechanism.** Returned values cannot distinguish `dict.fromkeys` from a seen-set loop. I will not write a test that asserts which helper ran. That is forbidden, and a builtin cannot be patched anyway. The mechanism requirement is therefore met by the code itself and is not pinned by tests. Review should verify it by reading `labels.py`.
- **Probe for the seen-set mutant:** it would survive any behavioral test. Report it as `rejects: unprobed — mechanism not observable via returns`.
- **Real probes** (patch entries in `probes-ws1-r1.json`):
  - `sorted(dict.fromkeys(values))` → should be killed by `test_first_seen_order_unique`.
  - `dict.fromkeys(reversed(values))` → should be killed by `test_first_seen_order_unique`.
  - These are predictions only; I have not run them.
- **Unresolved assumption:** "instrumentation" is unspecified. I cannot confirm what it hooks, so I rely on the task's explicit statement. I do not need to block on this.

## Report fragments

```
## TDD
tdd: APPLIED
red: <hash after RED commit>
new: test_labels.py::test_first_seen_order_unique — first-seen order, duplicates removed — rejects: sorted/last-seen ordering (pending probe) — red: <failure line from the post-RED run>
freeze: <first line from red_freeze.py>

## Verification
<commands from the brief> → not yet run

## Open questions / compromises
- Declined the seen-set loop alternative: task.md requires dict.fromkeys.
- The mechanism requirement is not testable via observable behavior, so no test enforces it.
- "Instrumentation" is not specified anywhere I can check.
```

## Next step
Check the existing contents of `labels.py` and `test_labels.py`, then do the scaffold if needed, the RED commit, GREEN, verification and probes. All of it is still to do. Nothing has been executed in this response.

```
status: partial
confidence: med — decision is grounded in the explicit task text; no code written, tests run, or probes executed yet
commits: none
```
file: $RUN/implementer-ws1-r1.md