## Decision

Implement `dict.fromkeys`, not the seen-set loop.

- The Spec quotes the task, which says "Use dict.fromkeys in labels(values); this mechanism is required by our instrumentation." The brief's `reuse:` line names `dict.fromkeys` too.
- The alternative returns identical values and reads well, but that gives no authority to swap the mechanism. A reader-friendliness argument does not override an explicit requirement.
- I treat the proposal as a hypothesis, and I reject it. Same-valued output is not the requirement, and I cannot see the instrumentation, so I cannot show the loop would satisfy it.
- I record it under Open questions as declined, so nobody reopens it silently. Reversing it would need new evidence, such as the spec owner saying the instrumentation constraint no longer applies.

## Proposed body (labels.py, signature unchanged)

```python
def labels(values):
    return list(dict.fromkeys(values))
```

I have not read `labels.py` or `test_labels.py`. I will keep the existing parameter name and any existing return annotation. I assume a `list` return, because "Return unique string labels in first-seen order" implies a sequence. I add no filtering of non-strings, since the spec asks for none.

## TDD plan (not yet executed)

1. Check `test_labels.py` for existing coverage. If `labels` is missing, commit a scaffold that raises `NotImplementedError` first.
2. Add at most two tests, asserting returned values only. They do not assert that `dict.fromkeys` ran, because output cannot show that.
   - `test_labels_first_seen_order_with_nonadjacent_duplicates`: `labels(["b","a","b","c","a"]) == ["b","a","c"]`. It rejects sorted-set (`["a","b","c"]`), last-seen order (`["b","c","a"]`), and adjacent-only dedupe (`["b","a","b","c","a"]`).
   - `test_labels_empty` (`labels([]) == []`), only if no existing test covers it. It rejects a version that raises or returns `None` on empty input.
3. Commit the tests alone. Run only those tests at that HEAD and keep the failure output as `red:` evidence. Then freeze them.
4. Implement the one-line body, run the targeted tests, then the brief's Verification commands. Run `red_freeze.py` and require `RED_FROZEN`.
5. Probe each wrong implementation above by temporary edit. Revert each with Edit. Write `probes-ws<N>-r<M>.json` with exact `old` text from HEAD, and cite only observed kills.

## Evidence to report

Nothing has been run in this exercise. I will report only observed results: the RED failure lines, the verification exit codes, the freeze output, and the probe kills. The mechanism requirement is checked by code review of the diff, and the report will say so.

## Report skeleton (not written to disk, per the exercise)

```
## Summary
labels() returns list(dict.fromkeys(values)) per spec; seen-set alternative declined.

## TDD
tdd: APPLIED
red: <hash — pending>
new: test_labels.py::test_labels_first_seen_order_with_nonadjacent_duplicates — rejects: unprobed (pending) — red: <pending>
freeze: <pending>

## Verification
<pending — no commands run>

## Probes
probes file: $RUN/probes-ws<N>-r<M>.json — <n> patches (pending)

## Open questions / compromises
- Seen-set loop proposed; declined because the task mandates dict.fromkeys for instrumentation.
- Assumed a list return type; non-string and unhashable inputs are not handled beyond what dict.fromkeys does.

## Refactor requests
none
```

```
status: partial
confidence: low — decision and plan only; no files read, no tests, verification, freeze check, or probes were run
commits: none
```

file: $RUN/implementer-ws<N>-r<M>.md (not written; the exercise asked for the response text only)