## Decision

**Action:** I will replace the mechanism assertion in `test_uses_dict_fromkeys`. The edit to that frozen line is authorized because R1 HIGH, adopted by triage, names that test and its `spy.call_count == 1` assertion as wrong. No task text, rule, ADR or caller contract requires a helper invocation. I will not touch `test_first_seen`.

I traced the reviewer's suggestion instead of taking it on trust. `dict.fromkeys` is a reuse recommendation, not a spec requirement, and the spec requires only unique labels in first-seen order. The seen-set loop in `labels.py` produces the same output. So the old assertion checked implementation, not behavior.

**Evidence:** The brief's R1 finding and triage; the spec text; the fact that only the spy test fails against the equivalent loop. Nothing has been executed here, and this directory is not a git repo.

## Next actions

1. Edit only `test_labels.py`. Remove the spy setup and `call_count` assertion. Rename the test to something like `test_duplicates_collapsed`, because the old name would falsely claim a mechanism.
2. Add behavioral coverage with a duplicate-heavy input, for example `labels(["a","a","b","a","b"]) == ["a","b"]`. Call `labels` twice with the same input and assert equal results. That rejects a module-level `seen` that leaks state across calls.
3. Leave `labels.py` unchanged. The finding asks for no production change.
4. Commit the test change separately, using `git commit -F <file under $RUN>`.
5. Run the brief's verification commands, whose text I don't have, from the stated directory.
6. Run `red_freeze.py` with every RED hash. Expect `RED_CHANGED`, listing only the `test_uses_dict_fromkeys` lines I changed: the def, spy and assertion lines. `test_first_seen` must not appear. Each listed line goes beside the R1 HIGH row.
7. Run the self-probes and write `probes-ws<N>-r2.json`.

**May change:** `test_labels.py` only, and only the `test_uses_dict_fromkeys` lines.

**Must not change:** `test_first_seen`, `labels.py`, signatures, dependencies.

## Freeze evidence required

- The `red_freeze.py` output with all RED hashes.
- Each `RED_CHANGED` line mapped to R1 HIGH.
- Confirmation that the `test_first_seen` assertion is untouched.

## Report excerpts (draft, to be confirmed by observation)

```
## TDD
tdd: APPLIED
red: <r1-hash>
new: test_labels.py::test_duplicates_collapsed — duplicates collapse, repeated calls independent — rejects: unprobed until the module-level-seen mutation is run — red: n/a — behaviour already present
existing: test_first_seen — ran / still green
extra: none
freeze: RED_CHANGED — lines of test_uses_dict_fromkeys (def, spy, call_count assert) — authorized by R1 HIGH; test_first_seen unchanged

## Probes
probes file: $RUN/probes-ws<N>-r2.json — <n> patches
# each outcome is filled in only after the probe is run
dedupe guard removed in labels.py → expected killed by test_first_seen or test_duplicates_collapsed
seen hoisted to module scope → expected killed by test_duplicates_collapsed

## Open questions / compromises
labels.py uses a seen-set loop, while Reuse and scope recommends dict.fromkeys.
The behavior is equivalent and R1 asks for no production change, so I left it.
The coordinator may decide whether to switch.
```

```
status: partial
confidence: low — plan only; no tests, freeze check or probes have been run
commits: none
```
file: $RUN/implementer-ws<N>-r2.md

## Counterfactual

Before R1 existed, I would not have made this edit. The freeze forbids changing frozen lines unless a finding explicitly names the test as wrong. My own doubt about the assertion would not authorize the change. I would have reported it under Open questions, left RED as committed, and returned `partial` or `blocked`. The `reuse:` recommendation also made the assertion look defensible in round 1. R1's explicit finding, accepted by triage, is what makes the edit legitimate.