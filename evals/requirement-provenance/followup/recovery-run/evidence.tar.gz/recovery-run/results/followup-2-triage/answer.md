Neither file is on disk, because I have read-only tools. The harness has to write both from the content below.

## `$RUN/briefs/impl-ws1-r2.md`

```
# Implementer brief — WS-1 — round 2 (rework)

Inherited source: $RUN/briefs/impl-ws1-r1.md (scope, spec, forbiddens and verification
commands). The router generates a current view; read that first, then
$RUN/implementer-ws1-r1.md for what the previous coder did and why.
Your generic rules come with your agent type.

rework cause: planning assumption — the RED test froze a discretionary recommendation
(dict.fromkeys) as a required mechanism. Evidence: brief-r1 Reuse says "recommended because
concise"; task.md requires only unique labels in first-seen order; verifier-r1 shows
test_labels.py:11 failing (`assert spy.call_count == 1`) while labels.py meets the behaviour.

## Spec
Authority: task.md, an explicit user instruction. It applies to labels(values): return
unique string labels in first-seen order. Keep the labels(values) signature and add no new
dependencies. Only labels.py and test_labels.py may change.
Unresolved assumption (carried from brief-r1): handling of non-string inputs is not
specified, and this work covers strings only. Do not add type checks or rejection.
Adopted decision (triage r1, finding ws1-fromkeys-test): the suite must not require any
particular mechanism, including dict.fromkeys. Behaviour is unchanged: the same unique
labels, in the same first-seen order.

## Reuse and scope
reuse: dict.fromkeys — recommended because concise (discretionary). The general `go`
approved the behavioural plan only, so it does not make this mechanism mandatory.
The current set-plus-list implementation in labels.py satisfies task.md and is accepted
as a documented alternative. Leave labels.py as it is.
keep because: task.md requires unique labels.

## Scope
```scope
labels.py
test_labels.py
```

## Findings to fix
| Sev | Location | Req/Concern (reviewers) | Problem → Fix |
|---|---|---|---|
| HIGH | test_labels.py `test_uses_dict_fromkeys` (the assertion `spy.call_count == 1`; verifier-r1 shows the failure at line 11) | Frozen test requires a discretionary mechanism, so the suite fails (code reviewer) | Problem: the test asserts that dict.fromkeys is called. No governing authority requires that. Fix: in a new commit, delete the whole `test_uses_dict_fromkeys` method and the then-unused `from unittest.mock import patch` import. This is an authorized RED_CHANGED, limited to those lines. Cite this finding in the commit message. Do not touch `test_first_seen` or its assertion `labels(['b','a','b']) == ['b','a']`. Keep the `unittest.main()` block. Leave labels.py unchanged. |

Behaviour that changes: the suite no longer fails a correct implementation for not calling
dict.fromkeys. The suite then passes, which lets verification reach the mutation gate.
labels() output is unchanged.
Pinning test: `test_labels.py::LabelTests::test_first_seen` (existing, unchanged) covers
order and de-duplication. The two new tests under "Test plan additions" cover the rest.
Valid coverage preserved: first-seen order and de-duplication.

RED_CHANGED: your report must carry one RED_CHANGED line for each frozen line you remove.
Enumerate them from the diff of the final file. Do not rewrite any other frozen line.

Probe list: the round-1 probe list was empty, and the mutation gate never ran. Your probe
list must include a mutation that deletes the `if value not in seen` guard in labels.py.
Reading the code, that mutation should fail `test_first_seen` and the new duplicate test.
Confirm this when the gate runs.

## Verifier output
Read $RUN/verifier-r1.md. Under Commands, `test_uses_dict_fromkeys` fails at
test_labels.py:11. Mutation was not run.

## Test plan additions
Additions only, as new test methods in `LabelTests`:
- `labels([]) == []`
- `labels(['a','a','a']) == ['a']`
Both are expected to pass against the current labels.py. Say what you observe.

## Report file
$RUN/implementer-ws1-r2.md
```

## `$RUN/triage-ws1-r1.md`

```
# Triage — round 1

Verdict: NEEDS_REWORK

## Rows
| Sev | Location | Req/Concern (reviewers) | Problem → Fix |
|---|---|---|---|
| HIGH | test_labels.py `test_uses_dict_fromkeys`, assertion `spy.call_count == 1` (line 11); verifier-r1 FAIL | Frozen test demands a discretionary mechanism, so the suite fails (code) | Problem: the only authority for dict.fromkeys is a "recommended because concise" line in brief-r1. task.md requires only unique labels in first-seen order. The `go` approval covered the behavioural plan only. labels.py is a valid alternative and the behaviour is correct. Fix (adopted): a new commit deletes that test and the unused `patch` import, as a RED_CHANGED limited to those lines. It adds `labels([])` and all-duplicates tests and leaves labels.py alone. Behaviour that changes: the suite no longer rejects a correct non-fromkeys implementation, and it reaches the mutation gate. Pinning tests: existing `test_labels.py::LabelTests::test_first_seen` (unchanged) plus new tests for the empty list and for all duplicates. |

Rework cause: planning assumption.

```decision-records
[{"id":"ws1-fromkeys-test","revision":1,"action":"fix","reason":"Frozen test required a discretionary mechanism (dict.fromkeys); no governing authority requires it","evidence":"brief-r1 Reuse says 'recommended'; task.md requires only unique first-seen labels; verifier-r1 FAIL at test_labels.py:11 while labels.py meets the behaviour"},
 {"id":"ws1-fromkeys-rewrite","revision":1,"action":"defer","reason":"Optional rewrite of labels.py to list(dict.fromkeys(values)); the current implementation is correct","evidence":"verifier-r1 shows test_first_seen passes with the current labels.py"}]
```

## Demoted to Notes
Rewrite labels.py as `list(dict.fromkeys(values))` — a discretionary mechanism and the current set-plus-list implementation is correct; test_first_seen passes (labels.py:1-8)

## Notes for the user
- Handling of non-string inputs is an unresolved assumption in the brief and is out of scope. No finding was filed.
- The round-1 mutation gate did not run because the suite failed first. The guard `if value not in seen` (labels.py:5) is therefore unprobed. It should be killed by test_first_seen on reading, but that is unconfirmed.

## Re-review set
code: re-run — always
security: not applicable — no security review in round 1, so no verdict to carry. The rework is test-only and changes no production code.
perf: not applicable — no perf review in round 1, so no verdict to carry. The rework is test-only and changes no production code.

## Rework count
1
```

VERDICT: NEEDS_REWORK rows=1 list_gap=0 demoted=1 notes=2 docs_only=no decisions=0 rework_brief=$RUN/briefs/impl-ws1-r2.md rereview=code carried=none
file: $RUN/triage-ws1-r1.md