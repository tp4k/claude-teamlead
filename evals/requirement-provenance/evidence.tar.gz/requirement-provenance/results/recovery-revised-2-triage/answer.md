## Triage: round 1 (`$RUN/triage-r1.md`)

**Verdict: NEEDS_REWORK.** Rework count after this round is 1 of 3. `docs_only=no`, because the fix changes a test.

### Rows
| Sev | Location | Req/Concern (code reviewer) | Problem → Fix |
|---|---|---|---|
| HIGH | `test_labels.py:7-11` (`test_uses_dict_fromkeys`, `assert spy.call_count == 1`) | The frozen RED test asserts a discretionary mechanism. | No governing authority requires `dict.fromkeys`. `task.md` requires unique labels in first-seen order. The brief only says "recommended because concise", and the `go` approval covered the behavioral plan. `labels.py` is a documented alternative that meets the behavior, and the suite fails only on the mechanism test (verifier exit 1, `.F`). **Fix:** remove that method and its `RED_CHANGED` lines. Add one behavioral test, `test_repeated_and_empty`, which asserts `labels(['a','a','a']) == ['a']` and `labels([]) == []`. **Behavior that changes:** the suite no longer rejects a correct non-`dict.fromkeys` implementation, so the existing `labels.py` is accepted. It is pinned by `test_labels.py::LabelTests::test_first_seen` (unchanged) and the new `test_repeated_and_empty`. |

The reviewer's MEDIUM row (empty `tree:`, mutation not run) is not a code defect. The mutation step was skipped because the suite failed. It becomes a verification requirement for round 2, listed in the Notes. It is not a finding.

### Demoted to Notes
none

### Notes for the user
- Handling of non-string inputs is unresolved in the brief and out of scope (strings only).
- `dict.fromkeys` stays a recommendation. Evidence: no authority beyond "recommended because concise". Round 2's verification must report `tree:` state and a mutation probe that deletes the `if value not in seen` guard, each as observed.
- The RED run was valid, and `red_freeze` reported `RED_FROZEN` (13 lines). The first-seen assertion at line 14 stays frozen.

### Re-review set
- code: re-run, always.
- security: no review in this round's inputs, so nothing to carry. The rework is test-only with no production change, so no re-run is needed.
- perf: same as security.

```decision-records
[{"id":"frozen-fromkeys-assert","revision":1,"action":"fix","reason":"Test asserts discretionary dict.fromkeys mechanism; no governing authority requires it","evidence":"task.md requires only unique first-seen labels; brief marks dict.fromkeys 'recommended because concise'; verifier: test_labels.py:11 assertion failed against a behaviorally correct labels.py"}]
```

## Rework brief (`$RUN/briefs/impl-ws1-r2.md`)

# Implementer brief — WS-1 — round 2 (rework)

Inherited source: `$RUN/briefs/impl-ws1-r1.md` (scope fence, project rules, verification commands). Read `$RUN/implementer-ws1-r1.md` for what the previous coder did. The active fence already allows `test_labels.py`, so no `## Scope` section is added.

## Spec
Authority: `task.md`, an explicit user instruction, applies to `labels(values)`. Return unique labels in first-seen order. The signature stays `labels(values)` and no new dependencies are allowed. Assumption: handling of non-string inputs is unresolved, and this work covers strings only. Adopted decision (triage r1): the suite must not require a specific mechanism, because no governing authority requires one.

## Reuse and scope
Reuse: `dict.fromkeys` is recommended because it is concise. It is discretionary, not mandatory, and the current `set` plus `list` implementation is an accepted alternative. The general `go` approved the behavioral plan, not the mechanism. Keep because `task.md` requires unique labels. Do not change `labels.py`.

## Findings to fix
1. HIGH, `test_labels.py:7-11`, `test_uses_dict_fromkeys` (`assert spy.call_count == 1`). Remove this method. It is the only frozen assertion you may change. The `unittest.mock` import line stays as is. Keep `test_first_seen` and its line-14 assertion unchanged, since it is the coverage to preserve. Behavior that changes: the suite accepts a correct implementation that does not use `dict.fromkeys`. It is pinned by `test_first_seen` and the new `test_repeated_and_empty`. In your report, give one `RED_CHANGED` line per removed frozen line, each citing this finding. Any other frozen-line change is a defect.

rework cause: planning assumption. The RED test froze a recommended mechanism. Evidence: the brief's "recommended because concise", and `test_labels.py:11` failing against behaviorally correct code.

## Verifier output
Read `$RUN/verifier-r1.md`. Failing command: `python3 -B -m unittest test_labels` exited 1, with the failure at `test_labels.py:11`.

## Test plan additions
`test_repeated_and_empty`: `labels(['a','a','a']) == ['a']` and `labels([]) == []`. Run the suite and state what you observe. Report a probe that deletes the `if value not in seen` guard and say which test kills it, as observed. Do not predict.

## Report file
`$RUN/implementer-ws1-r2.md`

```
VERDICT: NEEDS_REWORK rows=1 list_gap=0 demoted=0 notes=3 docs_only=no decisions=0 rework_brief=$RUN/briefs/impl-ws1-r2.md rereview=code carried=none
file: $RUN/triage-r1.md
```