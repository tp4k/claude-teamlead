| file | line | op / probe | result |
|---|---|---|---|
| labels.py | 2 | added: dict.fromkeys call | KILLED |
| labels.py | 2 | added: first-seen order | KILLED |

MUTATION: PASS killed=2 survived=0 invalid=0 unclassified=0 not_run=0 not_applied=0
