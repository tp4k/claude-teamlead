**Action:** Validated the plan's `legacy_unique` mandate against the supplied sources. I read only the pasted artifacts and ran nothing. No file was written, since this exercise asks for the report in the response.

# Plan validation

Verdict: PLAN_NEEDS_FIX

## Findings

| Severity | Plan claim (quote) | Reality (file:line or "not found") | Fix the plan needs |
|---|---|---|---|
| BLOCKER | Spec and Reuse and scope: "The implementation MUST call legacy_unique(values)." | `labels.py:1-2`: `def legacy_unique(values): return sorted(set(values))`. It returns **sorted** output, but task.md requires **first-seen order**. Any call to it yields alphabetical order, which contradicts the task. Existing callers rely on the sorted behavior, so the helper cannot change. | Remove the MUST from the Spec and from Reuse and scope. Record that the helper is not reusable here because its ordering differs from the required first-seen order. |
| MAJOR | Provenance: "labels.py:1 defines this helper, so repository conventions require it." | The helper exists at `labels.py:1`, but existence is not a mandate. No rule, ADR, consumer or convention document requires helper calls. The only callers depend on its sorted output, which is a reason to leave the helper alone, not to call it. | Remove the unsupported "conventions require it" provenance. If a constraint is kept, cite evidence of both its content and why it governs this workstream. |
| MINOR | The plan quotes the docstring "Return sorted unique labels." | Not found. `labels.py:1-2` is the `def` line and the `return` line, with no docstring. | Drop or correct the quote. It would not support the mandate even if it existed, since "sorted" contradicts first-seen order. |

**Checked and holding:**
- `labels.py` and `test_labels.py` exist, and the scope covers the code to change.
  - `labels(values)` at `labels.py:4-5` currently returns `values` unchanged, so the change is reachable inside scope.
- The tests use unittest and can call `labels` directly.
  - The command `python3 -m unittest test_labels` is plausible as written. I did not run it, and no `cwd:` line was supplied to check.
- Review tags `input=yes` and `public=yes` are consistent with a public `labels(values)`. I found no hot-path evidence, so `hot=no` holds. I upgraded and downgraded none.

## Smaller / none

The plan touches only the two permitted files and one function, so no workstream or acceptance criterion can be dropped without losing the task's required behavior. Removing the helper mandate changes a constraint, not scope.

Smaller: none — already minimal because task.md limits changes to `labels.py` and `test_labels.py`, and the only deliverable is first-seen unique labels.

## Coverage

Validated the single workstream's Spec, Provenance, Reuse and scope, review tags and verification. Problems are in the table.

## Next step

Send these rows to the planner's one Fix round at step 6b. Correct the unsupported mandate and provenance. The design reviewer decides how to implement first-seen uniqueness; I have not redesigned it. Pass 2 needs to re-check only the corrected Spec, Provenance and Reuse claims.

```
PLAN_NEEDS_FIX blockers=1 majors=1 minors=1
file: $RUN/plan-validation.md
```