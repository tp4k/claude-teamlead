**Action:** Planner Fix mode. Answer 1 ("go") is applied. Case sensitivity stays open. I wrote no files, and I did not run any tests. The repo facts below come from the task artifacts, so `labels.py` and `test_labels.py` still need to be read at implementation time.

## What "go" settles
"go" accepts the recommended option, **a) first-seen order**. That settles ordering only: alphabetical is rejected, and the plan states it as fact. It does not settle whether `"a"` and `"A"` are distinct. That question is a separate one and stays open.

## Corrected plan sections (WS-1 — dedupe labels)

### Spec excerpt
task.md (task excerpt, not a repo document): "Return unique string labels in first-seen order. No new dependencies or public signature changes."

### Reuse and scope
- reuse: none found — `labels.py` and `test_labels.py` contain no deduplication helper (per task artifacts). The built-in `dict.fromkeys(values)` is the mechanism, wrapped in `list(...)` if `labels` already returns a list. The implementer confirms the existing return type.
- keep because: user's request (task.md).
- Files: `labels.py`, `test_labels.py` only.

```scope
labels.py
test_labels.py
```

### Decisions taken
1. Order follows first occurrence. Evidence: operator answered "go" to question 1, accepting the recommendation. Alphabetical is rejected.
2. Implement with `dict.fromkeys`. It is concise, adds no dependency, and preserves insertion order. An explicit seen-set loop would also meet the task. Evidence: the task artifacts state that Python dicts preserve insertion order and that both approaches satisfy the task.
3. The public signature and the return type stay as they are. No new imports beyond the stdlib. Evidence: task.md.

### Unresolved assumption (not a decision)
Case variants are provisionally treated as distinct, which is exact-string equality. This is the literal reading of "unique string labels" and the natural behavior of `dict.fromkeys`. The user has not confirmed it. It stays in `questions.md`:

```
1. Should labels differing only in letter case (e.g. "Bug" and "bug") count as the same label?
   options:
     a) distinct, exact string match
     b) same, keep first-seen spelling
   recommended: a
   rests on: task.md "unique string labels" (literal equality; no case-folding mentioned)
   otherwise: b changes WS-1 to dedupe on a casefolded key and replaces the case-variant test
```

The case-variant test is marked provisional in the brief. If the user answers b, the next Fix round updates the brief and the test.

### Observable acceptance
`test_labels.py` should fail before the change on duplicate input and pass afterwards. For `["b","a","b","c","a"]`, `labels` returns `["b","a","c"]`.

### Test plan
- existing: all current `test_labels.py` tests (read them first; none are frozen).
- new:
  - `test_labels.py::test_first_seen_order` — `["b","a","b","c","a"]` gives `["b","a","c"]`. A sorted implementation would return `["a","b","c"]`, so the input tells the two apart.
  - `test_labels.py::test_empty_input` — `[]` gives `[]`.
  - `test_labels.py::test_case_variants_distinct` (provisional, pending the case question) — `["a","A","a"]` gives `["a","A"]`.
- probe: order is first-seen — the result is sorted instead.
- probe: first occurrence wins — the last occurrence's position is kept instead.
- probe: case-variant equality — the key is casefolded (kills the provisional test).
- probe: empty input — raises or returns a non-empty result.

### Review axes
- attacker-controlled input: yes — the origin of `values` is unknown, so default to yes.
- hot path: no — no spec or benchmark identifies one.
- public surface: yes — `labels` is a public function whose output behavior changes.

### Verification commands
cwd: .
- `python -m unittest test_labels`

The availability of `python` is unchecked, since I ran no `which`.

## Brief excerpts (impl-ws1-r1.md)
- **Spec, Reuse and scope, Test plan, Scope** carry the text above verbatim, including the `scope` fence.
- **Do not touch:** every file other than `labels.py` and `test_labels.py`, any dependency manifest, and the signature of `labels`.
- **Project forbiddens:** none exist (no CLAUDE.md or rule files provided).
- **Report file:** `$RUN/implementer-ws1-r1.md`.

## Fix log
- answer 1: first-seen order → Decisions taken #1 added, alphabetical option removed, order test added.
- case question: no answer received → remains open, provisional assumption labeled, otherwise-branch recorded.

## Next step
The coordinator relays the case question and waits. If the answer is **a**, the brief is dispatched as written and the provisional label is dropped. If the answer is **b**, I run another Fix round.

```
PLAN_FIXED fixed=1 new_paths=no
```