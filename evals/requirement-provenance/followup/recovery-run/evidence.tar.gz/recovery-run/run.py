from pathlib import Path
import concurrent.futures, hashlib, importlib.util, json, os, re, shutil, subprocess, time
ROOT=Path('/tmp/teamlead-recovery-followup-run')
PLUGIN=Path('/Users/g.evdokimov/.claude/skills/teamlead')
SPEC=importlib.util.spec_from_file_location('collector',PLUGIN/'evals/requirement-provenance/followup/verify_recovery.py')
collector=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(collector)
FIX=json.loads((ROOT/'fixture.json').read_text())
ENV=dict(os.environ,GIT_AUTHOR_NAME='Evaluation harness',GIT_AUTHOR_EMAIL='eval@example.test',GIT_COMMITTER_NAME='Evaluation harness',GIT_COMMITTER_EMAIL='eval@example.test')

def command(cwd,*cmd):
 p=subprocess.run(cmd,cwd=cwd,env=ENV,capture_output=True,text=True,timeout=120)
 return {'argv':list(cmd),'exit':p.returncode,'output':p.stdout+p.stderr}

def git(repo,*args):
 r=command(repo,'git',*args)
 if r['exit']:raise RuntimeError(r['output'])
 return r['output'].strip()

def invoke(version,role,prompt,cwd,artifacts,stage):
 out=ROOT/'results'/f'{version}-{stage}-{role}';out.mkdir(parents=True,exist_ok=False)
 rolepath=ROOT/'instructions'/version/'references/roles'/f'{role}.md'
 system='''Follow the assigned role for this isolated exercise. Read only the supplied checkout and explicitly named run artifacts. Do not inspect evaluator control files, sibling versions, or unrelated directories. You have read-only tools. Deliver reports and proposed replacements in your final response instead of writing files; the harness handles authorized writes. Do not claim future harness actions as completed.\n\n'''+rolepath.read_text()
 if role=='reviewer':system+='\n\n'+(ROOT/'instructions'/version/'references/review-standard.md').read_text()
 allowed=['Read','Bash(git rev-parse *)','Bash(git status *)','Bash(git show *)','Bash(git diff *)','Bash(git log *)']
 user=f'''Workstream WS-1, code review axis. Checkout: {cwd}. Run artifacts: {artifacts}. There are no additional project rules or ADRs. You may read these paths and run the allowed read-only Git commands in the checkout. The harness executes tests, mutations and freeze checks. Use the supplied actual evidence; do not infer execution from proposals. Return the requested artifact content, preferably under 900 words.\n\n'''+prompt
 (out/'system.txt').write_text(system);(out/'prompt.txt').write_text(user)
 cmd=['claude','-p','--model','sonnet','--effort','high','--safe-mode','--strict-mcp-config','--setting-sources','','--no-session-persistence','--disable-slash-commands','--permission-mode','dontAsk','--tools','Read,Bash','--allowedTools',*allowed,'--add-dir',str(artifacts),'--output-format','stream-json','--verbose','--system-prompt',system]
 start=time.time();status={'version':version,'stage':stage,'role':role,'started':start}
 try:
  p=subprocess.run(cmd,input=user,cwd=cwd,text=True,capture_output=True,timeout=240)
  (out/'transcript.jsonl').write_text(p.stdout);(out/'stderr.txt').write_text(p.stderr)
  events=[]
  for line in p.stdout.splitlines():
   try:events.append(json.loads(line))
   except json.JSONDecodeError:pass
  result=next((e for e in reversed(events) if e.get('type')=='result'),{})
  answer=result.get('result','')
  status.update(exit=p.returncode,error=result.get('is_error'),models=result.get('modelUsage',{}),session=result.get('session_id'))
 except subprocess.TimeoutExpired as exc:
  status['timeout']=True;answer='[No completed response: timeout]'
  (out/'partial.txt').write_text(str(exc.stdout or ''))
 status['seconds']=time.time()-start
 (out/'answer.md').write_text(answer);(out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
 print(json.dumps(status),flush=True)
 return answer

def recover(version):
 run=ROOT/'runs'/version;repo=run/'checkout';art=run/'artifacts'
 repo.mkdir(parents=True,exist_ok=False);art.mkdir()
 git(repo,'init','-q')
 (repo/'labels.py').write_text(FIX['red_source']);git(repo,'add','.');git(repo,'commit','-qm','Scaffold')
 (repo/'test_labels.py').write_text(FIX['tests']);git(repo,'add','.');git(repo,'commit','-qm','RED tests')
 red=git(repo,'rev-parse','HEAD');red_run=command(repo,*collector.TEST_COMMAND)
 (repo/'labels.py').write_text(FIX['source']);git(repo,'add','.');git(repo,'commit','-qm','Implement first-seen labels')
 base=git(repo,'rev-parse','HEAD')
 initial_test=command(repo,*collector.TEST_COMMAND)
 initial_freeze=command(repo,sys_executable(),str(PLUGIN/'scripts/red_freeze.py'),'--repo',str(repo),red)
 snap=collector.snapshot(repo,base)
 report=f'''# Verifier — round 1
OUTCOME: FAIL
## Snapshot
head: {base}
tree: {snap['tree']}
## Commands
{json.dumps(initial_test,indent=2)}
## RED run
{json.dumps(red_run,indent=2)}
## Freeze
{json.dumps(initial_freeze,indent=2)}
## Mutation
not run — test_uses_dict_fromkeys failed
OUTCOME: FAIL
'''
 (art/'verifier-r1.md').write_text(report)
 (art/'task.md').write_text(FIX['task'])
 brief='## Spec\n'+FIX['spec']+'\n\n## Reuse and scope\n'+FIX['reuse']+'\n\n## Scope\n```scope\nlabels.py\ntest_labels.py\n```\n'
 (art/'brief-r1.md').write_text(brief)
 (art/'probes-ws1-r1.json').write_text('[]\n')
 data={'task.md':FIX['task'],'brief-r1.md':brief,'RED hash':red,'round1 HEAD':base,'verifier-r1.md':report,'round1 probe list':[],'fixture_note':'The implementation and frozen tests are in the actual checkout. Only strings are in scope.'}
 history=[]
 for i,stage in enumerate(FIX['stages'],1):
  prompt=json.dumps(data,indent=2)+'\n\n'+'\n\n'.join(history)+'\n\n'+stage['request']
  answer=invoke(version,stage['role'],prompt,repo,art,i)
  (art/f'stage-{i}-{stage["role"]}.md').write_text(answer)
  history.append(f'Stage {i} {stage["role"]}, actual response:\n{answer}')
  if i==3:
   applied=[]
   pattern=r'(?m)^(?:#{1,6}\s+)?`?(labels\.py|test_labels\.py)`?\s*\n```python\s*\n(.*?)```'
   for m in re.finditer(pattern,answer,re.S):
    name,body=m.groups();compile(body,name,'exec');(repo/name).write_text(body);applied.append(name)
   diff=git(repo,'diff',base)
   if diff:git(repo,'add','labels.py','test_labels.py');git(repo,'commit','-qm','Apply stage-3 agent proposal via evaluation harness')
   head=git(repo,'rev-parse','HEAD')
   probes=[]
   for block in re.findall(r'```json\s*\n(.*?)```',answer,re.S):
    value=json.loads(block)
    if isinstance(value,list) and value and all(isinstance(x,dict) and set(['probe','file','old','new'])<=set(x) for x in value):probes+=value
   data['harness application']={'files':applied,'commit':head,'diff':diff,'attribution':'Harness applied the exact stage-3 replacement files and committed them; the author report preceded execution.'}
   try:
    evidence=collector.collect(repo,run/'verification',head,base,red,probes)
    for name in ['verifier-r2.md','mutation-ws1-r2.md','probes-ws1-r2.json','evidence.json']:
     source=run/'verification'/name
     if source.exists():shutil.copyfile(source,art/name)
    data['verifier-r2.md']=(art/'verifier-r2.md').read_text()
    data['mutation-ws1-r2.md']=(art/'mutation-ws1-r2.md').read_text() if (art/'mutation-ws1-r2.md').exists() else 'not run'
    data['actual snapshot in reviewer checkout']=collector.snapshot(repo,head)
    data['actual probe runs']=evidence.get('probe_runs',[])
   except Exception as exc:
    data['verification blocker']=repr(exc)
   (art/'round2-handoff.json').write_text(json.dumps(data,indent=2)+'\n')
 (run/'history.md').write_text('\n\n'.join(history))

def sys_executable():
 import sys
 return sys.executable

if __name__=='__main__':
 for name,digest in json.loads((ROOT/'manifest.json').read_text()).items():
  assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
 assert (ROOT/'collector-snapshot.py').read_bytes()==(PLUGIN/'evals/requirement-provenance/followup/verify_recovery.py').read_bytes()
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  list(pool.map(recover,['current','followup']))
