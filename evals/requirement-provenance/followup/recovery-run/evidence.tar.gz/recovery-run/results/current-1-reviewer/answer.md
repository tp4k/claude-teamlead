# Review WS-1 r1, code axis

## Verdict
NEEDS_REWORK

## Coverage
I checked the task.md and brief-r1 requirements, the frozen RED tests, scope, and the verifier evidence. The requirement that `labels` use `dict.fromkeys` is the failure, in row 1. The behavioural requirement (unique strings, first-seen order) is met at `labels.py:1-8` and is checked by `test_labels.py::test_first_seen`.

## Probes
list: 0 brief + 0 added; off-list clauses: 1; LIST_GAP: 0

- The probe list (`probes-ws1-r1.json`) is `[]`, and the mutation gate did not run ("not run — test_uses_dict_fromkeys failed"). No probe rows exist to grade.
- First-seen dedupe [off-list] → NOT PROBED — the gate did not run. Reading the tests, `test_labels.py::test_first_seen` (input `['b','a','b']`, expected `['b','a']`) would reject a sorted or `set()`-ordered result. I found no realistic wrong implementation that passes the tests, so there is no LIST_GAP.
- Re-run the mutation gate after the fix in row 1.

## Findings
| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| HIGH | `labels.py:1-8` (`test_labels.py:8-11`) | Brief "Reuse and scope": `reuse: dict.fromkeys`. Frozen RED test `test_uses_dict_fromkeys`. | The verifier's suite run is FAIL. `test_uses_dict_fromkeys` fails at `test_labels.py:11` (`assert spy.call_count == 1`). `labels` never calls `dict.fromkeys` and builds the result with a hand-rolled `set` and `list` loop. `test_first_seen` passes, so only the reuse requirement is unmet. → In `labels.py`, replace the body with `return list(dict.fromkeys(values))`. Resolve `dict` as a bare module-global name, not via `builtins` or an alias. The test patches `labels.dict` and counts calls on `.fromkeys`. Remove the `seen`/`result` loop. Keep the signature `labels(values)`. Do not edit `test_labels.py`: RED is frozen, and both existing tests must stay as they are. Only `labels.py` may change. |

## Notes
- The brief calls `dict.fromkeys` "recommended because concise" and also "keep because: task.md requires unique labels". task.md does not name `dict.fromkeys`. `test_uses_dict_fromkeys` therefore pins an implementation choice, not behaviour. The implementer should apply the fix in row 1 as written. If the user wants the reuse optional, the coordinator should authorize a RED change explicitly. The implementer must not weaken the test unilaterally.
- Non-string handling is declared out of scope by the brief. Unhashable inputs would raise `TypeError` in both the current code and `dict.fromkeys`, so this is not a finding.
- The scope is respected: the post-scaffold commits touch only `labels.py` and `test_labels.py`.

## Verification
per `$RUN/verifier-r1.md`: FAIL. The failing command was `python3 -B -m unittest -v test_labels`, which exited 1 with `test_uses_dict_fromkeys` failing at `test_labels.py:11`.

I confirmed that HEAD is `ab0ac5d36a0c590eb822d5fc1c0c476160c033d6`, matching the verifier's recorded `head:`, and that `git status --porcelain=v1 --untracked-files=all` is empty. I read the verifier's RED run and Freeze output (`RED_FROZEN`). I did not run the freeze check, tests, or mutations myself. My Bash access was denied partway through, so I did not run `git show 5596652 --stat`.

VERDICT: NEEDS_REWORK rows=1 notes=3
file: review-r1-code.md (proposed path for the harness; I did not write it)