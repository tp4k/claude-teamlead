**Action:** Fix mode, applying the operator's "go" to question 1. I did not run any tests or write any files.

## What "go" settles
- **Settled:** question 1, label order. "go" accepts the recommended option a), first-seen order. Alphabetical is dropped.
- **Not settled:** the case-variants question. "go" answered the question asked and nothing else. I am not folding case handling into it.

## Spec
Source: `task.md` (verbatim task text, not a repo spec): "Return unique string labels in first-seen order. No new dependencies or public signature changes."

## Reuse and scope
- reuse: none found. I searched `labels.py` and `test_labels.py` and there is no dedup helper. The stdlib builtin `dict.fromkeys` is allowed (no new dependency) and preserves insertion order.
- keep because: the user's request. `labels(values)` must return unique strings in first-seen order.
- The mechanism is the implementer's choice. `list(dict.fromkeys(values))` and an explicit seen-set loop both satisfy the task for strings. I do not prescribe one.
- The implementer must preserve the existing return type of `labels`. I have not seen it in the artifacts.

## Decisions taken
1. Label order is first-seen. The operator answered "go" to question 1 and accepted option a), the recommendation. Evidence: `task.md`, "first-seen order".
2. **Provisional, not closed:** two strings are duplicates only if they are exactly equal, so `"A"` and `"a"` are distinct. There is no case folding. Evidence: `task.md` says "unique string labels" and mentions no normalization. Case folding would be a behavior the task does not ask for. This stays open (question below) and is worded identically in the plan and the brief.

## Brief excerpts (WS-1, round 1)
```scope
labels.py
test_labels.py
```
Observable acceptance: `labels(["b","a","b","c","a"])` returns `["b","a","c"]`.

Test plan:
- existing: any current `test_labels.py` cases. I have not seen them. The implementer must keep them passing.
- new:
  - `test_labels.py::test_first_seen_order` — `["b","a","b","c","a"]` → `["b","a","c"]`. This fails for sorted output (`["a","b","c"]`) and for last-seen order (`["b","c","a"]`).
  - `test_labels.py::test_empty_input` — `[]` → `[]`.
  - `test_labels.py::test_case_variants_distinct` (provisional) — `["A","a","A"]` → `["A","a"]`. This fails if case folding is introduced.
- probe: order is first-seen — output is sorted alphabetically instead.
- probe: the first occurrence keeps its position — a repeat moves the label to its last-seen position.
- probe: duplicates are exact-equal strings — comparison is case-folded.

Do not touch: everything except `labels.py` and `test_labels.py`. Anti-scope: no new dependencies, no public signature changes, no handling of non-string inputs, no sorting.

Review axes:
- attacker-controlled input: yes — the source of `values` is unknown and I default to yes when uncertain.
- hot path: no — nothing in the artifacts marks it as high-volume.
- public surface: yes — `labels` is a public function and its behavior is changing.

Verification:
cwd: .
- `python -m unittest test_labels`

I have not confirmed with `which` that this invocation works here. The implementer must do that.

Project forbiddens: none (no CLAUDE.md or rule files were supplied).

## Questions.md (remaining item)
1. Should labels differing only by letter case, such as "A" and "a", count as distinct?
   options:
     a) distinct, exact string equality
     b) same, case-insensitive match
   recommended: a
   rests on: `task.md` "unique string labels" (no normalization mentioned)
   otherwise: b changes WS-1 acceptance (the first-seen casing is kept) and replaces `test_case_variants_distinct`. `dict.fromkeys` alone would no longer suffice.

## Fix log
- answer 1: first-seen order → recorded as a fact in Decisions taken. The mechanism is unchanged because it was already the recommendation.
- unresolved assumption (case) → kept as the provisional decision 2 and as an open question. No scope cut.

PLAN_FIXED fixed=1 new_paths=no