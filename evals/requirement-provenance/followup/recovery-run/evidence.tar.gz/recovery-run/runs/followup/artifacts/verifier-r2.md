# Verifier — recovery evidence supplement

OUTCOME: PASS

## Snapshot

head: 07cc27d134bc9ba5bc4b669c3fab257a445f0dde
tree: CLEAN

## Commit attribution

Original harness applied the agent's proposed file; this collector only verifies that existing commit in a clone.

commit 07cc27d134bc9ba5bc4b669c3fab257a445f0dde
Author:     Evaluation harness <eval@example.test>
AuthorDate: Fri Oct 30 11:21:13 2026 +0400
Commit:     Evaluation harness <eval@example.test>
CommitDate: Fri Oct 30 11:21:13 2026 +0400

    Apply stage-3 agent proposal via evaluation harness

## RED run

none — round 2 has no new RED commit

## Tests

/Users/g.evdokimov/.pyenv/versions/3.12.4/bin/python3 -B -m unittest -v test_labels → exit 0
> test_all_duplicates (test_labels.LabelTests.test_all_duplicates) ... ok
> test_empty (test_labels.LabelTests.test_empty) ... ok
> test_first_seen (test_labels.LabelTests.test_first_seen) ... ok
> 
> ----------------------------------------------------------------------
> Ran 3 tests in 0.000s
> 
> OK

## Freeze

/Users/g.evdokimov/.pyenv/versions/3.12.4/bin/python3 /Users/g.evdokimov/.claude/skills/teamlead/scripts/red_freeze.py --repo /private/tmp/teamlead-recovery-followup-run/runs/followup/verification/checkout 559665203eddc5590a2d74f091fdb59b68662e36 → exit 1
> RED_CHANGED — 6 of 13 frozen lines missing at HEAD
> 559665203 test_labels.py: from unittest.mock import patch
> 559665203 test_labels.py: def test_uses_dict_fromkeys(self):
> 559665203 test_labels.py: with patch('labels.dict', wraps=dict, create=True) as wrapper:
> 559665203 test_labels.py: spy = wrapper.fromkeys
> 559665203 test_labels.py: labels(['b', 'a', 'b'])
> 559665203 test_labels.py: assert spy.call_count == 1

## Mutation

/Users/g.evdokimov/.pyenv/versions/3.12.4/bin/python3 /Users/g.evdokimov/.claude/skills/teamlead/scripts/mutate.py --repo /private/tmp/teamlead-recovery-followup-run/runs/followup/verification/checkout --base ab0ac5d36a0c590eb822d5fc1c0c476160c033d6 --commits 07cc27d134bc9ba5bc4b669c3fab257a445f0dde --cmd '/Users/g.evdokimov/.pyenv/versions/3.12.4/bin/python3 -B -m unittest -v test_labels' --probes /private/tmp/teamlead-recovery-followup-run/runs/followup/verification/probes-ws1-r2.json --max-generic 0 --out /private/tmp/teamlead-recovery-followup-run/runs/followup/verification/mutation-ws1-r2.md → exit 0
> KILLED  labels.py:5  probe=added: delete the `if value not in seen` guard so duplicates are kept
> KILLED  labels.py:6  probe=added: never record a value as seen, so duplicates pass the guard
> KILLED  labels.py:8  probe=added: return labels sorted instead of in first-seen order
> MUTATION: PASS killed=3 survived=0 invalid=0 unclassified=0 not_run=0 not_applied=0

## Observed probe failures

added: delete the `if value not in seen` guard so duplicates are kept
> test_all_duplicates (test_labels.LabelTests.test_all_duplicates) ... FAIL
> test_empty (test_labels.LabelTests.test_empty) ... ok
> test_first_seen (test_labels.LabelTests.test_first_seen) ... FAIL
> 
> ======================================================================
> FAIL: test_all_duplicates (test_labels.LabelTests.test_all_duplicates)
> ----------------------------------------------------------------------
> Traceback (most recent call last):
>   File "/private/tmp/teamlead-recovery-followup-run/runs/followup/verification/checkout/test_labels.py", line 13, in test_all_duplicates
>     assert labels(['a', 'a', 'a']) == ['a']
>            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
> AssertionError
> 
> ======================================================================
> FAIL: test_first_seen (test_labels.LabelTests.test_first_seen)
> ----------------------------------------------------------------------
> Traceback (most recent call last):
>   File "/private/tmp/teamlead-recovery-followup-run/runs/followup/verification/checkout/test_labels.py", line 7, in test_first_seen
>     assert labels(['b', 'a', 'b']) == ['b', 'a']
>            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
> AssertionError
> 
> ----------------------------------------------------------------------
> Ran 3 tests in 0.000s
> 
> FAILED (failures=2)

added: never record a value as seen, so duplicates pass the guard
> test_all_duplicates (test_labels.LabelTests.test_all_duplicates) ... FAIL
> test_empty (test_labels.LabelTests.test_empty) ... ok
> test_first_seen (test_labels.LabelTests.test_first_seen) ... FAIL
> 
> ======================================================================
> FAIL: test_all_duplicates (test_labels.LabelTests.test_all_duplicates)
> ----------------------------------------------------------------------
> Traceback (most recent call last):
>   File "/private/tmp/teamlead-recovery-followup-run/runs/followup/verification/checkout/test_labels.py", line 13, in test_all_duplicates
>     assert labels(['a', 'a', 'a']) == ['a']
>            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
> AssertionError
> 
> ======================================================================
> FAIL: test_first_seen (test_labels.LabelTests.test_first_seen)
> ----------------------------------------------------------------------
> Traceback (most recent call last):
>   File "/private/tmp/teamlead-recovery-followup-run/runs/followup/verification/checkout/test_labels.py", line 7, in test_first_seen
>     assert labels(['b', 'a', 'b']) == ['b', 'a']
>            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
> AssertionError
> 
> ----------------------------------------------------------------------
> Ran 3 tests in 0.000s
> 
> FAILED (failures=2)

added: return labels sorted instead of in first-seen order
> test_all_duplicates (test_labels.LabelTests.test_all_duplicates) ... ok
> test_empty (test_labels.LabelTests.test_empty) ... ok
> test_first_seen (test_labels.LabelTests.test_first_seen) ... FAIL
> 
> ======================================================================
> FAIL: test_first_seen (test_labels.LabelTests.test_first_seen)
> ----------------------------------------------------------------------
> Traceback (most recent call last):
>   File "/private/tmp/teamlead-recovery-followup-run/runs/followup/verification/checkout/test_labels.py", line 7, in test_first_seen
>     assert labels(['b', 'a', 'b']) == ['b', 'a']
>            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
> AssertionError
> 
> ----------------------------------------------------------------------
> Ran 3 tests in 0.000s
> 
> FAILED (failures=1)

The reviewer must match any RED_CHANGED lines to the prior finding.
This supplement does not change the original agent verdicts.

OUTCOME: PASS
