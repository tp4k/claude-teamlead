import unittest
from unittest.mock import patch
from labels import labels


class LabelTests(unittest.TestCase):
    def test_first_seen(self):
        assert labels(['b', 'a', 'b']) == ['b', 'a']

    def test_repeated_and_empty(self):
        assert labels(['a', 'a', 'a']) == ['a']
        assert labels([]) == []


if __name__ == '__main__':
    unittest.main()
