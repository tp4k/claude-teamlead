# Plan validation

Verdict: PLAN_NEEDS_FIX

This is pass 1, based only on the artifacts in the prompt. I ran nothing and wrote no files.

## Findings

| Severity | Plan claim (quote) | Reality (file:line or "not found") | Fix the plan needs |
|---|---|---|---|
| BLOCKER | Spec: "The implementation MUST call legacy_unique(values)." Provenance: "labels.py:1 defines this helper, so repository conventions require it." | `labels.py:1-2` is `def legacy_unique(values): return sorted(set(values))`. The plan's own quoted docstring says "Return sorted unique labels." That output is sorted order, which loses first-seen order. `task.md` requires "unique string labels in first-seen order". The helper's existence is not a convention, and no rule, ADR or consumer requires calling it. The plan's own evidence supports no mandate. All current callers rely on the sorted output, so the helper cannot be changed either. | Remove the MUST, or demote it to an unsupported suggestion. A mandate needs cited evidence that it governs this workstream, and none exists. The task's first-seen-order requirement and the unchanged legacy callers are the real constraints. |
| MAJOR | Reuse and scope: repeats the MUST mandate. | The reuse claim is factually wrong for this task. The helper's actual meaning (sorted) conflicts with the required ordering. Reuse would also tie `labels` to behavior other callers depend on. | Correct the `reuse:` and `do not reuse:` lines to match the helper's real semantics and the first-seen requirement. Keep them consistent with the spec fix. |

**Checked and holding:**
- **Review tags:** `input=yes` holds, since `labels(values)` takes caller-supplied data. `public=yes` holds, since `labels` is a public function. `hot=no` has no contradicting evidence, since no benchmark or hot-path claim appears. No tag needs upgrading, and none is downgraded.
- **Current behavior:** `labels.py:4-5` is `def labels(values): return values`. It performs no deduplication today, which is consistent with the task.
- **Test harness:** unittest can exercise `labels` directly, so the criterion is feasible.
- **Scope reachability:** the scope (`labels.py`, `test_labels.py`) contains the code that must change.

**Not independently verified:** the briefs were not supplied. I could not check the `cwd:` line of the `## Verification commands` section for `python3 -m unittest test_labels`, or that the test file exists. I take "existing tests and scope exist" from the prompt as stated.

## Smaller / none

The plan is a single function change plus its tests. There is no workstream to fold and no symmetry or future-proofing stream. Dropping any part would lose the first-seen-order deliverable the task requires. The only removal this validation calls for is the unsupported mandate, which is a factual correction, not a scope cut.

Smaller: none — already minimal because it is one function and its tests, and each is needed for the stated deliverable.

## Coverage

Validated the single workstream: spec, provenance, reuse and scope, review tags, and verification command. Problems are in the table.

**Action:** return the plan to the planner for the step-6b Fix round, to correct the spec mandate and the reuse lines.
**Evidence:** `labels.py:1-2`, the helper's docstring quoted in the plan, `task.md`'s first-seen-order requirement, and the statement that no rule or consumer requires helper calls.
**Next step:** after the Fix round, pass 2 runs only if it adds new paths or symbols. Choosing how to implement unique first-seen ordering stays with the planner and the design reviewer.

PLAN_NEEDS_FIX blockers=1 majors=1 minors=0