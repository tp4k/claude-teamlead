## Triage, round 1: conflict between governing sources

**Action:** STOP. No implementer is dispatched and no rework is consumed. Autopilot cannot settle this, and a `recommended:` line cannot override a conflict between governing requirements.

**Conflicting sources**
- `task.md`, the user's explicit instruction: `labels(values)` returns labels in first-seen order, with no signature change and no new dependencies.
- `api-v1.md #Labels`, an active published external contract for this endpoint: it MUST return unique labels in ascending lexical order. The release cannot change the contract version.

**Evidence**
- The reviewer reports `["b","a","b"]` returns `["b","a"]`, which violates the contract; the contract requires `["a","b"]`.
- The implementer conforms to the task, and security and performance approve.
- Verification is a clean PASS. That shows the code meets the task and tests, not that it meets the contract.
- The user has not authorized a contract revision and has not been told about the conflict.

Both reviewer suggestions are rejected. Silently revising the contract has no authority behind it. Keeping the sort silently overrides the user's instruction. Either choice resolves a governing conflict without the person who owns it.

## Triage file content (`triage-r1.md`)

Verdict: STOP

| Sev | Location | Req/Concern (reviewers) | Problem → Fix |
|---|---|---|---|
| HIGH | labels.py | api-v1.md #Labels vs task.md (code) | Implementation follows the task but violates the contract. No fix adopted, because either code behavior breaks one governing source. Decision needed from the user. |

**Demoted to Notes:** none

**Notes for the user**
- The reviewer's suggestion to silently revise the contract was not adopted, since there is no authority for it.
- Security and performance approved; the verifier passed. Neither covers contract conformance.

**Decision needed (the user chooses):**
1. Keep ascending lexical order. Amend `task.md`; the code then needs a rework to restore sorting and unique labels.
2. Keep first-seen order. The user must authorize a contract change or a new API version. That revision is outside the labels.py/test_labels.py scope and needs its own authorization.
3. Keep first-seen order as an explicit, documented deviation from the contract, accepted by the user with its consequences.

**Re-review set** (applies once the user decides)
- code: re-run, always.
- security: carried, no finding in the round-1 review. Re-run if the chosen fix changes behavior beyond ordering.
- perf: carried on the same basis.

**Rework count:** 0 (cap 3). STOP is not a rework round.

**Possible root cause:** the task and the external contract conflict at the requirement level. The planning step did not check the task against api-v1.md.

## Constraints preserved for any later resume
- Edits only to `labels.py` and `test_labels.py`.
- No public signature change and no new dependencies.
- Frozen assertions stay frozen unless a finding names the exact erroneous assertion and the governing authority for changing it.
- No decision record is written, because the user has not decided.

## Rework brief
Not written (`rework_brief=none`). There is no executable fix until the user resolves the conflict. After they decide, write a brief stating the behavior change and the test that pins it, with `rework cause: planning assumption`.

```
VERDICT: STOP rows=1 list_gap=0 demoted=0 notes=2 docs_only=no decisions=0 rework_brief=none rereview=code carried=security,perf
file: $RUN/triage-r1.md
```