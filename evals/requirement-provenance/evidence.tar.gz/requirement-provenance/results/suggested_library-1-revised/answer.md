# Planner Fix mode: WS-1 (labels deduplication)

**Action:** I updated the plan and brief text below. I wrote no files and ran no tests. I did not read `labels.py` or `test_labels.py` directly (only the exercise description), so the return type and current body are for the implementer to confirm.

## What the answer settles
"go" on the order question adopts **a) first-seen order**. That is a behavioral decision and is now stated as fact, not a conditional choice. The task text already says "first-seen order", so the answer confirms rather than changes behavior.

"go" does **not** make `dict.fromkeys` binding. It was a discretionary recommendation, and no one instructed a mechanism. "go" also does **not** answer the case-variant question, which stays open.

## Spec
Source: task.md (verbatim task excerpt): "Return unique string labels in first-seen order. No new dependencies or public signature changes."
- **Binding, explicit user instruction (task.md):** unique labels, first-seen order, no new dependencies, no public signature change.
- **Adopted decision:** order follows the input. Source: operator reply "go" to question 1, option a. Alphabetical (b) is rejected.
- **Unresolved assumption (not a requirement):** case variants (`"a"`, `"A"`) are distinct, i.e. exact string equality. It is provisional, pending question 1 in `questions.md`.

## Reuse and scope
reuse: none found — searched `labels.py` and `test_labels.py`; no deduplication helper exists.
Recommended: `list(dict.fromkeys(values))`, which is concise and preserves insertion order. An explicit seen-set loop also satisfies the behavior and the scope fences, so the implementer may use either. Keep the existing return type.
keep because: user's request (task.md).

## Decisions taken
1. Label order follows the input (first-seen). Evidence: task.md wording; operator "go" on option a.
2. Mechanism is the implementer's choice. `dict.fromkeys` is recommended only. Evidence: both options meet the task for strings; the repo has no helper.
3. Case handling is provisional (distinct) until answered.

## Test plan
existing: `test_labels.py` (unittest) — no frozen assertions; check what is already there.
new:
- `test_labels.py::test_first_seen_order` — `["b","a","b","c","a"]` → `["b","a","c"]`. It fails sorted (`["a","b","c"]`) and last-seen (`["b","c","a"]`) implementations.
- `test_labels.py::test_empty_input` — `[]` → `[]`.
- `test_labels.py::test_case_variants_distinct` — `["a","A","a"]` → `["a","A"]`. It is provisional and labeled so.

probe: order — output is sorted instead of first-seen
probe: duplicates — the later occurrence's position is kept instead of the earlier
probe: case — comparison is case-insensitive (provisional with the assumption)

## Review axes
- attacker-controlled input: yes — the origin of `values` is unknown, so I default to yes
- hot path: no — no spec or benchmark names one
- public surface: yes — `labels` is an exported function whose behavior callers rely on

## Brief excerpts (`impl-ws1-r1.md`, identical wording)
Scope: goal and files as above.

```scope
labels.py
test_labels.py
```

Do not touch: every other file. Task-wide anti-scope: no new dependencies, no signature change, no sorting, no normalization beyond exact equality.

Verification commands:
cwd: .
- `python3 -m unittest test_labels`

`python3` availability is unchecked (`which` not run). A `check:` line is not needed for Python.

## Unresolved question (`questions.md`)
1. Should labels differing only by case (`"a"` vs `"A"`) count as distinct?
   options:
     a) distinct, exact string equality
     b) same, case-insensitive dedupe
   recommended: a
   rests on: task.md "unique string labels"; no normalization is specified
   otherwise: b changes WS-1's acceptance, replaces `test_case_variants_distinct`, and requires choosing which variant is kept

## Fix log
- answer 1: first-seen order → de-conditionalized in Spec and Decisions taken; no behavior change, since task.md already required it.
- `dict.fromkeys` recommendation → kept in Reuse and scope as non-binding.
- case question → still open; assumption labeled.

**Next step:** the coordinator relays question 1 to the user. Dispatch the brief only after that answer, or proceed on the labeled provisional assumption if the user approves.

```
PLAN_FIXED fixed=1 new_paths=no
```