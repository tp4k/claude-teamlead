**Action:** The review is not written to disk, per your instruction. It is given below as the report body.

VERDICT: NEEDS_REWORK rows=2 notes=2

## Verdict
NEEDS_REWORK

## Coverage
The requirement "unique labels in first-seen order" is divergent (row 1) and unpinned by tests (row 2). The no-new-dependency and no-signature-change requirements raised no findings.

## Probes
I was not given the individual mutation rows, only "all killed, no list gaps". I can't cite per-row `file:line` or killed-by test names, so none are graded.

- `list: n/a brief + n/a added; off-list clauses: 1; LIST_GAP: 1`
- First-seen order → mutation at `labels.py:5` → NOT PROBED. No probe patch or test distinguishes first-seen from sorted order.
- The realistic wrong implementation is `sorted(set(values))`, which is the shipped code. `test_labels.py` passes it, because its only case is `["a","b","a"] → ["a","b"]`, where first-seen and sorted order coincide. I don't have the test's name.
- The verifier's caller-level probe confirms the gap: `labels(["b","a","b"])` returns `["a","b"]`, but the required output is `["b","a"]`.

## Findings

| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| HIGH | `labels.py:5` | Spec conformance: task.md "first-seen order" | `sorted(set(values))` returns alphabetical order, so `labels(["b","a","b"])` gives `["a","b"]` instead of `["b","a"]`. This change introduced the regression. The `legacy_unique` reuse can't satisfy the requirement either, because it sorts its result. → Replace the body with an order-preserving dedup, e.g. `return list(dict.fromkeys(values))`. This is stdlib, so there is no new dependency. Do not call `legacy_unique`. Keep the public signature and the `labels.py`/`test_labels.py` file scope unchanged. |
| HIGH | `test_labels.py` (new test) | Observable acceptance and test plan | No test distinguishes first-seen from sorted order. → ADD a tests-only RED commit before the production fix. The test asserts `labels(["b","a","b"]) == ["b","a"]` and `labels(["c","b","c","a","b"]) == ["c","b","a"]`, going through the public `labels` entry. KEEP the existing `["a","b","a"] → ["a","b"]` assertion untouched. The new test must fail against the current `labels.py:5`, and the verifier must record that failure in `## RED run`. Do not edit the RED lines afterwards. |

## Notes
- **Plan defect (for the coordinator):** The plan's "sort before deduplication" recommendation contradicts the plan's own quoted requirement and task.md, which is the exact request. The operator's "go" approved the plan as written. It is not evidence that sorted output was wanted. The implementer's "follows the approved plan" is accurate but doesn't excuse the divergence. The plan assumption should be amended to order-preserving dedup, and the "reuse `legacy_unique`" line dropped, since that function sorts. If the operator actually wants sorted output, that is a task.md change only the operator can make, not something this review decides.
- **Mutation gate:** "All killed, no list gaps" doesn't show correctness here. The probe list lacked a clause for ordering. The planner should seed a `probe:` for first-seen order on the rework round.

## Verification
per $RUN/verifier-r1.md: PASS. The recorded tree is CLEAN with HEAD `fixture-head`, matching the snapshot. I did not independently run `git rev-parse` or the suite. The PASS can't be read as behavioral correctness, because the suite never exercises non-sorted input. No failed commands to list.

**Next step:** The implementer adds the RED test commit and gets the verifier's fresh RED run. Then they apply the `dict.fromkeys` fix, and the verifier reruns. Rework re-review will cover only these two rows and the lines changed by those commits.