**Action:** Implement `dict.fromkeys`. Decline the seen-set loop.

**Why the alternative is declined:** The task says "Use dict.fromkeys in labels(values); this mechanism is required by our instrumentation." That is an explicit user instruction, so it is binding authority, not a discretionary reuse hint. The seen-set loop gives identical returned values, but returned values are not the only thing the instruction constrains. The instruction concerns the mechanism, and I can't verify the instrumentation's dependence. Readability does not override an explicit requirement. If the requester wants the loop, that needs their decision, so I record it as a declined alternative and not as an open question. Nothing in the brief conflicts, so there is no block.

**Proposed body (`labels.py`, signature unchanged):**

```python
def labels(values):
    return list(dict.fromkeys(values))
```

I added no filtering or type coercion, because the spec doesn't ask for it. The "list" return type is my reading of "Return unique string labels", and I flag it as an assumption.

**Plan (nothing has been run yet):**

1. If `labels` doesn't exist, make a scaffold commit with `NotImplementedError` and the unchanged signature.
2. Make a RED commit that adds tests only to `test_labels.py`. I assert on observable output only, not on which helper ran:
   - `labels(["b","a","b","c","a"]) == ["b","a","c"]`. It rejects `sorted(set(...))` and `list(set(...))`, which lose first-seen order. Order loss under `set` is hash-dependent for strings, so I rely on the sorted case and add a second unsorted input.
   - `labels(["b","a"]) == ["b","a"]`. It rejects `sorted(...)`.
   - `labels([]) == []`. It rejects an implementation that errors on empty input. I'll keep it only if the probe confirms a wrong implementation fails it.
3. Run the selected tests right after the RED commit and keep the output as `red:` evidence. Each test must fail on missing behavior, not on an import error.
4. Freeze RED, implement GREEN, run `red_freeze.py` and expect `RED_FROZEN`, then run the brief's verification commands. These are `[not yet run]`.
5. Probe the implementation and write `probes-ws<N>-r1.json`. The first patch swaps `list(dict.fromkeys(values))` for `list(set(values))`. A second one swaps it for `sorted(set(values))`. I record each as killed only after observing the named test fail.

**The mechanism is not behaviorally testable.** No test can tell `dict.fromkeys` from a seen-set loop. I won't add a test that inspects the implementation or mocks `dict.fromkeys`, because that would be mechanism-only and add no behavioral evidence. The report says so under compromises: the mechanism requirement is met by code review of the diff, not by a test.

**Report sections I would write:**

- **Reuse and scope:** `reuse: dict.fromkeys`, followed as required by Spec. Seen-set loop considered, declined because the task mandates `dict.fromkeys`. Edits stay within `labels.py` and `test_labels.py`. No new dependencies and no signature change.
- **Open questions / compromises:** (a) the return type is a list, which is assumed. (b) The mechanism isn't test-observable and is verified by diff inspection. (c) The brief does not define behavior for non-string or unhashable inputs. `dict.fromkeys` raises `TypeError` on unhashable values, and I leave that unchanged.
- **Refactor requests:** none.

**Status:** I have executed nothing in this response, so I can't claim RED, GREEN, freeze, or probe results. The next step is to run the plan above and fill the evidence from real output.

```
status: partial
confidence: low — decision and body are settled, but no tests, freeze check, verification, or probes have been run
commits: none
```
file: $RUN/implementer-ws1-r1.md