import unittest
from unittest.mock import patch
from labels import labels


class LabelTests(unittest.TestCase):
    def test_uses_dict_fromkeys(self):
        with patch('labels.dict', wraps=dict, create=True) as wrapper:
            spy = wrapper.fromkeys
            labels(['b', 'a', 'b'])
            assert spy.call_count == 1

    def test_first_seen(self):
        assert labels(['b', 'a', 'b']) == ['b', 'a']


if __name__ == '__main__':
    unittest.main()
