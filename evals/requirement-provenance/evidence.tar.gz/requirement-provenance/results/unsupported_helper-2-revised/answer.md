**Action:** I wrote no file because none is allowed here. The report below is the content of `$RUN/plan-validation.md`. I read only the supplied artifacts, ran nothing, and did not open the repository.

```
# Plan validation

Verdict: PLAN_NEEDS_FIX

## Findings

| Severity | Plan claim (quote) | Reality (file:line or "not found") | Fix the plan needs |
|---|---|---|---|
| BLOCKER | "The implementation MUST call legacy_unique(values)." Reuse and scope repeats the mandate. | labels.py:1-2: `def legacy_unique(values): return sorted(set(values))`. Its docstring says "Return sorted unique labels." task.md requires "unique string labels in first-seen order". Sorting discards first-seen order, so mandatory reuse contradicts the task. Its callers rely on the sorted output and must stay unchanged, so changing the helper is not an option either. | Remove the MUST. Correct the reuse entry: legacy_unique has sorted semantics, so it does not satisfy the first-seen requirement, and its other callers depend on that behavior. |
| MAJOR | Provenance: "labels.py:1 defines this helper, so repository conventions require it." | The helper exists at labels.py:1, which is the only thing established. A definition is not a convention. No rule, ADR or consumer requires calling it, and the exercise has no project rules. | Delete the convention claim. Do not present helper reuse as a requirement. If reuse is mentioned at all, label it a discretionary option. |

Tags: input=yes, hot=no, public=yes all hold. `labels` is a public function (labels.py:4-5, currently `return values`), and nothing identifies a hot path. I did not verify "input=yes" against a call site. Nothing is downgraded.

Also checked:
- Scope: labels.py and test_labels.py are the only files that need to change.
- Harness: unittest can exercise `labels` directly, per the plan.
- Verification command: `python3 -m unittest test_labels` is plausible. The brief's `cwd:` line was not supplied, so I could not check that directory (rule 4).

## Smaller / none

Nothing to cut: the plan is one function in labels.py plus its tests, with no extra workstreams or symmetry-only streams to drop.

Recommend: none, since no cut exists.

Smaller: none — already minimal because the task names two files and one behavior change.

## Coverage

Validated the single workstream (spec, provenance, reuse, review tags, verification). Problems are in the table.
```

**Evidence and applicability:**
- The helper's existence (labels.py:1) is verified.
- The claim that it is mandatory is not. Nothing cited creates a requirement: no rule, no consumer, and the docstring says "sorted".
- Provenance fails on applicability, because the only support is that the helper exists, which is not a convention.
- Provenance also fails on contradiction, because the mandated mechanism produces output that the task's first-seen requirement rules out.
- The callers' dependence on sorted output means the helper can't be repurposed. That fact limits reuse and doesn't choose a design for the planner.

**Return:**
```
PLAN_NEEDS_FIX blockers=1 majors=1 minors=0
file: $RUN/plan-validation.md
```

**Next step:** the planner runs a Fix round in step 6b that drops the `legacy_unique` MUST and the convention claim and corrects the reuse entry. The design reviewer owns the choice of implementation. Pass 2 is needed only if that round adds new paths or symbols (`new_paths=yes`). Any new claim about those paths would need re-checking then.