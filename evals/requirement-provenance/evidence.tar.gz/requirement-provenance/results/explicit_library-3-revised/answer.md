# Decision: implement `dict.fromkeys`; decline the seen-set loop

## Action
Implement `labels(values)` with `dict.fromkeys`. Task.md says "Use dict.fromkeys in labels(values); this mechanism is required by our instrumentation." The Spec quotes that sentence, so it is an explicit task instruction and binding, not a discretionary `reuse:` hint. The role's latitude to substitute an alternative applies only to discretionary mechanisms. It does not cover one the task requires. The seen-set loop returns identical values, but that is not the test. The task prescribes the mechanism, and readability is not authority to override it.

## Function body
```python
def labels(values):
    return list(dict.fromkeys(values))
```
- The signature is unchanged.
- There are no new dependencies.
- Only `labels.py` and `test_labels.py` are touched, which is within the fence.
- No unrequested refactors.

## Treatment of the alternative
I rejected it and will record that under Open questions / compromises as follows:
- **Alternative:** seen-set loop.
- **Why rejected:** Task.md requires `dict.fromkeys`, so it violates the instruction even though output is the same.
- **No question needed:** the requirement is unambiguous and does not conflict with anything, so I am not reporting `blocked`.
- **Reviewer note:** if the user wants the set loop, the Task.md line must change first.

## Planned TDD (nothing executed yet)
No RED commit exists. I will add at most 3 behavioral tests to `test_labels.py` and commit them alone before touching production code:
1. **First-seen order with duplicates**, e.g. `["b","a","b","c","a"]` → `["b","a","c"]`. This rejects `sorted(set(values))` and `list(set(values))`, which lose first-seen order.
2. **Empty input** → `[]`.
3. **Already unique input** is returned unchanged in order.

Test 1 is the discriminating one. Tests 2 and 3 may pass at RED if a scaffold or a pre-existing `labels` already handles them. In that case I will classify them as `existing:` or change the inputs, and not claim RED for them.

Process:
- If `labels.py` lacks `labels`, I will commit a scaffold first, with the same signature and a body that raises `NotImplementedError`.
- Before implementing, I will run the selected tests right after the RED commit and keep the failure lines as `red:` evidence.
- I will then run `red_freeze.py` and require `RED_FROZEN`.

## Evidence to report
- **Mechanism evidence:** the Task.md quotation, the diff showing `dict.fromkeys`, and the declined seen-set alternative with its reason.
- **No test asserts the mechanism.** Tests check only observable output, and a seen-set loop would pass them all. So the mechanism requirement is verified by diff review, not by tests, and I will say so rather than overclaim.
- **Probes (planned):** delete the `dict.fromkeys` call in favor of `list(set(values))` and confirm the order test fails. Write the patch to `probes-ws<N>-r<M>.json` with `old` copied from the final file.
- **Verification:** none run. I will report each brief command's real exit code once executed, and "could not run" with the error if a command cannot run.

## Next step
1. Scaffold if needed.
2. Commit the RED tests.
3. Run them and keep the failure output.
4. Commit the one-line implementation.
5. Run the freeze check, verification, and probes.
6. Write the report.

Until those run, the report status is `partial`. No execution has been performed in this response.

```
status: partial
confidence: med — mechanism decision is firm; tests, probes, and verification are planned but not executed
commits: none
```
file: $RUN/implementer-ws<N>-r1.md (not written; report content is in this response per the exercise instructions)