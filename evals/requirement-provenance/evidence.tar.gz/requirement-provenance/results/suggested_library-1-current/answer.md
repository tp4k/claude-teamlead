**Action:** Planner Fix mode. Nothing was written to files or executed. I haven't seen `labels.py`, so the return type below comes from the task text only. Tests are unverified.

## What "go" settles
- **Settled:** Question 1, "first-seen order (a)". The task already says "first-seen order", so `go` accepts a recommendation the plan already stated.
- **Not settled:** the case-variant question. `go` answered the offered question only, so it isn't evidence for case handling.
- Log: `answer 1: first-seen order → no plan change; already covered by task.md and the draft`.

## Corrected plan sections

### Spec excerpt
task.md (verbatim task): "Return unique string labels in first-seen order. No new dependencies or public signature changes."

### Reuse and scope
reuse: none found — searched `labels.py` and `test_labels.py`; no deduplication helper exists. Extend `labels()` in place with stdlib `dict.fromkeys`.
keep because: user's request (deduplicate labels in first-seen order).

### Decisions taken
- **Order = first-seen** (user answer `go` to option a). Evidence: task.md.
- **Mechanism = `dict.fromkeys`**, not a seen-set loop. Both meet the task for strings.
  - Dict insertion order is guaranteed, and a duplicate key keeps its first position.
  - The draft's only stated reason was "concise". The mechanism choice is a judgment call with no further evidence.
  - The return type must not change: if `labels()` currently returns a list, return `list(dict.fromkeys(values))`. The implementer confirms the existing type; I did not.
- **Case variants distinct (exact string equality): provisional, not user-confirmed.**
  - Evidence: the literal wording "unique string labels" and Python `str` equality.
  - Case-folding would be behavior the task never states, and it would choose which casing to emit.
  - It stays open as the question below. The brief pins only the provisional reading.

## Brief excerpts (WS-1 — Deduplicate labels, round 1)

Scope: edit only these two files.
```scope
labels.py
test_labels.py
```

Test plan:
- existing: `test_labels.py` (unittest). I haven't read it, so the implementer checks it for relevant cases.
- new:
  - `test_labels.py::test_first_seen_order` — `["b","a","b","c","a"]` → `["b","a","c"]`. This distinguishes sorted output and last-seen order, which would give `["b","c","a"]`.
  - `test_labels.py::test_empty_input` — `[]` → `[]`.
  - `test_labels.py::test_case_variants_distinct` — `["a","A","a"]` → `["a","A"]`. This pins the provisional case decision.
- probe: first-seen order — later duplicate's position wins instead of the first.
- probe: output order — result is sorted alphabetically (rejected option b).
- probe: duplicates — only adjacent duplicates are removed.
- probe: case — comparison is case-folded.
- probe: empty input — returns something other than an empty result.

Do not touch: everything except the two files above. Task-wide anti-scope:
- no sorting
- no normalization
- no new helper or dependency
- no signature change
- no behavior beyond the task

Project forbiddens: none supplied.

Verification:
- `python3 -m unittest test_labels`
- Run from the repo root. `python3` availability is unchecked (`which` not run).
- Python-only, so no `check:` line.

Report file: `$RUN/implementer-ws1-r1.md`

Review axes:
- attacker-controlled input: yes — uncertain where values come from; unhashable items would raise `TypeError`.
- hot path: no — no spec or benchmark names one.
- public surface: yes — `labels` may have outside callers; uncertain.

## Open question (unresolved assumption)
1. Should labels differing only by letter case, such as "a" and "A", count as distinct?
   options:
     a) distinct, exact string equality
     b) same, case-insensitive match
   recommended: a
   rests on: task.md — "unique string labels"; no normalization is specified.
   otherwise: b changes WS-1's `test_case_variants_distinct` and drops `dict.fromkeys`. It also requires a decision on which casing is emitted.

## Fix log
- answer 1: first-seen order → no plan change
- Unresolved case assumption → labeled provisional; routed to `questions.md`
- Mechanism rationale → replaced "concise" with ordering evidence

`PLAN_FIXED fixed=1 new_paths=no`

## Next step
Coordinator relays question 1 and sends the plan to the implementer. If the user picks b, one more Fix round.