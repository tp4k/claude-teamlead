## Review (code axis), round 1

**Verdict: NEEDS_REWORK**

**Coverage:** `labels.py` meets the behavioral spec: unique strings in first-seen order, same signature, no new dependencies, and only in-scope files. The failures are in the table below. I did not check `dict.fromkeys` conformance because the only authority for it is a recommendation.

### Probes
`list: 0 brief + 0 added; off-list clauses: 1; LIST_GAP: 0`

- First-seen dedupe guard, `if value not in seen` at `labels.py:5`: NOT PROBED. The verifier skipped mutation because the suite failed, and no mutation report or `probes-ws` file was supplied. By reading the tests, `test_labels::LabelTests::test_first_seen` would fail on three wrong implementations: no dedupe, `sorted(set(...))`, and last-seen order. That is a reading, not a probe result.

### Findings

| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| HIGH | `test_labels.py:8-11` (`test_uses_dict_fromkeys`, `assert spy.call_count == 1`) | Frozen RED asserts a discretionary mechanism | The test requires `dict.fromkeys`. The only authority for it is the brief's "recommended because concise". `task.md` requires unique first-seen labels, not a mechanism, and the `go` approval covered the behavioral plan. `labels.py` is a valid alternative within scope, and it fails the suite (verifier `.F`, exit 1). **Fix:** the next implementation attempt may change these frozen lines, paired with `RED_CHANGED` evidence citing this finding. Remove the `patch('labels.dict', …)` spy and the `call_count` assertion. Replace the test with behavioral assertions, such as `labels(['a','a','a']) == ['a']` and `labels([]) == []`. KEEP `test_first_seen` and its `== ['b','a']` assertion (line 14) unchanged. Do NOT change `labels.py` to satisfy the mechanism test. |
| MEDIUM | Verifier evidence (`tree:`, mutation) | Missing or mismatched evidence | The verifier recorded `tree:` as empty, not `CLEAN`, so a clean tree at `head: 89678d9c…` is not established. I cannot confirm that SHA against `git rev-parse HEAD` or `git status` in this exercise, and I did not invent a check. Mutation did not run, so there is no mutation report. **Fix:** request a fresh verification after rework with `tree: CLEAN`, the `head:` SHA, a passing suite, and a mutation report. The implementer must provide a probe patch that deletes the `if value not in seen` guard, and the report must show it killed by `test_first_seen`. |

### Notes
- Non-string input handling is unresolved in the brief. It is out of scope and not a defect.
- The RED run is valid: `test_first_seen` failed on behavior before implementation, not on import or syntax errors.
- `red_freeze.py` reported `RED_FROZEN` (13 lines). That is expected until the authorized change above, and then `RED_CHANGED` evidence must reference the HIGH finding.

### Verification
per verifier-r1: FAIL. `test_uses_dict_fromkeys` failed at `test_labels.py:11`. Freeze check: `RED_FROZEN`. I ran no commands myself.

### Next step
The implementer makes the test-only rework above and leaves `labels.py` as is. Then triage requests fresh verification: suite, clean tree, and mutation.

```
VERDICT: NEEDS_REWORK rows=2 notes=3
file: review-r1-code.md
```