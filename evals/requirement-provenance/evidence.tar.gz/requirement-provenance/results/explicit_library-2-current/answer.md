## Decision

Implement `dict.fromkeys`. Do not use the seen-set loop.

The spec says "Use dict.fromkeys in labels(values); this mechanism is required by our instrumentation", and the brief's `reuse:` line names it. The seen-set loop returns identical values, but it replaces a mechanism the spec requires. A reviewer's or proposer's suggested mechanism is only a hypothesis, and here it contradicts the quoted spec. No new evidence shows the requirement is wrong, so I decline the alternative. I record it under Open questions so the coordinator can overrule the requirement if readability matters more.

## Proposed body

```python
def labels(values):
    return list(dict.fromkeys(values))
```

Keep the existing signature, annotations and return type unchanged. I have not seen `labels.py`. If it already declares a different return type, preserve it. If the return type is undeclared and ambiguous, report that as an Open question instead of guessing.

## TDD plan (nothing executed yet)

1. If `labels.py` lacks `labels`, commit a scaffold first. It contains only the existing signature, with a body that raises `NotImplementedError`.
2. Add the RED test in `test_labels.py`: `labels(["b","a","b","c","a"]) == ["b","a","c"]`.
   - It rejects no deduplication (returns the input unchanged).
   - It rejects `sorted(set(...))` (gives `a,b,c`).
   - It rejects `set(values)` ordering.
   - It asserts the returned value only. It does not assert that `dict.fromkeys` ran, since that is not observable behavior.
3. Run only that test and confirm a behavioral failure, such as `expected ['b','a','c'], got [...]`. A missing-module or import error does not count as RED.
4. Commit the test alone and freeze it. While HEAD is still that commit, rerun the test and keep the output as `red:` evidence.
5. Implement the body above, then run the targeted test and the brief's Verification commands.
6. Run `red_freeze.py` against the RED hash and expect `RED_FROZEN`.

An optional second test, for an empty input returning `[]`, is warranted only if it rejects an identifiable wrong implementation. Otherwise omit it.

## Probes

Planned and not yet run. Each needs an observed result before I claim `killed by`.
- Replace `dict.fromkeys(values)` with `values`. Expected to be killed by the order/dedup test.
- Replace it with `sorted(dict.fromkeys(values))`. Expected to be killed by the same test.

Both will be written to `$RUN/probes-ws<N>-r1.json` using the exact HEAD text for `old`. Each probe will be undone manually, never with git checkout or restore.

## Evidence for the mechanism

Since no test can observe the mechanism, I will report a grep of `labels.py` showing `dict.fromkeys` in the final tree. I will also quote the diff line and cite the Spec line it satisfies.

## Environment caveat

The working directory is not a git repository. Commits, `red_freeze.py` and `git status` checks therefore cannot run as written. I will report them as "could not run" with the error, not as passed. I will not invent hashes.

## Open questions

- The seen-set loop was proposed as equivalent and more readable. It was declined because the spec mandates `dict.fromkeys`. If the user wants to drop that requirement, the coordinator must amend the spec.
- The return type of `labels` is not visible to me and needs confirming against the existing file.

```
status: partial
confidence: low — plan and decision only; no code was written, no tests were run, and the repository is not under git
commits: none
```
file: $RUN/implementer-ws<N>-r1.md