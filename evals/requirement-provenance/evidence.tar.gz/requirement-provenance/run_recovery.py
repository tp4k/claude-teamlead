from pathlib import Path
import concurrent.futures, hashlib, json, os, re, subprocess
from run_trials import ROOT, invoke
FIX=json.loads((ROOT/'recovery-fixture.json').read_text())
for name,digest in json.loads((ROOT/'recovery-manifest.json').read_text()).items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
REPO=Path('/Users/g.evdokimov/.claude/skills/teamlead')
ENV=dict(os.environ,GIT_AUTHOR_NAME='Evaluation',GIT_AUTHOR_EMAIL='eval@example.test',GIT_COMMITTER_NAME='Evaluation',GIT_COMMITTER_EMAIL='eval@example.test')

def run(cwd,*cmd):
    p=subprocess.run(cmd,cwd=cwd,env=ENV,text=True,capture_output=True)
    return {'command':list(cmd),'exit_code':p.returncode,'output':p.stdout+p.stderr}

def recover(version):
    root=ROOT/'recovery'/version
    repo=root/'repo';repo.mkdir(parents=True,exist_ok=False)
    run(repo,'git','init','-q')
    (repo/'labels.py').write_text(FIX['red_source'])
    run(repo,'git','add','labels.py');run(repo,'git','commit','-qm','Scaffold')
    (repo/'test_labels.py').write_text(FIX['tests'])
    run(repo,'git','add','test_labels.py');run(repo,'git','commit','-qm','RED tests')
    red=run(repo,'git','rev-parse','HEAD')['output'].strip()
    initial_red=run(repo,'python3','-B','-m','unittest','test_labels')
    (repo/'labels.py').write_text(FIX['source'])
    run(repo,'git','add','labels.py');run(repo,'git','commit','-qm','Implement first-seen labels')
    before=run(repo,'git','rev-parse','HEAD')['output'].strip()
    initial_verifier={'head':before,'tree':run(repo,'git','status','--porcelain')['output'], 'test':run(repo,'python3','-B','-m','unittest','test_labels'),'freeze':run(repo,'python3',str(REPO/'scripts/red_freeze.py'),'--repo',str(repo),red),'red_run':initial_red,'mutation':'Not executed: the suite fails at the mechanism assertion.'}
    data={'task.md':FIX['task'],'brief Spec':FIX['spec'],'brief Reuse and scope':FIX['reuse'],'scope':['labels.py','test_labels.py'],'labels.py':FIX['source'],'test_labels.py':FIX['tests'],'RED hash':red,'verifier':initial_verifier}
    (root/'initial.json').write_text(json.dumps(data,indent=2))
    history=[]
    for i,stage in enumerate(FIX['stages'],1):
        prompt='Recovery exercise artifacts:\n'+json.dumps(data,indent=2)+'\n\n'
        prompt+='\n\n'.join(history)+'\n\n'+stage['request']
        ident=f'recovery-{version}-{i}-{stage["role"]}'
        status=invoke(version,stage['role'],prompt,ident)
        answerpath=ROOT/'results'/ident/'answer.md'
        answer=answerpath.read_text() if answerpath.exists() else '[NO RESPONSE]'
        history.append(f'Stage {i}, {stage["role"]}, actual response:\n{answer}')
        if i==3:
            edits=[]
            for match in re.finditer(r'```python\s*\n(.*?)```',answer,re.S):
                context=answer[max(0,match.start()-300):match.start()]
                names=list(re.finditer(r'(?<![\w/])(test_labels\.py|labels\.py)(?!\w)',context))
                if not names:
                    edits.append({'rejected':'No exact filename before code block'})
                    continue
                name=names[-1].group(1)
                code=match.group(1)
                # Require a complete Python file, not a patch or prose.
                try:
                    compile(code,name,'exec')
                except SyntaxError as e:
                    edits.append({'rejected':str(e),'file':name});continue
                (repo/name).write_text(code)
                edits.append({'file':name,'sha256':hashlib.sha256(code.encode()).hexdigest()})
            run(repo,'git','add','labels.py','test_labels.py');run(repo,'git','commit','-qm','Apply agent recovery')
            evidence={'applied':edits,'tests':run(repo,'python3','-B','-m','unittest','test_labels'),'diff':run(repo,'git','diff',before),'freeze':run(repo,'python3',str(REPO/'scripts/red_freeze.py'),'--repo',str(repo),red),'valid_assertion_preserved':"assert labels(['b', 'a', 'b']) == ['b', 'a']" in (repo/'test_labels.py').read_text()}
            evidence['head']=run(repo,'git','rev-parse','HEAD')['output'].strip()
            evidence['tree']=run(repo,'git','status','--porcelain')['output']
            data['round2_actual_evidence']=evidence
            data['round2_labels.py']=(repo/'labels.py').read_text()
            data['round2_test_labels.py']=(repo/'test_labels.py').read_text()
            (root/'rework-evidence.json').write_text(json.dumps(evidence,indent=2))
    (root/'history.md').write_text('\n\n'.join(history))

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(recover,['current','revised']))
