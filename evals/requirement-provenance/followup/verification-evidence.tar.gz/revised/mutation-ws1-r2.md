| file | line | op / probe | result |
|---|---|---|---|
| labels.py | 5 | added: dedupe guard (delete `if value not in seen`) | KILLED |

MUTATION: PASS killed=1 survived=0 invalid=0 unclassified=0 not_run=0 not_applied=0
