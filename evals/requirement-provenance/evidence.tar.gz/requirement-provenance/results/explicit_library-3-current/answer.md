# Implementer report (WS-1, round 1): plan and decision, nothing executed

## Summary
I will implement `labels(values)` with `dict.fromkeys`, as the Spec requires. I decline the seen-set loop. Both return the same values, but the Spec names the mechanism as required by instrumentation. Readability is not a ground for overriding it, and the "easy to read" argument is a hypothesis, not a spec change. I have not run or written anything yet, and no tools were available.

## Decision and function body
```python
def labels(values):
    return list(dict.fromkeys(values))
```
- This matches `reuse: dict.fromkeys`.
- It adds no new helper, dependency, or signature change.
- Edits stay within `labels.py` and `test_labels.py`.
- It does not coerce to `str`, since the Spec doesn't ask for that.

## Treatment of the alternative
The seen-set loop is not implemented. A test cannot tell the two apart, because only the returned values are observable. I will not assert which mechanism ran. The mechanism requirement is therefore checked by diff and probe review, not by a test. If the user wants the loop, they must amend the Spec.

## Planned TDD (not yet done)
- Check first whether `labels` already exists. If the function or module is missing, commit a scaffold first. It would have only `def labels(values)` raising `NotImplementedError`, matching the existing signature.
- RED test, committed alone before production code:
  - `test_labels.py::test_labels_unique_first_seen_order` asserts `labels(["b","a","b","c","a"]) == ["b","a","c"]`.
  - It rejects `sorted(set(values))`, `list(set(values))` (arbitrary order), and last-seen-wins ordering.
  - Its `red:` line must be a behavioral failure (an assertion mismatch, or `NotImplementedError` if scaffolded), captured right after the RED commit.
- A second test is only warranted if it rejects a distinct wrong implementation, such as returning duplicates for an empty or all-equal input. I expect 1–2 tests in total.
- After GREEN, run `red_freeze.py` and require `RED_FROZEN`.

## Planned probes
Probes file: `$RUN/probes-ws1-r1.json`, with one patch:
```json
[{"probe": "unique first-seen order", "file": "labels.py",
  "old": "return list(dict.fromkeys(values))",
  "new": "return sorted(set(values))"}]
```
- Expected to be killed by `test_labels.py::test_labels_unique_first_seen_order`. This is a prediction, not an observation. It must be run before `rejects:` is claimed.
- Confirm `old` occurs exactly once in `labels.py` at HEAD after the last commit.
- Undo the probe edit manually and confirm the working tree matches its pre-probe state.

## Evidence to report at `done`
- Commit hashes for the scaffold (if any), RED, and GREEN.
- The `red:` failure line from the run right after the RED commit.
- The `RED_FROZEN` output.
- The brief's verification commands with exit codes. I don't have their text, so they are not listed here.
- Probe outcomes marked `killed by` with the test name copied from runner output.

## Open questions / compromises
- The brief does not state the existing return type or signature. I assume `list`, because "return unique labels in order" implies a sequence. I must confirm this against the current `labels.py` before writing code. If callers expect another type, I will stop and ask.
- Non-string or unhashable inputs are unspecified. I add no handling, and `dict.fromkeys` raises `TypeError` on unhashables.
- The seen-set proposal is declined as described above. It is a Spec amendment for the coordinator or user, not for me.

## Refactor requests
none

```
status: partial
confidence: low — decision and plan only; no code written, no tests or verification run, and the existing signature and return type are unchecked
commits: none
```
file: $RUN/implementer-ws1-r1.md