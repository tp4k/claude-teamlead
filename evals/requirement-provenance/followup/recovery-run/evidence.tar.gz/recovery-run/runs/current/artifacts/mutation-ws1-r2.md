| file | line | op / probe | result |
|---|---|---|---|
| labels.py | 2 | added: dedupe via dict.fromkeys (finding ws1-r1-row1) - wrong implementation skips dict.fromkeys and returns the input unchanged | KILLED |
| labels.py | 2 | added: first-seen order preserved - wrong implementation still calls dict.fromkeys but sorts the input first | KILLED |

MUTATION: PASS killed=2 survived=0 invalid=0 unclassified=0 not_run=0 not_applied=0
