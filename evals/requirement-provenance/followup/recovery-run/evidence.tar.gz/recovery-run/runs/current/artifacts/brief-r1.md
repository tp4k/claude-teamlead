## Spec
Authority: task.md explicit user instruction, applies to labels(values). Return unique labels in first-seen order. Assumption: handling non-string inputs unresolved; this work only covers strings.

## Reuse and scope
reuse: dict.fromkeys — recommended because concise. General go approved the behavioral plan. keep because: task.md requires unique labels.

## Scope
```scope
labels.py
test_labels.py
```
