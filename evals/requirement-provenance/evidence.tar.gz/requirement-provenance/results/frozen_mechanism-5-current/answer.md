# Rework r2: plan and report excerpts

**Nothing has been executed.** This is the plan and the report skeleton. Hashes, outputs and the status line get filled in only from real runs.

## Decision

I will edit the frozen assertion `assert spy.call_count == 1` in `test_uses_dict_fromkeys`. The freeze rule allows this only when a finding explicitly names the test as wrong, and R1 HIGH does that. It cites the test and the assertion, and finds that no task, rule, ADR or caller contract requires the helper call. `test_first_seen` stays untouched.

I do not treat the `dict.fromkeys` recommendation in Reuse and scope as a behavior requirement. The spec says only "unique labels in first-seen order". The assertion checks the mechanism, not the output.

## Next actions

1. Read `labels.py`, `test_labels.py`, the R1 finding, the triage and the r1 report.
2. Replace `test_uses_dict_fromkeys` with a behavioral duplicate-output test, in `test_labels.py` only. For example, `labels(["a","a","a"]) == ["a"]` and a non-adjacent repeat with several duplicates.
   - It rejects a dedupe that drops only one repeat, or only non-adjacent repeats. `test_first_seen` alone passes both. A probe must confirm this before I write `rejects:`.
   - Do not touch `test_first_seen`.
3. Commit the test change alone, before any production edit. Only the findings row may change, so I make no production change. The loop already meets the spec.
4. Run the targeted tests, then the brief's Verification commands from its stated working directory.
5. Run `red_freeze.py --repo <repo> <r1-red-hash>` with every RED hash.
   - Expect `RED_CHANGED` listing only the removed `spy.call_count == 1` line, reported beside the R1 row.
   - If `test_first_seen`'s line appears, I stop and fix it.
6. Self-probe: read the exact loop text from `labels.py` and write `probes-ws<N>-r2.json`. Mutate the dedupe branch, confirm each `old` occurs once, run the named test, then undo the edit by hand. Never commit a probe.

## What may change

- `test_labels.py`: only `test_uses_dict_fromkeys`, replaced with behavioral coverage.
- `labels.py`: nothing.
- No public signature, dependency or other file changes.

## Report excerpts (to fill from real runs)

```
tdd: APPLIED
red: <r1-red-hash>
new: test_labels.py::<new_name> — repeated labels appear once, first-seen order — rejects: <confirmed by probe | unprobed — why> — red: n/a — behaviour already present
existing: test_first_seen — still green (unchanged)
extra: none
freeze: RED_CHANGED — removed `assert spy.call_count == 1` (test_uses_dict_fromkeys); authorized by R1 HIGH finding row 1: the assertion checks a helper call, which no spec, rule or caller requires. Callers see only the output, and that contract is covered by the new test.
```

Open questions:
- The Reuse line recommends `dict.fromkeys`, but production uses an equivalent seen-set loop. I am not changing it, because the findings row does not ask for it. Switching is in scope, if the coordinator wants it.
- The r1 RED turned a reuse recommendation into a mechanism assertion. That is a planning defect.

Routing: the final `status:` line stays absent until the verification, freeze and probe results are real. If any of them cannot run, I report "could not run".

## Same edit before R1?

No. Before R1, the assertion was frozen and my own opinion was not a finding. I would have left it in place and reported it under Open questions with the evidence: production behavior is correct, the test enforces the mechanism, and the spec doesn't require it. I would not have returned `done` with a knowingly failing frozen test. The edit is authorized now because R1 explicitly names the test, and triage adopted that finding for this round.