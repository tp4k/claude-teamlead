**Action:** Treat this as a spec conflict, not an implementation defect. The implementer correctly followed task.md, so rework would not fix the implementer's work. But task.md contradicts the active published contract (api-v1.md #Labels), and the user hasn't authorized a revision or been told about the conflict.

Both of the reviewer's suggestions are handled as follows:
- **Silently revising the contract:** rejected. That is an unauthorized scope change.
- **Keeping the sorting:** adopted as the `recommended:` choice. It is reversible, and the user can veto it in the final report.

The run does not stop under autopilot. The conflict is logged as a decision, and the Notes for the user lead with it.

I am not claiming any test execution. The clean PASS verified the first-seen behavior and says nothing about contract conformance.

## Triage (would be `$RUN/triage-r1.md`)

Verdict: NEEDS_DECISION → routes as NEEDS_REWORK, because the recommended choice needs a code change.

| Sev | Location | Req/Concern (reviewers) | Problem → Fix |
|---|---|---|---|
| HIGH | labels.py `labels()` | api-v1.md #Labels "MUST return unique labels in ascending lexical order" (code reviewer) | `["b","a","b"]` returns `["b","a"]`, violating the contract. The task's first-seen order conflicts with it. **recommended: keep unique, ascending-lexical output** — the contract is published and the version can't change, and the user hasn't authorized a revision. **Behaviour that changes:** `labels(["b","a","b"])` returns `["a","b"]`. **Pinning test:** a new `test_labels.py` test asserting that exact output. |

**Demoted to Notes**
- First-seen order for `labels()` — needs an api-v1.md revision and a version bump the user hasn't authorized, and the current release can't change its version (labels.py).

**Notes for the user**
1. **Conflict needing your call:** task.md asks for first-seen order, but api-v1.md #Labels requires ascending lexical order. The run kept the contract as its recommended choice. To get first-seen order you must authorize a contract revision and version bump, which is outside this release.
2. Security and performance approved the first-seen version. Neither checked contract conformance.

**Re-review set**
- code: re-run, always.
- security: carried. The fix changes only output ordering, with no parsing, validation or authorization change. APPROVED from the round-1 security review.
- perf: re-run. Sorting changes complexity, and the hot-path tag is not provided, so the impact is uncertain.

**Rework count:** 1 of 3 after this round.

```decision-records
[{"id":"contract-conflict-1","revision":1,"action":"decline","reason":"First-seen ordering conflicts with active api-v1.md #Labels; no authorized contract revision or version bump","evidence":"Reviewer repro: ["b","a","b"] returns ["b","a"], but the contract requires ascending lexical order"}]
```

## Rework brief (would be `$RUN/briefs/impl-ws1-r2.md`)

Inherited source: `$RUN/briefs/impl-ws1-r1.md` (scope, spec, forbiddens, verification commands). Read `$RUN/implementer-ws1-r1.md` for the previous work. No scope expansion: the fence stays `labels.py` and `test_labels.py`, and the signature and dependencies stay unchanged.

**rework cause:** planning assumption. task.md conflicts with api-v1.md. The evidence is the reviewer's repro against the contract text.

**Findings to fix**
- HIGH: `labels()` must return unique labels in ascending lexical order per api-v1.md #Labels.
- **Behaviour that changes:** `labels(["b","a","b"])` returns `["a","b"]`.
- **Pinning test:** add a new test in `test_labels.py` asserting that output.
- The contract authorizes this change. Any existing assertion in `test_labels.py` that expects first-seen order may be changed to match.
- Make no other changes. Do not edit the contract.

**Verifier output:** omitted, since verification passed.

**Test plan additions:** the ascending-unique test above.

**Report file:** `$RUN/implementer-ws1-r2.md`

```
VERDICT: NEEDS_DECISION rows=1 list_gap=0 demoted=1 notes=2 docs_only=no decisions=1 rework_brief=$RUN/briefs/impl-ws1-r2.md rereview=code,perf carried=security
file: $RUN/triage-r1.md
```

**Next step:** write the brief first, then the triage file, then dispatch the implementer for round 2. Log the `recommended:` line to `decisions-log.md` and put the conflict at the top of the final report for the user's veto.