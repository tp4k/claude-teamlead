# Rework round 2: decision and plan

## Decision
I would replace the frozen mechanism assertion, and only that one. The role file allows a frozen line to change when a finding explicitly names that test as wrong. R1 HIGH does exactly that, and I checked its claim against the spec:

- The spec and task require only "unique string labels in first-seen order".
- The `dict.fromkeys` line in Reuse and scope is a reuse recommendation, not a behavior.
- Nothing requires a particular helper to be called, so `spy.call_count == 1` pins an implementation detail.
- The seen-set loop meets the contract, and `test_first_seen` already shows it.

## Next actions
1. **Edit `test_labels.py` only.** Rewrite `test_uses_dict_fromkeys` so it asserts duplicate-output behavior and drops the spy. I would rename it to something like `test_drops_repeated_labels`, because the old name falsely claims a mechanism. The `def` line is then also a changed frozen line. I would attribute it to the same R1 row and flag it under Open questions.
2. **Use a discriminating input.** For example `labels(["a","a","a","b","a"]) == ["a","b"]`. It rejects an implementation that removes only the second occurrence, which `test_first_seen` (two `b`s at most) would pass. I would only write `rejects:` after observing that mutation fail.
3. **Leave `test_first_seen` byte-identical.** Leave `labels.py` untouched too, because R1 does not ask for a production change. Commit the test change alone, with the message in a file under `$RUN` and `git commit -F`.
4. **Run the freeze check.** Run `red_freeze.py --repo <repo> <r1-red-hash>` with no run option. Expect `RED_CHANGED` listing the assertion line and the `def` line, each followed by the R1 row. `test_first_seen` must not appear. Any other output is a defect to fix.
5. **Run targeted tests, then full verification** from the brief's directory. Then self-probe: mutate production to drop only the second duplicate, confirm the new test fails, and undo the edit manually. Write `probes-ws<N>-r2.json` with `old` text that occurs once at HEAD, and recheck it after the last commit.

## Evidence required
- No new RED commit exists this round. The replacement test should pass immediately, so I report `red: n/a — behaviour already present`, with the probe failure as its evidence.
- I do not cite the r1 failure of `test_uses_dict_fromkeys` as RED for the new test.
- The old assertion was wrong, and I would show that existing callers still meet their contract. The behavioral tests cover the loop's output and nothing in the tree depends on a call count.

## Report excerpts (placeholders until run)
```
## TDD
tdd: APPLIED
red: <r1-red-hash>
new: test_labels.py::test_drops_repeated_labels — repeated labels collapse to first occurrence — rejects: <only after probe observed> — red: n/a — behaviour already present
existing: test_first_seen — unchanged, still green (to be confirmed by run)
extra: none
freeze: RED_CHANGED (expected) — test_labels.py `assert spy.call_count == 1` → R1 HIGH row (test named erroneous: no spec/rule/ADR/caller requires the helper call); `def test_uses_dict_fromkeys` → same row (rename; name claimed a mechanism)

## Open questions / compromises
- labels.py uses a seen-set loop, not the dict.fromkeys the Reuse line recommends. R1 did not require a production change, so I left it. Coordinator: switch, or accept the loop?
- The rename also changes a frozen `def` line. Confirm the R1 row covers it.
```

## Would I have made this edit before R1 existed?
No. Without a finding naming the test as wrong, the role forbids editing, deleting or weakening frozen lines. I would have left the assertion alone and reported it under Open questions. I would have said that RED failed on a mechanism rather than behavior, and that the spec does not require `dict.fromkeys`. The coordinator would then decide whether to authorize the change. R1 supplies that authorization. My own judgement that the test is wrong does not.

```
status: partial
confidence: low — plan only; no commands run, no hashes, no freeze or probe results observed
commits: none
```
file: $RUN/implementer-ws<N>-r2.md (not written; plan provided inline per instructions)