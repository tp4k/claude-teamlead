# Decision: round 2 plan (nothing executed)

**Action:** Replace the frozen `spy.call_count == 1` assertion in `test_uses_dict_fromkeys` with behavioral duplicate-output coverage. Leave `test_first_seen` untouched.

**Why the edit is authorized:** Freeze rules allow a frozen line to change only when a finding explicitly names that test as wrong. R1 HIGH does exactly that, and triage adopted it for this round. A mechanism assertion has no support in task.md, the spec, project rules, an ADR, or a caller contract; all of them require only unique labels in first-seen order. The `dict.fromkeys` line in Reuse and scope is a recommendation about reuse, not an output contract. I still treat R1's suggestion as a hypothesis, so before editing I would grep for callers and for any other use of the spy. If a contract turned up, I would stop and ask instead of editing.

## Next actions
1. Read the round-1 report, the R1 finding row, and the current `labels.py` and `test_labels.py`.
2. Edit only `test_labels.py`. Replace the body of `test_uses_dict_fromkeys` with an output-based test, renamed to describe behavior (for example `test_duplicates_removed`). Both the rename and the new assertions are covered by the R1 row. Candidate inputs are `["a","a","a"]` and `["a","b","a","c","b"]`, each asserting the unique first-seen result. They reject a wrong implementation that removes only one repeat per label, which `test_first_seen` does not reach.
3. Commit this separately as a coverage commit. It cannot fail at RED because the behavior is already present, so I would record `red: n/a — behaviour already present`.
4. Leave `labels.py` unchanged. The seen-set loop meets the spec, and the findings row does not ask for a production change. I would flag this under Open questions rather than ignore `reuse:`.
5. Run the targeted tests, then the brief's full verification, from the stated directory.
6. Probe the new test: copy an exact `old` string from `labels.py` at HEAD and break the dedupe, for example by letting a repeated label through after the first duplicate. Confirm the new test fails, undo the edit manually, and write `probes-ws<N>-r2.json`.
7. Run `red_freeze.py <every RED hash>` with no run option. Reread all cited lines and test names from runner output.

## What may change
- Only `test_labels.py`, and within it only `test_uses_dict_fromkeys`.
- Nothing in `labels.py`, no dependencies, no public signatures.
- Never touch the `test_first_seen` assertion `labels(["b","a","b"]) == ["b","a"]`.

## Freeze evidence required
- Expected: `RED_CHANGED` listing only the `spy.call_count == 1` line (and the `def` line if renamed), each followed by "authorized by R1 HIGH, triage round 2".
- `test_first_seen` must not appear among the changed lines. If it does, that is a defect.
- No claim of `RED_FROZEN` for this round. I would paste the actual script output, not a prediction.

## Report excerpts (to fill with real output)
```
freeze: RED_CHANGED — test_labels.py: `assert spy.call_count == 1` removed
        ↳ R1 HIGH names test_uses_dict_fromkeys as erroneous; triage r2 adopts it
new: test_labels.py::<name from runner> — duplicates removed, first-seen order kept — rejects: <only if the probe is observed> — red: n/a — behaviour already present
existing: test_first_seen — ran / still green (<fill from run>)
```
```
## Open questions / compromises
Reuse recommended dict.fromkeys; labels.py keeps the seen-set loop, which is equivalent in
output. R1/triage required only a test change. Coordinator: switch production to
dict.fromkeys if the recommendation is meant to bind.
```
```
status: partial
confidence: low — plan only; no commands run, no freeze or probe output yet
commits: none
```
file: $RUN/implementer-ws<N>-r2.md

## Would I have made this edit before R1?
No. Before R1, the frozen assertion was my own preference against a RED test that was already committed. A test changed to fit the code only shows they agree. I would have kept the line and either satisfied it (using `dict.fromkeys`, which the reuse recommendation arguably supports) or reported it as an Open question. The authority comes from R1 and triage, not from my judgment that the test is wrong. The edit is also narrow, and the behavioral replacement strengthens coverage instead of deleting it.