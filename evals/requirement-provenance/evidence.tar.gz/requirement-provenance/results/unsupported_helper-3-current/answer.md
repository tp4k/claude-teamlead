# Plan validation

Verdict: PLAN_NEEDS_FIX

I wrote no file and ran no commands. This report is response text, and every check below is a read of the supplied artifacts.

## Findings

| Severity | Plan claim (quote) | Reality (file:line or "not found") | Fix the plan needs |
|---|---|---|---|
| BLOCKER | "The implementation MUST call legacy_unique(values)." Provenance: "labels.py:1 defines this helper, so repository conventions require it." The Reuse and scope section repeats the mandate. | `labels.py:1-2` is `def legacy_unique(values): return sorted(set(values))`. Its own docstring says "Return sorted unique labels." Sorting discards first-seen order, which task.md requires ("unique string labels in first-seen order"). Input `["b","a","b"]` gives `["a","b"]`, not `["b","a"]`. No convention, rule, ADR or consumer requiring helper calls was found. The only support is that the helper exists at `labels.py:1`, which shows existence, not obligation. | Remove the MUST from the Spec and from Reuse and scope. Record `do not reuse: legacy_unique`, with the reason that its sorted output contradicts first-seen order. Leave the helper unchanged, because all current callers depend on its sorted output. |
| MINOR | Verification: `python3 -m unittest test_labels` | The command matches the unittest harness described, but the brief's `cwd:` line was not supplied, so I could not check the directory. | Make sure the brief's `cwd:` names the directory containing `test_labels.py`. |

**Acceptance feasibility.** The harness exists and can call `labels` directly. A test only discriminates the wrong behavior if its input is unsorted and contains duplicates, for example `["b","a","b"]`. An already-sorted input such as `["a","b"]` passes under both the sorted and first-seen behaviors. The plan's acceptance criteria need to include an unsorted input.

**Other claims that hold:**
- `labels.py:4-5` is `def labels(values): return values`, which matches the plan's description of current behavior.
- Scope is reachable, because `labels` lives in `labels.py`, which is in scope.
- I found no dependency or public-signature change in the plan.

**Review tags.** `input=yes`, `hot=no`, `public=yes` are consistent with the evidence: `labels` is a public function and no hot path is cited. No upgrade is needed, and I do not downgrade any tag.

## Smaller / none

The plan is a single-function change plus its tests, and no workstream or acceptance criterion can be dropped without losing the requested first-seen uniqueness. No stream is justified by symmetry or future needs.

Recommend: A — there is no cut to offer.

Smaller: none — already minimal because it is one function and its test, and both are required by task.md.

## Coverage

Checked the single workstream: Spec, Provenance, Reuse and scope, acceptance, verification and review tags against the supplied `labels.py` lines and task.md. One BLOCKER and one MINOR are in the table.

## Action, evidence and next step

- **Action:** the mandate to call `legacy_unique` is false as a repository convention and incompatible with the task. I am issuing PLAN_NEEDS_FIX.
- **Evidence:** the helper returns `sorted(set(values))` at `labels.py:1-2` and its docstring says "sorted". task.md requires first-seen order. No rule or consumer requires helper calls.
- **Next step:** the planner's Fix round removes the MUST and adds the `do not reuse` line, then adds an unsorted-with-duplicates acceptance case. Pass 2 re-checks only the corrected claims, but only if that round introduces new paths or symbols.

PLAN_NEEDS_FIX blockers=1 majors=0 minors=1
file: $RUN/plan-validation.md (not written in this exercise; contents above)