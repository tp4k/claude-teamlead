## Action

Rework round 2 changes only `test_labels.py`. I would replace the mechanism assertion in `test_uses_dict_fromkeys` with behavioral coverage. I would leave `labels.py` and `test_first_seen` untouched. Nothing below has been run.

## Evidence for the edit

- A frozen line may change only when a finding explicitly names that test as wrong. R1 HIGH names `test_uses_dict_fromkeys` and `spy.call_count == 1`. Triage adopted R1.
- No task, rule, ADR, or caller contract requires the helper call. `task.md` requires only "unique string labels in first-seen order".
- The `dict.fromkeys` recommendation is discretionary. A general "go" does not make it binding.
- The seen-set loop already satisfies the behavior. It is the alternative to record in the report.
- Callers still meet their contract because the return value is unchanged. I have not searched the tree for callers. I would Grep for `labels(` first and cite the result, not claim "all callers checked".

## Next actions

1. Read the brief, the R1 finding, and the round-1 report. Grep for `labels(` callers.
2. Edit `test_labels.py` only.
   - Remove the spy setup and the `spy.call_count == 1` assertion.
   - Do not rename the test just to dodge the mechanism, since a rename is not evidence. Give it a behavioral name such as `test_no_duplicate_labels`.
   - Add a duplicate-output assertion with non-adjacent and repeated duplicates, for example `labels(["a","a","b","c","b","a"]) == ["a","b","c"]`.
   - `test_first_seen`, including `assert labels(["b", "a", "b"]) == ["b", "a"]`, stays byte-identical.
3. Commit this as a separate, forward-only commit with `git commit -F <file under $RUN>`. No amend, no reset, no checkout or restore.
4. Run only the new test. It should pass immediately because the behavior already exists. I would therefore record `red: n/a — behaviour already present` and not claim RED. Its evidence is a mutation failing it.
5. Self-probe. Temporarily delete the `if label in seen` guard in `labels.py`, run the named test, expect failure, and undo the edit with Edit. Check that `git status --short` matches its pre-probe state. Write `probes-ws<N>-r2.json` with `old` copied verbatim from HEAD and appearing exactly once. Recheck it after the last commit.
6. Run the brief's Verification commands from its stated directory. Report any that could not run as "could not run".
7. Run `red_freeze.py --repo <repo> <r1-red-hash>` with no run option.

## Freeze evidence required

I expect `RED_CHANGED`, not `RED_FROZEN`. It should list only the removed spy lines and `assert spy.call_count == 1`. Each listed line must be followed by the R1 HIGH finding row. If it lists any `test_first_seen` line, I have made a mistake.

## Report excerpts (to be filled from real output)

```
tdd: APPLIED
red: <r1-hash>
new: test_labels.py::test_no_duplicate_labels — duplicates removed, first-seen kept — rejects: unprobed until guard-deletion mutation observed — red: n/a — behaviour already present
existing: test_first_seen — unchanged, ran / still green
freeze: RED_CHANGED — <spy lines> ← R1 HIGH: mechanism-only assertion, no governing authority
```

Open questions: the R1 RED was invalid evidence for behavior. The round-1 test failed only on the helper call, because the production loop was already behaviorally correct. The reuse suggestion was discretionary, and I kept the seen-set loop.

Final routing block (placeholders until the work is done and verified):

```
status: partial
confidence: low — plan only; no edits, tests, probes, or freeze check performed
commits: none
```
file: $RUN/implementer-ws<N>-r2.md

## Would I have made this edit before R1 existed?

No. Without a finding or governing authority, I could not unilaterally change a frozen line, even a mechanism-only one. I would have kept it frozen and reported it under Open questions. The edit is authorized by R1's explicit finding and triage's adoption, not by my own view of the test. I also should not have written a mechanism-only test in round 1, because `dict.fromkeys` was a discretionary recommendation.