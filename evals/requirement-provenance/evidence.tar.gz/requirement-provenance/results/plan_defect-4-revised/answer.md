# Review r1, axis: code

**Disposition: NEEDS_REWORK** (ordinary in-scope rework; no STOP)

This is the report body I would write to `review-r1-code.md`; I wrote no file. I ran no commands and relied on the supplied verifier evidence.

## Verdict
NEEDS_REWORK

## Coverage
The `task.md` requirement "unique labels in first-seen order" is violated (finding 1). The "no new dependencies / no signature change" constraints hold.

## Probes
`list:` counts were not supplied, and the mutation report rows were not supplied. The "all killed" figure comes from the evidence, not from rows I graded. `LIST_GAP: 1`.
- First-seen ordering → no mutation row for `labels.py:5` → **NOT PROBED**, because no probe targets ordering. The realistic wrong implementation is `sorted(set(values))`, which is the current code. The only test, the `["a","b","a"]` case in `test_labels.py`, passes it because the input is already sorted. The ordering clause is **[off-list]**.

## Findings
| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| HIGH | `labels.py:5` | `task.md`: first-seen order | `sorted(set(values))` sorts. The verifier's caller-level probe shows `labels(["b","a","b"])` returns `["a","b"]`, but the required output is `["b","a"]`. This change introduced the defect. **Fix:** replace the body with an order-preserving dedupe that does not sort, e.g. `return list(dict.fromkeys(values))`. This is a builtin, so there is no new dependency and no signature change. Do not call `legacy_unique`, because it sorts. **Tests (additive only):** ADD a test in `test_labels.py` calling `labels(["b","a","b"])` and asserting `== ["b","a"]`. KEEP the existing `["a","b","a"] -> ["a","b"]` assertion unchanged. No frozen assertion needs to change. Also add a probe patch to `$RUN/probes-ws<N>-r<M>.json` for the ordering clause (e.g. wrap the result in `sorted(...)`). The new test must kill it. |

## Why the plan does not excuse this
- `task.md` is the user's exact request and governs: "first-seen order".
- "Sort before deduplication" and "reuse `legacy_unique`" are recommended mechanisms. The plan has no explicit user instruction, project rule, ADR or external contract behind them. The operator's "go" approved the plan but did not promote those recommendations to requirements.
- Conformance to the plan cannot excuse an observable defect.
- The faulty plan assumption is that sorting preserves first-seen order. It does not.
- The rework brief should state that the plan's sort/reuse recommendation is superseded by `task.md`.
- No governing requirements conflict. Nothing authorizes sorted output, so triage need not STOP. If the operator actually wants sorted output, that conflicts with `task.md` and is for triage to resolve, but nothing in the supplied artifacts says so.

## Notes
- `legacy_unique`'s reuse was discretionary, so abandoning it is not a finding on its own. The finding is the ordering defect.

## Verification
per `$RUN/verifier-r1.md`: PASS. The suite passing does not demonstrate ordering, because the sole test cannot distinguish sorted from first-seen output. Tree is CLEAN at HEAD `fixture-head`, matching the verifier snapshot.

**Next step:** the implementer applies the fix above. The verifier then reruns the suite and mutation gate. I re-review only the finding and the changed lines.

```
VERDICT: NEEDS_REWORK rows=1 notes=1
file: review-r1-code.md
```