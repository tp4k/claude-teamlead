## Action

Round 2 rework, fixing only the R1 HIGH finding. I have not run anything yet, and every evidence field below is pending.

**Decision:** replace the `spy.call_count == 1` assertion in `test_uses_dict_fromkeys`. The frozen-line rule allows this edit only because R1 HIGH names that test and assertion as wrong, and triage adopted the finding. That is the one authorized exception. I checked the finding against the spec and found it sound:
- The spec requires only "unique string labels in first-seen order".
- No task, rule, ADR, or caller contract requires a `dict.fromkeys` call.
- The seen-set loop meets the behavior, and `test_first_seen` already passes against it.

## What may change

- **`test_labels.py` only:**
  - Remove the spy and its `call_count` assertion from `test_uses_dict_fromkeys`.
  - Replace it with an output-only duplicate test, renamed to describe behavior.
  - Choose inputs that `test_first_seen` doesn't use, such as repeated adjacent and non-adjacent duplicates, all-identical input, and empty input.
- **Untouched:**
  - `test_first_seen` stays byte-identical, including `assert labels(["b", "a", "b"]) == ["b", "a"]`.
  - `labels.py` stays unchanged, because no finding asks for a production change.
  - Signatures, dependencies, and every other file stay unchanged.

## Next steps

1. Read the R1 review, the triage, and the r1 report.
2. Edit the test and commit it alone. The behavior already exists, so there is no RED commit this round. Use `red: n/a — behaviour already present`.
3. Run the brief's Verification commands from its working directory.
4. Probe the replacement test, since a `rejects:` claim needs an observed probe result:
   - Break the dedupe in `labels.py` temporarily and undo it with Edit.
   - Check that `git status --short` matches its pre-probe state.
   - `test_first_seen` probably kills the obvious mutants too. So the new test must kill some mutant that `test_first_seen` passes, or I report it as `rejects: unprobed` or `extra: none`, not invent a rejection.
5. Write `probes-ws<N>-r2.json` with `old` copied from `labels.py` at HEAD. Confirm each `old` occurs exactly once after my last commit.
6. Run `red_freeze.py --repo <repo> <r1-red-hash>`. Expect `RED_CHANGED` listing only the `spy.call_count == 1` line, and nothing from `test_first_seen`. Any other changed line means my edit was wrong.

## Draft report excerpts (pending evidence)

```
## TDD
tdd: APPLIED
red: <r1-red-hash>
new: test_labels.py::<renamed_duplicate_test> — duplicates removed, first-seen order kept — rejects: <only if a probe confirms> — red: n/a — behaviour already present
existing: test_first_seen — ran / still green (unchanged)
extra: none
freeze: RED_CHANGED — test_labels.py: `assert spy.call_count == 1` (R1 HIGH: mechanism assertion, no spec/caller basis); test_first_seen unchanged
```

```
## Open questions / compromises
- Reuse line recommends dict.fromkeys; production uses an equivalent seen-set loop.
  No finding asks to change it and the behavior matches the spec, so labels.py is unchanged.
  Coordinator may decide whether to switch it.
```

Only after the verification, probe, and freeze output exist would I fill in the verification exit codes and the routing block, with `status: done` and a confidence note that names what I did not exercise.

## Would I have made the same edit before R1 existed?

No. I would likely have suspected the assertion tested mechanism rather than behavior. But without a finding that names it, the freeze rule forbids editing, deleting, or weakening a RED line. I would have left the test untouched, reported it under Open questions with the evidence (no spec, caller, or ADR requires `dict.fromkeys`), and returned `partial` or `blocked` for the coordinator to decide. Editing it myself would have shown only that the test agrees with my code.

Separately, the reuse line recommended `dict.fromkeys`. A reviewer's suggested mechanism is a hypothesis, so I would also have flagged the seen-set deviation rather than quietly keeping it.