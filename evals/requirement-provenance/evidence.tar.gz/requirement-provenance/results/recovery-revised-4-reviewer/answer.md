## Review (code axis), round 2 re-review

**Verdict: NEEDS_REWORK**

**Coverage:** I checked only the round-1 HIGH row and the lines changed by the rework. That row is resolved. One evidence gap remains (table below).

**Recovery of the HIGH row**
- The diff against `89678d9` touches only `test_labels.py`. `labels.py` is unchanged and the scope fence holds.
- `RED_CHANGED` lists 5 of 13 frozen lines. They are exactly the five lines of `test_uses_dict_fromkeys` that my round-1 HIGH finding authorized. The other 8 frozen lines are intact. The `RED_CHANGED` result is therefore authorized, and the implementer's report cites the finding for each line.
- I read the removed lines first. Only the mechanism assertion (`spy.call_count == 1`) and its patch scaffolding were removed. Behavioral coverage is preserved. `test_first_seen` is unchanged and still asserts `['b','a','b'] → ['b','a']`, the input the removed test used.
- Provenance is preserved. `dict.fromkeys` stays a recommendation with no test requiring it. Authority for the behavior remains `task.md`, and the `go` approval was not promoted to a mechanism requirement.
- The suite passes: `python3 -B -m unittest test_labels` exited 0, 2 tests OK.

### Probes
`list: 0 brief + 1 added (inline in implementer report, no probes file); off-list clauses: 1; LIST_GAP: 0`

- Dedupe guard (delete `if value not in seen`) → mutation at `labels.py:5` → NOT PROBED. The round-2 evidence has no mutation report, and the implementer wrote no `probes-ws1-r2.json`. By reading, the patch is on target and would fail `test_labels::LabelTests::test_first_seen` and `test_labels::LabelTests::test_repeated_and_empty`. That is a reading, not a probe result.

### Findings

| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| MEDIUM | verifier-r2 evidence (`tree:`, mutation); missing `$RUN/probes-ws1-r2.json` | Missing independent evidence | The suite now passes, so the mutation gate should have run. Triage-r1 required a guard-deletion probe and a stated tree state for round 2. The supplied evidence has no mutation report. `tree:` is again an empty string rather than `CLEAN`, and the recorded `head:` is `66449dd…`. I cannot compare it with `git rev-parse HEAD` because this exercise has no repository, and I ran no commands. Acceptance of `test_repeated_and_empty` as `red: n/a — behaviour already present` depends on a mutation failing that test, which is not shown. **Fix:** no change to `labels.py` or `test_labels.py`. (1) The implementer writes the guard-deletion patch from the inline JSON into `$RUN/probes-ws1-r2.json`, with `old` being the three lines inside the `for`. (2) Request fresh verification. It must record `tree: CLEAN` with `head:` matching shared HEAD, the passing suite, and a mutation report. That report must show the guard-deletion row killed, naming the killing `file::test_name`. KEEP everything else as is. |

### Notes
- The `from unittest.mock import patch` import is now unused. The brief said to keep it, so a linter may flag it. Removing it is a separate decision.
- Non-string input handling stays unresolved and out of scope.
- The implementer's `status: partial` and `confidence: low` come from running nothing. I relied on the harness evidence, not on that report.

### Verification
per `$RUN/verifier-r2.md`: PASS for the suite (exit 0). The mutation report and `tree: CLEAN` are missing, as the row above states. I ran no commands.

**Recovery status:** the code and test content is recovered and provenance is intact. Recovery is not complete until the fresh verification shows a killed probe and a clean tree. No other defects or constraint violations remain.

**Next step:** the implementer adds the probes file, triage requests re-verification, and I confirm the mutation row.

```
VERDICT: NEEDS_REWORK rows=1 notes=3
file: review-r2-code.md
```
(Intended path. This exercise is response-only, so nothing was written to disk.)