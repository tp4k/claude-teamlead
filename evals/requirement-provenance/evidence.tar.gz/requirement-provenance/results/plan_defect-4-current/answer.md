# Review r1, axis: code (report text; no file written)

## Verdict
**NEEDS_REWORK**

## Coverage
The spec requirement "unique labels in first-seen order" is not met (finding 1). The test plan does not distinguish first-seen from sorted order (finding 2). No ADRs apply. File scope is clean (labels.py and test_labels.py only). Public surface: no signature change reported, and I found none in the supplied material.

## Probes
list: n/a brief + n/a added; off-list clauses: 1; LIST_GAP: 1

- The verifier reported all mutation rows killed. I was not given the row-level file:line citations or test names, so I cannot grade individual rows. NOT PROBED: row detail not supplied.
- first-seen ordering → no probe covers it [off-list]. The realistic wrong implementation is the current `sorted(set(values))`. It passes the existing `["a","b","a"] -> ["a","b"]` test, because sorted order and first-seen order coincide for that input. I was not given the test's name. The missing observable assertion is `labels(["b","a","b"]) == ["b","a"]`.
- Caller-level probe from the verifier: `labels(["b","a","b"])` returns `["a","b"]`. The required output is `["b","a"]`. This confirms the defect.

## Findings

| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| HIGH | labels.py:5 | task.md: "unique string labels in first-seen order" | `sorted(set(values))` reorders labels alphabetically. `labels(["b","a","b"])` returns `["a","b"]` instead of `["b","a"]`. The change introduced this. → Replace the body with order-preserving dedup, `return list(dict.fromkeys(values))`. This adds no dependency and does not change the signature. Do NOT call `legacy_unique`, because it sorts its result. Do not edit `legacy_unique`, which is outside scope. |
| MEDIUM | test_labels.py | Observable acceptance (1b/1c) | The only test cannot tell first-seen order from sorted order. → ADD a test, e.g. `test_labels_preserves_first_seen_order`, asserting `labels(["b","a","b"]) == ["b","a"]`. Consider a second input such as `["c","a","c","b","a"] -> ["c","a","b"]`. KEEP the existing `["a","b","a"] -> ["a","b"]` assertion. The diff should be additions only. |

**TDD sequencing for the rework:** commit the new test alone first (tests-only RED). The verifier should confirm it fails against the current `sorted(set(...))`. Then commit the labels.py fix as GREEN. No frozen assertion is touched.

## Plan assumption
The plan's "sort before deduplication" recommendation and the "reuse `legacy_unique`" note contradict task.md and are invalid. The operator's "go" approved the plan as written. It did not clearly authorize overriding the stated request. The implementation report's claim that it follows the plan is accurate, but that does not make the output correct. Because task.md is the exact request, the fix is unambiguous and rework should proceed now. The coordinator should do two things:
1. Amend the plan spec to "order-preserving dedup, no sorting; do not reuse `legacy_unique`".
2. Tell the operator that the earlier approval rested on a plan defect, so they can confirm the correction.

## Notes
- If any caller actually depends on sorted output, that is a separate requirement for the operator to decide. I found no evidence of one.

## Verification
per $RUN/verifier-r1.md: PASS (suite, clean tree, HEAD fixture-head matches the snapshot). I ran no commands. I did not run the freeze/RED check, and no RED commit hashes were supplied. The suite PASS does not cover this defect, because the tests never exercise non-sorted input.

VERDICT: NEEDS_REWORK rows=2 notes=1
file: (not written — text-only exercise)