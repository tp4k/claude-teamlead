# Review: code axis, round 1

**VERDICT: NEEDS_REWORK** rows=1 notes=2

I wrote no file, as instructed. This report is the response text.

## Coverage
Task requirement "unique string labels in first-seen order" is not met (finding 1). No new dependencies and no public signature changes were found. File scope is limited to `labels.py` and `test_labels.py`.

## Probes
`list: 0 brief + 0 added; off-list clauses: 1; LIST_GAP: 1`

- Criterion "first-seen order" [off-list] → mutation at `labels.py:5` → NOT PROBED. The probe intents were seeded from the plan's "sort before deduplication" wording, so no patch targets ordering. The verifier's rows are all killed, but none distinguishes sorted output from first-seen output.
- The wrong implementation is the current one, `sorted(set(values))`. The existing `["a","b","a"]` test in `test_labels.py` passes it because sorted order and first-seen order coincide. A one-sentence mutation would be: replace line 5 with a first-seen dedupe and confirm the suite still passes. Today it does, which proves the gap.

## Findings

| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| HIGH | `labels.py:5` | task.md: "unique string labels in first-seen order" | `sorted(set(values))` returns sorted output. The verifier's caller-level probe shows `labels(["b","a","b"])` returning `["a","b"]` where `["b","a"]` is required. This change introduced the defect. The suite passes only because its sole case, `["a","b","a"]`, has first-seen order equal to sorted order. **Fix, in order:** (1) Add a tests-only RED commit first, with no production code. ADD a test in `test_labels.py` asserting `labels(["b","a","b"]) == ["b","a"]`, and optionally a three-label case such as `["c","a","c","b"] → ["c","a","b"]`. KEEP the existing `["a","b","a"] → ["a","b"]` assertion unchanged. It is not frozen-conflicting, since the diff is additions only. (2) Then change `labels.py:5` to a first-seen dedupe, for example `list(dict.fromkeys(values))`. This is stdlib, adds no dependency and leaves the signature unchanged. Do not call `legacy_unique`, which sorts. Do not edit `legacy_unique`, which is out of scope. |

## Plan assumption and approval
- The plan's "sort before deduplication" recommendation and its "reuse `legacy_unique`" step contradict task.md, which is the exact request. The assumption is wrong and must not be carried forward. The implementer followed the plan faithfully, so this is a plan defect, not an implementation slip.
- The operator's "go" approved the plan as written. Nothing in the evidence shows the operator chose sorted output over the task's stated first-seen order. I therefore treat task.md as governing.
- The coordinator should correct the plan spec line and its probe intent to "first-seen order; do not reuse `legacy_unique`". If the operator actually wants sorted output, that is a change to task.md the operator must make explicitly. Until then, rework proceeds against first-seen order.

## TDD note for rework
- The new RED test should fail against the current line 5, since it would return `["a","b"]` against an expected `["b","a"]`. I did not run this. The verifier's RED run for the rework round must show that individual failure.
- Freeze check: no existing assertion changes, so `RED_CHANGED` should not arise.

## Notes
1. Reusing `legacy_unique` was never a valid simplification. Its sorting behavior is incompatible with the spec, so "reuse" should not be a standing preference for this function.
2. A verifier probe at caller level caught this and the unit suite did not. Rework should keep that caller-level case as the permanent test.

## Verification
per verifier report: suite PASS (HEAD `fixture-head`, tree clean, snapshot matches). The PASS is real but cannot be relied on for ordering. Its only case cannot distinguish sorted from first-seen output. No failed commands to list. I ran no commands, mutations or suites.

**Next step:** return to the implementer with finding 1 (RED commit first, then the one-line fix). The coordinator then corrects the plan text and requests fresh verification, including a RED run, for the rework round.