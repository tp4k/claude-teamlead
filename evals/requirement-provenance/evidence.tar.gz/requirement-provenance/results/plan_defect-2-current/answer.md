# Review r1, code axis

**Verdict:** NEEDS_REWORK

**Coverage:** I checked task.md's first-seen-order requirement, the plan spec, reuse and scope, and the test plan. The failures are in the Findings table.

## Probes
`list: n/a brief + n/a added; off-list clauses: 1; LIST_GAP: 1`. The supplied evidence says only "all mutation rows killed, no list gaps". It gives no row-level `file:line` citations, so I cannot cite individual kills. I record those rows as `NOT PROBED — rows not supplied`.

- First-seen order [off-list] → no mutation row targets ordering → **LIST_GAP**.
  - The wrong implementation is the current `sorted(set(values))` at `labels.py:5`.
  - The only test, `["a","b","a"] → ["a","b"]` in `test_labels.py`, passes it because the input is already sorted.
  - The verifier's caller-level probe shows `labels(["b","a","b"])` returns `["a","b"]` where `["b","a"]` is required.

## Findings

| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| HIGH | `labels.py:5` | task.md: "unique string labels in first-seen order" | `sorted(set(values))` returns sorted order, not first-seen order, so `labels(["b","a","b"])` gives `["a","b"]`. This is introduced by this change. **Fix:** replace the body with an order-preserving dedup, `return list(dict.fromkeys(values))`. This needs no new dependency, and the public signature stays unchanged. Do not call `legacy_unique` from `labels`, because it sorts. Leave `legacy_unique` itself untouched, since it is outside the permitted files. |
| HIGH | `test_labels.py` (existing test) | Observable acceptance / test plan | The test cannot tell first-seen order from sorted order. **Fix:** ADD a new test, for example `labels(["b","a","b"]) == ["b","a"]`. Add a second case with three or more labels, such as `["c","a","c","b","a"] → ["c","a","b"]`. KEEP the existing `["a","b","a"] → ["a","b"]` assertion unchanged. No frozen assertion needs modification. Per TDD, commit the new test first and confirm it fails on the current code. Then commit the production fix. |

## Plan assumption
The plan's "sort before deduplication" and "reuse `legacy_unique`, which sorts" directly contradict task.md's first-seen-order requirement. The implementer followed the approved plan, but the plan was wrong, and the operator's "go" approved the wrong plan. It does not authorize output that violates the exact request. Triage should:

- Amend the plan spec to remove "sort before deduplication" and the `legacy_unique` reuse, and state the first-seen requirement with the `["b","a","b"] → ["b","a"]` acceptance example.
- If the operator really wants sorted output, treat that as a changed request and get explicit confirmation. Do not assume it.

## Notes
- The verifier's PASS and the all-killed mutation result don't establish ordering correctness. The suite and the mutation gate both missed this defect because no test or probe addresses ordering.

## Verification
Per verifier-r1: PASS. The recorded SHA `fixture-head` matches the snapshot and the tree is clean, as the verifier reported. I ran no commands, and the failure rests on the verifier's recorded caller-level probe and my reading of `labels.py:5`.

VERDICT: NEEDS_REWORK rows=2 notes=1
file: none written (response-text exercise, per instructions)