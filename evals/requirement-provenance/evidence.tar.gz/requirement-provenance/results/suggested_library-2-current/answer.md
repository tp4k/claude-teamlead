**Action:** Fix mode. I fold answer 1 into the plan and briefs. I leave the case-sensitivity assumption open and labelled provisional. I ran nothing, and I have not read `labels.py` or `test_labels.py` myself. Everything below comes from the artifacts you supplied.

## What "go" settles

- **Settled:** question 1, label order. "go" accepts the recommended option a), first-seen order. The draft plan already recommended it, so the only change is wording. The conditional becomes a fact marked user-confirmed, and alphabetical is dropped.
- **Not settled by "go":** case variants. That is a separate pending question, and "go" is not an answer to it.
- **Not a user question:** `dict.fromkeys` versus a seen-set loop. Both meet the task for strings, so it is a mechanism choice for the plan.

## Corrected plan sections (WS-1 — dedupe labels, S, no deps, wave 1)

### Spec excerpt
task.md (task excerpt, no design document exists): "Return unique string labels in first-seen order. No new dependencies or public signature changes."

### Reuse and scope
- reuse: none found. The repository artifacts state there is no existing deduplication helper. Use the built-in `dict.fromkeys`, since a Python dict preserves insertion order.
- keep because: the user's request. `labels(values)` must return unique labels in first-seen order.

### Decisions taken
1. Order is first-seen, **user-confirmed** ("go" accepting option a). Evidence: task.md says "first-seen order".
2. Use `list(dict.fromkeys(values))`. Both approaches are correct for strings. The one-liner is concise, adds no dependency, and keeps the signature.
   - The implementer must keep the current return type. Its current value is unverified, since I have not seen `labels.py`.
3. **Provisional, unconfirmed:** case variants are distinct, so labels are compared by exact string equality with no normalization.
   - Evidence: task.md says "unique string labels" and says nothing about case folding.
   - Folding would also require inventing a rule for which casing to keep.
   - This stays open in questions.md. It is not recorded as user-settled.

### Test plan (`test_labels.py`, unittest)
- existing: none relevant, since nothing is frozen.
- new:
  - `test_labels.py::test_duplicates_keep_first_position`, input `["b","a","b","c","a"]`, expects `["b","a","c"]`. It fails for sorted output and for last-seen order.
  - `test_labels.py::test_empty_input` expects `[]`.
  - `test_labels.py::test_unique_input_unchanged` checks that already-unique input keeps its order, as in `["c","a","b"]`.
  - `test_labels.py::test_case_variants_distinct` (provisional), input `["a","A","a"]`, expects `["a","A"]`. This is marked "pending question 2", so the implementer knows the assertion may change.
- probe: first-seen order — the last occurrence is kept instead of the first.
- probe: first-seen order — the output is sorted alphabetically.
- probe: exact equality — labels are compared case-folded, so `"A"` is dropped.

### Review axes
- attacker-controlled input: yes — the source of `values` is unknown, and uncertain cases default to yes.
- hot path: no — no spec or benchmark names one.
- public surface: yes — `labels` is an exported function whose behavior callers rely on.

### Verification commands
cwd: <repo root, from `$RUN/repo.txt`>
- `python3 -m unittest test_labels`

I could not check tool availability here, so the invocation is unverified. Python-only, so no `check:` line.

## Brief excerpts (`impl-ws1-r1.md`)

Scope block:
```scope
labels.py
test_labels.py
```

- **Do not touch:** every other file. Anti-scope: no new dependencies, no signature changes, no case normalization, no sorting.
- **Project forbiddens:** none, because no CLAUDE.md or rules were supplied.
- **Report file:** `$RUN/implementer-ws1-r1.md`.

## Open question (questions.md)

2. Should labels differing only in case count as distinct?
   options: a) distinct, exact string equality; b) case-insensitive, keep first-seen casing
   recommended: a
   rests on: task.md — "unique string labels" with no normalization mentioned
   otherwise: b changes WS-1's `test_case_variants_distinct` to expect `["a"]` and adds a case-folded key.

## Fix log
- answer 1: "go" accepts first-seen → the plan already recommended it, so I only turned the conditional into a user-confirmed fact.
- case question: unanswered → decision 3 is carried provisionally and the open question is kept.

PLAN_FIXED fixed=1 new_paths=no