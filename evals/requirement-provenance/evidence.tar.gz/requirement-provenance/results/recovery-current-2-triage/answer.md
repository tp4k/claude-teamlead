# Triage, round 1 (inline, nothing written to disk, nothing executed)

**Action:** NEEDS_REWORK. Rework count is 0 of 3 before this round and 1 after. The verdict is not a docs-only round or a spec call.

Verdict: NEEDS_REWORK

## Rows
| Sev | Location | Req/Concern (reviewer: code) | Problem → Fix |
|---|---|---|---|
| HIGH | `labels.py:1-8` | Frozen RED `test_uses_dict_fromkeys`; brief `reuse: dict.fromkeys` | The set loop never calls `dict.fromkeys`. The verifier reported exit 1 (`.F`) at HEAD `89678d9…` on `spy.call_count == 1`. → Replace the body with `return list(dict.fromkeys(values))`. **Behaviour that changes:** `labels(values)` still returns unique labels in first-seen order, but now builds them through one `dict.fromkeys(values)` call instead of a manual loop. **Pinned by:** existing `test_labels.py::LabelTests::test_uses_dict_fromkeys` (unchanged) and `::test_first_seen`. |

The reviewer's MEDIUM row (`tree: ""`, mutation not run) is not a defect in the code. The implementer cannot fix it, so I moved it out of the rows. The next verifier run must record `tree: CLEAN` and the HEAD SHA, include the RED run, and run the mutation gate. I recorded this under Notes and in the brief's Verifier output section.

I traced the patched call path. `patch('labels.dict', create=True)` puts a wrapper in the `labels` module globals. A bare `dict.fromkeys(values)` resolves to that wrapper, so the spy sees the call. `builtins.dict` or `{}.fromkeys` would bypass it, so the brief tells the implementer to use the bare name.

```decision-records
[{"id":"labels-fromkeys-1","revision":1,"action":"fix","reason":"Frozen RED assertion and brief reuse directive require dict.fromkeys; task.md uniqueness behaviour unchanged","evidence":"Verifier exit 1 on test_uses_dict_fromkeys at HEAD 89678d9; RED_FROZEN passed"},
 {"id":"labels-empty-input-tests-1","revision":1,"action":"defer","reason":"Optional extra coverage outside requested behaviour","evidence":"dict.fromkeys handles empty and no-duplicate input; spec does not call them out"}]
```

## Demoted to Notes
- Add tests for empty and no-duplicate input — optional coverage, not in the spec, and the fixed code handles both (`test_labels.py`)

## Notes for the user
- `test_uses_dict_fromkeys` pins a mechanism, but `task.md` requires only unique labels in first-seen order. The brief calls `dict.fromkeys` "recommended". The frozen assertion stays in force. recommended: keep the assertion and the `dict.fromkeys` call, since the behavioural plan was approved with it. You may relax it separately.
- Non-string input handling is unresolved and out of scope for this work.
- Verification must be re-collected with clean-tree evidence and a mutation run. No probes file was supplied, so `list_gap=0`.

## Re-review set
code: re-run — always
security: no review in this round, so nothing to carry. The fix is a mechanism swap with no validation, parsing or authorization change.
perf: no review in this round, so nothing to carry.

## Rework count
1

---

# Implementer brief: WS-1, round 2 (rework)

Inherited source: the round-1 brief and `implementer-ws1-r1.md` (previous work). Your generic rules come with your agent type.

## Spec
Authority: `task.md`, an explicit user instruction, applying to `labels(values)`. Return unique string labels in first-seen order. Keep the `labels(values)` signature and add no dependencies. Only `labels.py` and `test_labels.py` may change. Assumption: handling of non-string inputs is unresolved, so this work covers strings only.

## Reuse and scope
- Reuse: `dict.fromkeys`. It is recommended because it is concise. The general go approved the behavioural plan. Keep it because `task.md` requires unique labels.
- The frozen RED assertions (`RED_FROZEN`, hash `b56ad06b5c1359aacbd4308ad21d54b085128904`) stay in force. Do not edit `test_labels.py`.

## Scope
```scope
labels.py
test_labels.py
```
The fix needs only `labels.py`. The fence is unchanged and not narrowed.

## Findings to fix
1. **HIGH, `labels.py:1-8`:** the set loop never calls `dict.fromkeys`, so `test_uses_dict_fromkeys` fails (`spy.call_count == 1`, exit 1 at HEAD `89678d9…`).
   - Fix: keep `def labels(values):` and make the body `return list(dict.fromkeys(values))`.
   - Use the bare module-global name `dict`. The test patches `labels.dict`, so `builtins.dict` or `{}.fromkeys` would bypass the spy.
   - Behaviour that changes: the result is still unique labels in first-seen order, now built by one `dict.fromkeys(values)` call.
   - Pinned by `test_labels.py::LabelTests::test_uses_dict_fromkeys` and `::test_first_seen`, both existing and unchanged.

Rework cause: implementation defect. The implementer ignored the `reuse: dict.fromkeys` directive and the frozen RED test. Evidence: verifier exit 1 on that test.

## Verifier output
The previous verifier run is in `verifier-r1.md`. The next run must record `tree: CLEAN` and the HEAD SHA, include `## RED run`, and run the mutation gate. This is the verifier's job, not yours.

## Test plan additions
None.

## Report file
`$RUN/implementer-ws1-r2.md`

---

```
VERDICT: NEEDS_REWORK rows=1 list_gap=0 demoted=1 notes=3 docs_only=no decisions=0 rework_brief=$RUN/briefs/impl-ws1-r2.md rereview=code carried=none
file: $RUN/triage-r1.md
```