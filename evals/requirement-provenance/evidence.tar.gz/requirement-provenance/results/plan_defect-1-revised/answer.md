**Action:** Issue `NEEDS_REWORK` on the code axis. Ordinary in-scope rework; no STOP.
**Next step:** The implementer applies the two rows below, with a RED test commit before the production fix. Triage corrects the plan note.

*(Report file not written, per the exercise. Content is below.)*

## Verdict
NEEDS_REWORK

## Coverage
The first-seen-order requirement from task.md and the observable acceptance check fail (rows 1 and 2). No ADRs or project rules apply. File scope is clean (`labels.py`, `test_labels.py`). There is no public-signature change and no new dependency.

## Probes
`list: n/a brief + n/a added; off-list clauses: 1; LIST_GAP: 1`
- "Unique labels in **first-seen order**" → `[off-list]`. The shared list has no probe for it, so it is a LIST_GAP. The shipped `sorted(set(values))` at `labels.py:5` is itself the wrong implementation, and the test for `["a","b","a"] -> ["a","b"]` passes under it. That test's name was not supplied. The verifier's caller-level probe confirms it: `labels(["b","a","b"])` returns `["a","b"]`, not `["b","a"]`.
- The other rows were reported all killed, but no `file:line` or test citations were supplied, so I cannot resolve them. NOT PROBED — unresolvable citations.

## Findings

| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| HIGH | `labels.py:5` | task.md: unique labels in first-seen order | `sorted(set(values))` returns lexicographic order. `labels(["b","a","b"])` yields `["a","b"]`, but `["b","a"]` is required. The change introduced this defect. → Replace the body with an order-preserving dedupe, e.g. `return list(dict.fromkeys(values))`. This needs no import and no new dependency. KEEP the signature unchanged. Do NOT call `legacy_unique`, because it sorts. Do not edit `legacy_unique`. |
| HIGH | `test_labels.py` | Observable acceptance; wrong implementation `sorted(set(values))` passes the only test | The sole case, `["a","b","a"]`, is already sorted, so it cannot distinguish first-seen order from sorted order. → ADD a test asserting `labels(["b","a","b"]) == ["b","a"]`, plus one all-distinct unsorted case such as `labels(["c","a","b"]) == ["c","a","b"]`. KEEP the existing `["a","b","a"] -> ["a","b"]` assertion untouched. The diff to this file should be additions only. |

**TDD for the rework:**
- Commit the new tests first as a tests-only RED commit. Against current `labels.py` they should fail, with `["a","b"]` returned where `["b","a"]` is expected. The verifier must record that failure in `## RED run`. I have not run it.
- Then commit the production fix.
- No frozen assertion changes, so no `RED_CHANGED` is expected.

## Plan assumption (for triage)
- The plan's "sort before deduplication" and "reuse `legacy_unique`" are discretionary mechanism recommendations. Nothing in task.md, project rules, ADRs or an external contract authorizes them.
- They contradict the governing requirement, "first-seen order". The operator's "go" does not promote them to requirements.
- Plan conformance does not excuse the observable defect.
- This is not a governing-requirement conflict, because task.md is unambiguous and the fix is in scope. Do not escalate to STOP.
- Strike the sort and `legacy_unique` guidance from the plan's spec for the rework brief. The brief should restate the behavior requirement: first-seen order, with unsorted-input acceptance cases.

## Notes
- Reusing `legacy_unique` is not by itself a defect. The finding is the ordering behavior.

## Verification
per `$RUN/verifier-r<M>.md`: PASS (clean tree, HEAD `fixture-head` matches the snapshot). The PASS does not cover ordering, because the suite lacks an order-sensitive case. The caller-level probe is the evidence of failure. I ran no commands of my own.

```
VERDICT: NEEDS_REWORK rows=2 notes=1
file: $RUN/review-r<M>-code.md
```