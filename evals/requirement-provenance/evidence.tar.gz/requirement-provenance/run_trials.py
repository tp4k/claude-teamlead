from pathlib import Path
import concurrent.futures, hashlib, json, subprocess, time
ROOT=Path('/tmp/teamlead-provenance-eval')
PROTOCOL=json.loads((ROOT/'protocol.json').read_text())
CASES=json.loads((ROOT/'fixtures.json').read_text())
for name,digest in json.loads((ROOT/'manifest.json').read_text()).items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name

def invoke(version, role, prompt, ident):
    out=ROOT/'results'/ident
    out.mkdir(parents=True,exist_ok=False)
    instructions=(ROOT/version/'references/roles'/f'{role}.md').read_text()
    if role=='reviewer':
        instructions+='\n\n'+(ROOT/version/'references/review-standard.md').read_text()
    system='Follow this assigned role for the supplied isolated exercise. No tools are available; provide the requested artifacts as response text. Do not claim unperformed execution.\n\n'+instructions
    user=PROTOCOL['output_contract']+'\n\n'+prompt
    (out/'system.txt').write_text(system)
    (out/'prompt.txt').write_text(user)
    cmd=['claude','-p','--model','sonnet','--effort','high','--tools','','--safe-mode','--strict-mcp-config','--setting-sources','','--no-session-persistence','--disable-slash-commands','--output-format','json','--system-prompt',system]
    started=time.time()
    try:
        p=subprocess.run(cmd,input=user,text=True,capture_output=True,cwd=out,timeout=240)
        (out/'response.json').write_text(p.stdout)
        (out/'stderr.txt').write_text(p.stderr)
        status={'exit_code':p.returncode}
        try:
            response=json.loads(p.stdout)
            (out/'answer.md').write_text(response.get('result',''))
            status.update(model_usage=response.get('modelUsage'),error=response.get('is_error'),session_id=response.get('session_id'))
        except json.JSONDecodeError:
            status['invalid_json']=True
    except subprocess.TimeoutExpired as e:
        status={'timeout':True}
        (out/'stderr.txt').write_text(str(e.stderr or ''))
    status.update(id=ident,version=version,role=role,started=started,seconds=time.time()-started)
    (out/'status.json').write_text(json.dumps(status,indent=2))
    print(json.dumps(status),flush=True)
    return status

if __name__=='__main__':
    jobs=[]
    for repeat in range(1,6):
        for case in CASES:
            versions=['current','revised'] if repeat%2 else ['revised','current']
            for version in versions:
                jobs.append((version,case['role'],case['prompt'],f'{case["id"]}-{repeat}-{version}'))
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        results=list(pool.map(lambda args:invoke(*args),jobs))
    (ROOT/'targeted-status.json').write_text(json.dumps(results,indent=2))
