## Decision

**Implement `dict.fromkeys`. Do not adopt the seen-set loop.**

- **Why it is binding:** Task.md says "Use dict.fromkeys in labels(values); this mechanism is required by our instrumentation." That is an explicit task instruction, so it is binding authority and the `reuse: dict.fromkeys` line is not discretionary. The discretion to choose an alternative that "satisfies the behavior, contracts, scope fence" only applies to non-binding recommendations. Here the mechanism is part of the contract.
- **The alternative:** The seen-set loop returns the same values and is easier to read. Readability does not override an explicit requirement, and the task's own rationale (instrumentation) is outside what I can check. I record the alternative in the report as considered and not adopted, with that reason.
- **Not a blocker:** The requirement is unambiguous and conflicts with nothing in the brief, so no Open question is needed.

## Proposed function body

```python
def labels(values):
    return list(dict.fromkeys(values))
```

- The signature stays as it is.
- The `list(...)` wrapper is needed because `dict.fromkeys` returns a dict. "Return unique string labels in first-seen order" implies a sequence. Check this against the existing signature or return annotation in `labels.py` before finalizing.
- No new dependencies.

## TDD plan (edits only in `labels.py` and `test_labels.py`)

1. If `labels.py` has no `labels` yet, commit a scaffold first. It contains only the signature, with the body raising `NotImplementedError`.
2. Add at most 2 RED tests to `test_labels.py`. They assert observable output only, not which helper ran:
   - `labels(["b","a","b","c","a"]) == ["b","a","c"]`. This rejects `sorted(set(...))`, bare `set(...)` (order not preserved), and last-seen-wins ordering.
   - `labels([]) == []`. This is only worth keeping if a probe shows it rejects a concrete wrong implementation. Otherwise omit it.
3. Run only those tests. Each must fail on behavior, for example a `NotImplementedError` or a wrong-value assertion, not on an import error. Keep that output as the `red:` evidence.
4. Commit the tests alone and freeze them. Then implement the body above.
5. Run the freeze check and the brief's verification commands once at the end.

## Evidence to report

- **Mechanism is not observable by tests.** Behavioral tests cannot tell `dict.fromkeys` from a seen-set loop, because both produce identical returns. I will not write a test that asserts the helper ran. Compliance with the mechanism requirement is shown by the diff, and the report cites the body line (`labels.py:<line>`) once the final tree exists.
- **Probes:**
  - Replace `list(dict.fromkeys(values))` with `list(set(values))`, expecting the order test to kill it. Report this only after observing the result.
  - The mechanism-swap probe (seen-set loop) is `NOT PROBED — mechanism is an explicit requirement and is not behaviorally observable; the swap would survive by design`.
  - Write the probes file with the patches I actually ran.
- **Open questions:** none about the mechanism. I will note the `list()` wrapper assumption if the existing signature says otherwise.

## Status of this exercise

No tools or execution were available here, and the working directory is not a git repository. So I have run no tests, made no commits, and have no RED output, freeze result or verification exit codes. The report below is a decision and plan, and nothing in it claims a verified run.

```
status: partial
confidence: low — decision and body are settled, but no tests, commits, RED output, freeze check, or probes were run
commits: none
```

file: $RUN/implementer-ws<N>-r<M>.md (not written; no file tool was available in this exercise)