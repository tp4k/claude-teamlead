Both files are proposed content for the harness to write. I did not write them.

## Proposed `$RUN/briefs/impl-ws1-r2.md`

```
# Implementer brief — WS-1 — round 2 (rework)

Inherited source: $RUN/briefs/impl-ws1-r1.md (scope, spec, forbiddens and verification
commands). The router generates a current view; read that first, then
$RUN/implementer-ws1-r1.md for what the previous coder did and why.
Your generic rules come with your agent type.

rework cause: implementation defect. The round-1 code passes test_first_seen but never calls
dict.fromkeys, which the brief's reuse line and the frozen RED test require. Evidence:
$RUN/verifier-r1.md, test_uses_dict_fromkeys fails at test_labels.py:11 (assert spy.call_count == 1).

## Spec
Authority: task.md, explicit user instruction. It applies to `labels(values)`.
- Return unique string labels in first-seen order.
- Keep the signature `labels(values)`. Add no new dependencies.
- Only `labels.py` and `test_labels.py` may change.
- Assumption: handling of non-string inputs is unresolved. This work covers strings only.
  Do not add input validation or type rejection.

## Reuse and scope
reuse: dict.fromkeys — recommended because it is concise. The general go approved the
behavioural plan. Keep it because task.md requires unique labels. The frozen RED test
test_uses_dict_fromkeys pins this reuse.

## Scope
```scope
labels.py
test_labels.py
```
(The fence is unchanged from round 1. `test_labels.py` is frozen RED: do not edit it.)

## Findings to fix
| Sev | Location | Req/Concern (reviewers) | Problem → Fix |
|---|---|---|---|
| HIGH | `labels.py:1-8` (`test_labels.py:8-11`) | Brief reuse: `dict.fromkeys`. Frozen RED `test_uses_dict_fromkeys`. (code) | `labels` builds the result with a hand-rolled `set`/`list` loop and never calls `dict.fromkeys`, so `test_uses_dict_fromkeys` fails at `test_labels.py:11`. → Replace the body with `return list(dict.fromkeys(values))`. Resolve `dict` as the bare module-global name. Do not use `builtins` or an alias, because the test patches `labels.dict`. Remove the `seen`/`result` loop. Keep the signature `labels(values)`. |

Behaviour that changes: `labels(values)` now gets its dedupe from exactly one `dict.fromkeys(values)` call. Output stays the unique values in first-seen order, e.g. `['b','a','b']` → `['b','a']`.
Pinning tests: `test_labels.py::test_uses_dict_fromkeys` (existing, currently failing, must pass) and `test_labels.py::test_first_seen` (existing, must stay passing).

## Verifier output
The verifier failed. Read $RUN/verifier-r1.md for the failing command (`python3 -B -m unittest -v test_labels`, exit 1) and its output.

## Test plan additions
none. Both pinning tests already exist and are frozen.

## Report file
$RUN/implementer-ws1-r2.md
```

## Proposed `$RUN/triage-ws1-r1.md`

```
# Triage — round 1

Verdict: NEEDS_REWORK

## Rows
| Sev | Location | Req/Concern (reviewers) | Problem → Fix |
|---|---|---|---|
| HIGH | labels.py:1-8 (test_labels.py:8-11) | Brief reuse `dict.fromkeys`; frozen RED test_uses_dict_fromkeys (code) | The hand-rolled set/list loop never calls dict.fromkeys, so the verifier run is FAIL. → `return list(dict.fromkeys(values))` using the bare global `dict`. Behaviour: labels now calls dict.fromkeys once and returns the same first-seen result. Pinned by test_labels.py::test_uses_dict_fromkeys (existing, frozen) and test_labels.py::test_first_seen. |

```decision-records
[{"id":"ws1-r1-row1","revision":1,"action":"fix","reason":"Brief reuse line and frozen RED test require dict.fromkeys; code does not call it","evidence":"verifier-r1.md: test_uses_dict_fromkeys fails at test_labels.py:11; labels.py:1-8 is a manual loop"}]
```

## Demoted to Notes
none

## Notes for the user
- The brief's reuse line says dict.fromkeys is "recommended because concise", and task.md does not name it. The frozen test therefore pins an implementation choice, not user-visible behaviour. The implementer must not weaken the test. If you want the reuse to be optional, authorise a RED change explicitly.
- Non-string inputs are declared out of scope by the brief. Unhashable inputs raise TypeError in both the current code and dict.fromkeys. This is not a finding.
- Scope was respected: only labels.py and test_labels.py changed. The RED freeze check reported RED_FROZEN. The mutation gate did not run (probe list empty, test failed), so re-run it after the fix. I did not run tests or mutations myself.

## Re-review set
code: re-run — always
security: not re-run — no security review existed for this round, so there is nothing to carry. The fix replaces a loop with one pure-Python builtin call and adds no parsing, validation or request-reachable path. (none)
perf: not re-run — no performance review or finding exists. The change is not tagged hot path. (none)

## Rework count
1
```

VERDICT: NEEDS_REWORK rows=1 list_gap=0 demoted=0 notes=3 docs_only=no decisions=0 rework_brief=$RUN/briefs/impl-ws1-r2.md rereview=code carried=none
file: $RUN/triage-ws1-r1.md