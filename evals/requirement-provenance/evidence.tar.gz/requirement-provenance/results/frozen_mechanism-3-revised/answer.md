## Decision

I will replace the frozen `spy.call_count == 1` mechanism assertion, because R1 HIGH names that test as erroneous and triage adopted it. `test_first_seen` stays byte-identical. `labels.py` does not change: the seen-set loop meets the spec ("unique, first-seen order"), and `dict.fromkeys` was a discretionary recommendation, not binding authority. Nothing has been run yet; every result below is a placeholder to fill from real runs.

## Next actions

1. Read `current-ws<N>-r2.md`, `implementer-ws<N>-r1.md`, the R1 finding row, the triage output, and the mutation report if the verifier's gate failed.
2. Edit only `test_labels.py`, in `test_uses_dict_fromkeys`. Remove the spy and the `call_count` assertion. Rename the test, since the old name would falsely claim a mechanism. Add a behavioral assertion such as `labels(["a","a","a","b"]) == ["a","b"]` plus a non-adjacent repeat.
3. Commit the test alone as a separate commit. It covers behavior that already exists, so it cannot fail at RED: `red: n/a — behaviour already present`. Its evidence is a mutation that now fails it.
4. Self-probe, then undo each edit manually and confirm `git status --short` matches its pre-probe state:
   - Drop the dedupe so duplicates are returned; this should fail the new test.
   - Dedupe only adjacent items or only the first repeat; this should fail the new test.
   - Last-seen ordering should still be killed by the unchanged `test_first_seen`.
   - I will record each outcome only after observing it.
5. Rewrite `probes-ws<N>-r2.json` against the final tree. Confirm each `old` text occurs exactly once at HEAD.
6. Run the brief's verification commands from its stated directory.
7. Run `red_freeze.py --repo <repo> <r1-red-hash> [<r2-hash>]` with no run option.

## What may change

- **Allowed:** the `test_uses_dict_fromkeys` def line (rename) and its mechanism assertion. No new `labels.py` edits.
- **Forbidden:** `test_first_seen`, public signatures, dependencies, any file other than the two in the fence, and history rewrites.
- **Not authorized:** deleting the test outright, which would lose behavioral coverage.

## Freeze evidence required

I expect `red_freeze.py` to print `RED_CHANGED`. That is acceptable only if the changed lines are exactly the renamed def and the `spy.call_count == 1` assertion. Each line goes in the report beside the R1 HIGH row that named it. Any `RED_CHANGED` line touching `test_first_seen` is a defect.

## Report excerpts (to be completed from actual output)

```
## TDD
tdd: APPLIED
red: <r1-red-hash>
new: test_labels.py::<renamed test> — duplicates removed from output — rejects: <probe result observed> — red: n/a — behaviour already present
existing: test_first_seen — ran / still green (unchanged)
extra: none
freeze: RED_CHANGED — <renamed def line> and `assert spy.call_count == 1`, both named by R1 HIGH (test_uses_dict_fromkeys is erroneous: no task, rule, ADR or caller contract requires the helper call); triage adopted R1 for round 2

## Open questions / compromises
Adopted R1's replacement of a mechanism assertion. Production keeps the seen-set loop rather than dict.fromkeys: Reuse was discretionary, and the behavior, scope, and frozen tests are satisfied. Callers see the same list output.
```

```
status: done
confidence: med — <fill after runs; mutation outcomes and verification not yet observed>
commits: <hash>
```
This block is valid only if the verification and probe results I have not yet observed come out passing; otherwise it becomes `partial`.

## Would I have made the same edit before R1?

No. Before R1, "implement exactly the spec" and the freeze rule apply. My own judgment that the assertion tests mechanism rather than behavior is not enough to change a frozen line. The authority to change it comes from R1 explicitly identifying the test as wrong and triage adopting that finding. Without R1, I would leave the frozen line alone and report it under Open questions as a mechanism-only assertion with no governing authority. I would then either use `dict.fromkeys` in production so the frozen test passes, which is within discretion, or report `partial` or `blocked` and let the coordinator decide. I would not have weakened the test unilaterally.