## Action

I am applying the operator's "go" in Fix mode. The answer closes the ordering question only. I am keeping the case-variant question open, and I have written no files and run no tests.

## What "go" settles

- **Settled:** label order is first-seen, option a. This is now a fact, not a choice. `task.md` already required it, so the answer confirms it and does not change it.
- **Not settled:** the mechanism. "go" approved the behavior, not `dict.fromkeys`, so the mechanism stays discretionary.
- **Not settled:** case variants. That question was never offered, so "go" does not answer it.

## Spec (WS-1, corrected)

Source: `task.md` (task excerpt, verbatim): "Return unique string labels in first-seen order. No new dependencies or public signature changes."

- **Authority:** the explicit user instruction in `task.md` binds. The operator's "go" confirms first-seen order. Alphabetical order (option b) is declined.
- **Binding:** first-seen order, uniqueness, no new dependencies, and an unchanged `labels(values)` signature.
- **Unresolved assumption (not a requirement):** case variants such as `"A"` and `"a"` count as distinct. This is provisional and rests on exact string equality, because the task mentions no case folding.

## Reuse and scope

reuse: none found — searched `labels.py` and `test_labels.py`; there is no deduplication helper. `dict.fromkeys(values)` is recommended because Python dicts preserve insertion order and it is concise. An explicit seen-set loop is an acceptable alternative. Either must meet the behavior, signature, and scope fences.

do not reuse: `sorted(set(values))` as deduplication — it drops first-seen order, which is the declined option b.

keep because: `task.md` requires unique labels in first-seen order.

## Decisions taken

1. Label order follows first-seen input order. Evidence: `task.md` ("first-seen order") and the operator's "go" on option a.
2. The mechanism is discretionary. Evidence: the operator approved only the behavior, and both candidates satisfy it for strings.
3. Case variants are treated as distinct provisionally. Evidence: `task.md` says "unique string labels" with no normalization. This is not closed, and it stays in `questions.md`.

If the case question is later answered "case-insensitive", `dict.fromkeys` alone no longer suffices. That is why the mechanism is not mandated.

## Treatment in questions.md

The case question stays open. It is the only remaining decision, so it needs one menu:

1. Should `"A"` and `"a"` count as the same label?
   - options: a) distinct, exact string equality; b) same, keep first spelling
   - recommended: a
   - rests on: `task.md` — "unique string labels"
   - otherwise: b changes WS-1's acceptance and its case test, and rules out plain `dict.fromkeys`.

The ordering question is closed and removed.

## Brief excerpts (impl-ws1-r1.md)

**Scope**
```scope
labels.py
test_labels.py
```

**Test plan**
- existing: none relevant, beyond whatever `test_labels.py` already contains; I have not seen its contents, so the implementer should confirm.
- new: `test_labels.py::test_duplicates_removed_first_seen_order` — `["b","a","b","c","a"]` yields `["b","a","c"]`.
- new: `test_labels.py::test_empty_input` — empty input yields an empty result.
- new: `test_labels.py::test_case_variants_distinct` — `["A","a"]` keeps both. This depends on the provisional assumption.

The implementer must preserve the existing return type of `labels`.

- probe: first-seen order — the last occurrence's position wins instead of the first
- probe: uniqueness — duplicates are kept
- probe: ordering — the result is alphabetical
- probe: empty input — the function returns a non-empty result
- probe: case assumption — `"A"` and `"a"` collapse

**Do not touch:** every file except `labels.py` and `test_labels.py`. Anti-scope: no new dependencies, no signature changes, no alphabetical sorting, no case normalization unless the question is answered.

**Project forbiddens:** none; no CLAUDE.md or rule files were supplied.

**Verification commands:** `python3 -m unittest test_labels`. Whether `python3` is available is unchecked; run `which python3` first. No `check:` line is needed for a Python-only task.

**Review axes**
- attacker-controlled input: yes — the origin of `values` is unknown, so I default to yes.
- hot path: no — nothing in the task identifies one.
- public surface: yes — `labels(values)` is an existing function whose signature is frozen.

**Report file:** `$RUN/implementer-ws1-r1.md`

## Fix log

- answer 1: first-seen order, option a → recorded as a closed behavioral decision. The mechanism was not made binding.
- case variants → remains an unresolved assumption.

## Next step

The coordinator relays the case question to the user, then runs one more Fix round if the answer is b.

PLAN_FIXED fixed=1 new_paths=no