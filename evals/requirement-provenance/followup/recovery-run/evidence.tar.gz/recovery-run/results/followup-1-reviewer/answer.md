# Review WS-1 r1, code axis

**Verdict: NEEDS_REWORK** rows=1 notes=2

## Coverage
I checked the task.md requirement (unique labels, first-seen order, `labels(values)` signature, no new dependencies) against `labels.py:1-8`. `labels.py` and `test_labels.py` are the only changed files, so file scope holds. The `labels.py` implementation meets the behavioral requirement. The one failure is in the frozen test, and it is in the table below.

## Probes
list: 0 brief + 0 added; off-list clauses: 1; LIST_GAP: 0 (unverified; no probes file or patches were supplied)
- `if value not in seen` guard (`labels.py:5`) → NOT PROBED — the verifier's mutation gate did not run, because `test_uses_dict_fromkeys` failed first. By reading, deleting the guard returns `['b','a','b']` and fails `test_labels.py::test_first_seen` (line 14). That is my reading, not a gate result.
- The rework must add a probe patch for this guard to the probes list. The mutation gate has to run once the suite is green.

## Findings

| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| HIGH | `test_labels.py:8-11` (`test_uses_dict_fromkeys`, assertion `spy.call_count == 1` at line 11) | Frozen test requires a discretionary mechanism. The suite fails, so `verifier-r1` is FAIL. | **Problem:** the test asserts `dict.fromkeys` is called. The brief's only authority for that is "reuse: dict.fromkeys — recommended because concise". task.md requires only unique labels in first-seen order. A recommendation is not authority, and the general `go` approval covered the behavioral plan only. `labels.py:1-8` (set plus ordered list) is a valid alternative that meets the behavior, so the implementation is not defective. The verifier's RED run and final run both fail this test at line 11. Mutation was never run.<br>**Fix (for the next implementation attempt):** in a new commit, delete `test_uses_dict_fromkeys`, lines 8-11, and the now-unused `from unittest.mock import patch` import. This `RED_CHANGED` on those lines is authorized by this finding, and the commit message should cite it.<br>Keep `test_first_seen` unchanged, including `assert labels(['b','a','b']) == ['b','a']`, and keep the `unittest.main()` block. Add behavioral coverage, as additions only: `labels([]) == []`, and `labels(['a','a','a']) == ['a']` as a single-repeat case.<br>Leave `labels.py` as it is. Then re-run verification so the mutation gate runs, including a probe patch for the `not in seen` guard. |

## Notes
- Non-string inputs are an unresolved assumption in the brief and are out of scope. I filed nothing on them.
- Rewriting `labels.py` as `list(dict.fromkeys(values))` would also turn the suite green without touching frozen lines. It is optional, because the reuse guidance is discretionary. If the implementer chooses it, `test_first_seen` must still pass.

## Verification
per `$RUN/verifier-r1.md`: **FAIL**. `test_labels.test_uses_dict_fromkeys` fails at `test_labels.py:11` with `AssertionError`. Mutation was not run.

The snapshot checks out. HEAD is `ab0ac5d36a0c590eb822d5fc1c0c476160c033d6`, which matches the recorded `head:`, and `git status --porcelain=v1 --untracked-files=all` is empty. The freeze check reported `RED_FROZEN` for 559665203eddc5590a2d74f091fdb59b68662e36, with 13 frozen lines present. The RED commit touches only `test_labels.py`.