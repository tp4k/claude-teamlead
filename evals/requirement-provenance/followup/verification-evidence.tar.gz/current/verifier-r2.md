# Verifier — recovery evidence supplement

OUTCOME: PASS

## Snapshot

head: d6c0e281f2fe1c017ff908c0f9f4f1c6dad6086b
tree: CLEAN

## Commit attribution

Original harness applied the agent's proposed file; this collector only verifies that existing commit in a clone.

commit d6c0e281f2fe1c017ff908c0f9f4f1c6dad6086b
Author:     Evaluation <eval@example.test>
AuthorDate: Fri Oct 30 09:51:48 2026 +0400
Commit:     Evaluation <eval@example.test>
CommitDate: Fri Oct 30 09:51:48 2026 +0400

    Apply agent recovery

## RED run

none — round 2 has no new RED commit

## Tests

/Users/g.evdokimov/.pyenv/versions/3.12.4/bin/python3 -B -m unittest -v test_labels → exit 0
> test_first_seen (test_labels.LabelTests.test_first_seen) ... ok
> test_uses_dict_fromkeys (test_labels.LabelTests.test_uses_dict_fromkeys) ... ok
> 
> ----------------------------------------------------------------------
> Ran 2 tests in 0.001s
> 
> OK

## Freeze

/Users/g.evdokimov/.pyenv/versions/3.12.4/bin/python3 /Users/g.evdokimov/.claude/skills/teamlead/scripts/red_freeze.py --repo /private/var/folders/lv/7tkpk3bd09jdc9j_0n97fy780000gq/T/teamlead-provenance-followup-k66kngy3/current/checkout b56ad06b5c1359aacbd4308ad21d54b085128904 → exit 0
> RED_FROZEN — 1 RED commit(s), 13 frozen lines, all present at HEAD

## Mutation

/Users/g.evdokimov/.pyenv/versions/3.12.4/bin/python3 /Users/g.evdokimov/.claude/skills/teamlead/scripts/mutate.py --repo /private/var/folders/lv/7tkpk3bd09jdc9j_0n97fy780000gq/T/teamlead-provenance-followup-k66kngy3/current/checkout --base 89678d9c83507c1ccd6250a96835ec8e0eda4ade --commits d6c0e281f2fe1c017ff908c0f9f4f1c6dad6086b --cmd '/Users/g.evdokimov/.pyenv/versions/3.12.4/bin/python3 -B -m unittest -v test_labels' --probes /private/var/folders/lv/7tkpk3bd09jdc9j_0n97fy780000gq/T/teamlead-provenance-followup-k66kngy3/current/probes-ws1-r2.json --max-generic 0 --out /private/var/folders/lv/7tkpk3bd09jdc9j_0n97fy780000gq/T/teamlead-provenance-followup-k66kngy3/current/mutation-ws1-r2.md → exit 0
> KILLED  labels.py:2  probe=added: dict.fromkeys call
> KILLED  labels.py:2  probe=added: first-seen order
> MUTATION: PASS killed=2 survived=0 invalid=0 unclassified=0 not_run=0 not_applied=0

## Observed probe failures

added: dict.fromkeys call
> test_first_seen (test_labels.LabelTests.test_first_seen) ... ok
> test_uses_dict_fromkeys (test_labels.LabelTests.test_uses_dict_fromkeys) ... FAIL
> 
> ======================================================================
> FAIL: test_uses_dict_fromkeys (test_labels.LabelTests.test_uses_dict_fromkeys)
> ----------------------------------------------------------------------
> Traceback (most recent call last):
>   File "/private/var/folders/lv/7tkpk3bd09jdc9j_0n97fy780000gq/T/teamlead-provenance-followup-k66kngy3/current/checkout/test_labels.py", line 11, in test_uses_dict_fromkeys
>     assert spy.call_count == 1
>            ^^^^^^^^^^^^^^^^^^^
> AssertionError
> 
> ----------------------------------------------------------------------
> Ran 2 tests in 0.001s
> 
> FAILED (failures=1)

added: first-seen order
> test_first_seen (test_labels.LabelTests.test_first_seen) ... FAIL
> test_uses_dict_fromkeys (test_labels.LabelTests.test_uses_dict_fromkeys) ... ok
> 
> ======================================================================
> FAIL: test_first_seen (test_labels.LabelTests.test_first_seen)
> ----------------------------------------------------------------------
> Traceback (most recent call last):
>   File "/private/var/folders/lv/7tkpk3bd09jdc9j_0n97fy780000gq/T/teamlead-provenance-followup-k66kngy3/current/checkout/test_labels.py", line 14, in test_first_seen
>     assert labels(['b', 'a', 'b']) == ['b', 'a']
>            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
> AssertionError
> 
> ----------------------------------------------------------------------
> Ran 2 tests in 0.004s
> 
> FAILED (failures=1)

The reviewer must match any RED_CHANGED lines to the prior finding.
This supplement does not change the original agent verdicts.

OUTCOME: PASS
