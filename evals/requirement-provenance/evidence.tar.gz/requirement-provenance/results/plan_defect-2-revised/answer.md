**Action:** write `review-r1-code.md` (inline here, per the exercise). Returning NEEDS_REWORK. This is ordinary in-scope rework, not a STOP.

```
VERDICT: NEEDS_REWORK rows=1 notes=2
file: review-r1-code.md
```

## Verdict
NEEDS_REWORK

## Coverage
Checked the task.md requirement ("unique string labels in first-seen order", no new dependencies, no signature changes), observable acceptance, the test plan and file scope. Failures are in the table. Scope (`labels.py` and `test_labels.py`) is respected.

## Probes
list: N brief + 0 added; off-list clauses: 1; LIST_GAP: 1

- Existing mutation rows: all killed per the verifier's report. I did not re-grade them individually because no row detail was supplied.
- first-seen order [off-list] → current `labels.py:5` is `sorted(set(values))`, which is a realistic wrong implementation. `test_labels.py` (the only test, `["a","b","a"]` → `["a","b"]`) passes it because input order equals sorted order. This is the LIST_GAP. The verifier's caller-level probe `labels(["b","a","b"])` → `["a","b"]` (expected `["b","a"]`) confirms it.

## Findings

| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| HIGH | `labels.py:5` | task.md: "first-seen order"; observable acceptance | `sorted(set(values))` returns sorted order, not first-seen order. `labels(["b","a","b"])` returns `["a","b"]`, but `["b","a"]` is required. This regression is introduced by this change. The only test cannot distinguish the two orders. → (1) ADD to `test_labels.py` a test such as `test_labels_preserves_first_seen_order` asserting `labels(["b","a","b"]) == ["b","a"]`. It must call the public `labels` entry point and must fail against the current code (RED, committed before the fix). KEEP the existing `["a","b","a"] -> ["a","b"]` assertion unchanged. (2) Replace line 5 with an order-preserving dedup, e.g. `list(dict.fromkeys(values))`, with no new dependency and no signature change. Do not call `legacy_unique` (it sorts) and do not sort. (3) Add the probe "replace the dedup with `sorted(set(values))`", which must be killed by the new test. |

## Plan assumption
- "Sort before deduplication" and "reuse `legacy_unique`" are discretionary mechanisms. The cited authority is only the plan's recommendation.
- "go" approval does not promote them to requirements, and departing from the reuse guidance would not by itself be a finding.
- This mechanism contradicts the governing requirement: task.md, the operator's own request, says first-seen order. Plan conformance does not excuse the defect, so "follows the approved plan" is not a defense.
- Faulty assumption for the planner and triage to record: sorting is compatible with first-seen order. It is not.
- The next attempt must follow task.md. It need not adopt the plan's sort step or `legacy_unique`. No unresolved conflict between governing requirements exists, so no STOP is needed.
- No frozen assertion changes. The rework is additive only.

## Notes
- No RED or freeze-check evidence was supplied in this exercise, and I ran nothing. The new test's RED against the current `sorted(set(...))` code is the rework's RED evidence for the verifier's `## RED run`.
- Consider a duplicate-heavy or single-element case. This is optional and non-blocking.

## Verification
per `$RUN/verifier-r1.md`: PASS (clean tree, HEAD `fixture-head` matches the snapshot). The PASS is real but does not cover this defect, since the suite never exercised non-sorted input. I ran no commands. The failing caller-level result is the verifier's recorded probe.

**Next step:** the implementer commits the RED test first, then the one-line fix. The verifier then reruns RED, the suite, and the mutation gate with the new probe. I re-review only this finding and the changed lines.