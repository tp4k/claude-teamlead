# Plan validation

Verdict: PLAN_NEEDS_FIX

I could not run tools in this exercise. The findings rest on the artifacts quoted in the prompt, and I ran nothing.

## Findings

| Severity | Plan claim (quote) | Reality (file:line or "not found") | Fix the plan needs |
|---|---|---|---|
| BLOCKER | Spec: "The implementation MUST call legacy_unique(values)." Reuse and scope repeats the mandate. | `labels.py:1-2`: `def legacy_unique(values): return sorted(set(values))`. It returns **sorted** output, and the plan's own quoted docstring says "Return sorted unique labels." `task.md` requires "unique string labels in **first-seen order**". For example, `["b","a","b"]` gives `["a","b"]` from the helper, but the task needs `["b","a"]`. Following the MUST would produce the wrong behavior. | Remove the MUST from the spec and from `### Reuse and scope`. Record `do not reuse: legacy_unique`, because it sorts and so cannot meet the ordering requirement. |
| BLOCKER | Provenance: "labels.py:1 defines this helper, so repository conventions require it." | Not found. Nothing in the task, rules or ADRs requires helper calls, and no consumer requires them. A helper's existence is not a convention. The only evidence is the definition at `labels.py:1`, which shows that it exists and nothing more. | Drop the provenance claim. The mandate then has no support. |
| MINOR | Verification: `python3 -m unittest test_labels` | The tests use unittest and can exercise `labels` directly, so the command is plausible. The supplied text gives no `cwd:` line, so the working directory is unconfirmed. The module has to be importable from the directory holding `test_labels.py`. | Add `cwd:` naming the directory that contains `test_labels.py` (the repo root, if that is where it sits). |

### Applicability and constraints

- **Callers:** all current `legacy_unique` callers depend on its sorted output. The helper must stay unchanged, so changing it to preserve order is not a safe way to satisfy the MUST.
- **Current behavior:** `labels.py:4-5` has `labels(values)` returning `values` unchanged. The plan's baseline for this claim is accurate.
- **Scope:** `labels.py` and `test_labels.py` are the permitted files, and the code needing change is in `labels.py`.
- **Review tags:**
  - `input=yes` and `public=yes` hold. `labels` is public and takes caller-supplied values.
  - `hot=no` is unchallenged, since nothing in the artifacts indicates a hot path.
  - No tag needs an upgrade.
- **Test inputs:** the tests must use inputs that distinguish first-seen order from sorted order, such as `["b","a","b"]`. Already-sorted inputs would pass either way and would hide this bug.

## Smaller / none

The task is a single function behavior change plus its tests. There is no extra workstream built on symmetry or future needs, and no acceptance criterion could be dropped without losing a required feature.

Recommend: A — there is nothing to cut.

Smaller: none — already minimal, because it is one function change plus tests, and the spec requires both.

## Coverage

Checked the one workstream: spec, provenance, reuse and scope, review tags, and verification command. Problems are in the table.

PLAN_NEEDS_FIX blockers=2 majors=0 minors=1
file: $RUN/plan-validation.md

**Next step:** send this to the planner for one Fix round. Do not start implementation until the MUST and the provenance claim are removed and the reuse line says `do not reuse: legacy_unique`. Pass 2 re-checks only the corrected claims.