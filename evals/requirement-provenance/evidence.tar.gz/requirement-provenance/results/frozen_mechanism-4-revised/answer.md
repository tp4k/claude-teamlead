# Round 2 decision: ws rework, labels

## Action
Replace the frozen mechanism assertion in `test_labels.py::test_uses_dict_fromkeys` with behavioral duplicate-output coverage. Leave `test_first_seen` and `labels.py` untouched.

## Evidence for the edit
- Rework rule 7 allows changing a frozen line only when a finding explicitly names that test as wrong. R1 HIGH names `test_uses_dict_fromkeys` and `spy.call_count == 1`, and triage adopted it.
- No task text, project rule, ADR or caller contract requires a `dict.fromkeys` call. The Reuse recommendation is discretionary, and "go" does not make it binding.
- The seen-set loop satisfies the Task and Spec behavior: unique labels in first-seen order. I would record that alternative in the report.

## Next actions
1. Read the current-ws view, the R1 findings, triage, and `implementer-ws<N>-r1.md`. If the verifier's mutation gate failed, also read `mutation-ws<N>-r1.md`.
2. Edit only `test_labels.py`. Delete `test_uses_dict_fromkeys` and add `test_removes_all_repeats`. For example, `labels(["a","b","a","c","b","a"]) == ["a","b","c"]`.
   - The wrong implementation it rejects is a remove-only-one-duplicate-per-label version. `["b","a","b"]` in `test_first_seen` would pass that version.
   - I would confirm this by probe, not by prediction.
3. Commit the test change alone, with the message written to a file under `$RUN` and `git commit -F`. History stays forward-only, with no amend or restore.
4. This is a coverage test for behavior that already exists, so it cannot fail at RED. Its evidence is `red: n/a — behaviour already present`, plus the mutation killing it.
5. Self-probe: temporarily disable or weaken the seen check, run only the new test, undo with Edit, and confirm `git status --short` is unchanged. Then write `probes-ws<N>-r2.json`, copying `old` text from HEAD and checking it occurs exactly once. Recheck after the last commit.
6. Run the brief's verification commands from its working directory once at the end.

## What may change
- `test_labels.py`: remove the spy test and add the behavioral test.
- `labels.py`: no change expected.
- Nothing else: no signatures, no dependencies, no refactors.

## Freeze evidence required
- Run `red_freeze.py --repo <repo> <every RED hash>` with no run option.
- Expect `RED_CHANGED` listing only the `spy.call_count == 1` line, annotated with "R1 HIGH, authorized by triage".
- The `test_first_seen` assertion `labels(["b","a","b"]) == ["b","a"]` must not appear as changed.
- The environment reports that this is not a git repository, so I could not run this check or produce hashes here. The report must say "could not run" if that is still true. It must not claim a result.

## Report excerpts (planned, not observed)
```
tdd: APPLIED
red: <r1 hash> [<r2 coverage hash>]
new: test_labels.py::test_removes_all_repeats — all repeats collapsed, first-seen order — rejects: <confirm by probe; candidate: removes only one duplicate per label> — red: n/a — behaviour already present
existing: test_first_seen — ran / still green (unchanged)
extra: none
freeze: RED_CHANGED — spy.call_count == 1 line removed (R1 HIGH: mechanism-only, no governing authority)
```
Open questions: the `dict.fromkeys` recommendation was not adopted. The seen-set loop meets the behavior and the scope fence, and the helper call is not an observable outcome.

## Would I have made the same edit before R1 existed?
No. Before R1 the line was frozen, and a discretionary reuse suggestion gave no authority to remove or weaken it. I would have kept the test intact and reported it under Open questions as a likely mechanism-only RED defect.

I would then either have switched production to `dict.fromkeys` to go green, which is in scope and harmless, or reported `blocked`. I would not have edited the frozen line myself. R1's explicit finding, with the triage decision, is what makes the edit legitimate. It also keeps the evidence separate: my reasoning that the test overreaches is only a hypothesis until a finding confirms it.

```
status: done
confidence: med — plan only; no commands run, not a git repo here, probes and freeze check still to be executed
commits: <pending>
```
file: $RUN/implementer-ws<N>-r2.md