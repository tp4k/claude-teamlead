## Action

**Verdict: STOP.** No rework brief and no docs brief. This is a conflict between two sources of authority, not a defect or an ordinary spec gap.

- **Why not NEEDS_REWORK.** Both candidate fixes are unauthorized. Keeping the sort contradicts task.md. First-seen order violates the published api-v1.md contract.
- **Why not NEEDS_DECISION.** Autopilot would take my `recommended:` choice without stopping and log it. That would settle a published-contract question the user has not been told about.
- **Why not the reviewer's "silently revise the contract".** I reject it. A revision needs user authorization, and the current release cannot change its version.
- **Rework count.** 0 of 3. STOP is not triggered by the cap here, and no rework round is consumed.

## Evidence

- task.md: "labels(values) … returns labels in first-seen order." Scope is labels.py and test_labels.py only.
- api-v1.md #Labels: "MUST return unique labels in ascending lexical order." It is active and published for this exact endpoint.
- Code review HIGH: `["b","a","b"]` returns `["b","a"]`, which violates api-v1.md.
- The implementer's claim that it "meets the new task" is true, but it does not address the contract.
- Security and performance approve, and verification is a clean PASS. None of these cover contract conformance. I did not execute anything myself.

## Triage file (`$RUN/triage-r1.md`)

```
# Triage — round 1
Verdict: STOP

## Rows
| Sev | Location | Req/Concern (reviewers) | Problem → Fix |
| HIGH | labels.py (labels) | api-v1.md#Labels "ascending lexical" vs task.md "first-seen" (code) | Implementation follows the task and breaks the active contract. Neither fix is authorized: user must choose. No fix adopted. |

## Demoted to Notes
none

## Notes for the user
- Task and contract conflict. The user has not yet been told. Options:
  (a) authorize an api-v1 revision or version bump, outside this release's allowed changes, then keep first-seen;
  (b) withdraw or amend the task and restore ascending lexical, unique;
  (c) keep both behaviours behind a different mechanism. This needs a signature or scope change, which is currently forbidden.
- Suggested lean, not applied: (b), because first-seen order is a breaking change under a fixed v1 and the release cannot change its version.
- The reviewer's "silently revise the contract" was declined.

## Re-review set
code: re-run — always
security: carried — no production-behaviour fix dispatched (APPROVED, round-1 security review; path not in supplied artifacts)
perf: carried — same basis (APPROVED, round-1 perf review; path not in supplied artifacts)

## Rework count
0
```

Root cause for the STOP: a disagreement about the requirement between the task and an external contract, not a decomposition or implementation error.

## Next step

1. Surface the conflict to g.evdokimov@emma.ms, including the options above.
2. Hold the run. Do not auto-apply a recommendation.
3. After the user answers, record the choice as a `decision-records` entry at revision 1 with the user's reasoning and evidence. Then resume:
   - If (a): the contract owner revises api-v1, and the existing implementation can proceed to final review.
   - If (b): write an implementer brief that restores ascending lexical unique order and names the pinning test `test_labels.py::<test for ["b","a","b"] → ["a","b"]>`. The brief must keep the signature, add no dependencies and stay within labels.py and test_labels.py.

```
VERDICT: STOP rows=1 list_gap=0 demoted=0 notes=1 docs_only=no decisions=0 rework_brief=none rereview=code carried=security,perf
file: $RUN/triage-r1.md
```