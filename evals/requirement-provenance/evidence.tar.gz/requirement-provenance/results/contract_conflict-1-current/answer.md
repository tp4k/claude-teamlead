**Action:** Triage the conflict as a spec call. Do not approve it, and do not silently revise the contract.

**Evidence**
- `task.md` asks for first-seen order. `api-v1.md#Labels` is an active published contract and says "MUST return unique labels in ascending lexical order." For `["b","a","b"]` the two give `["b","a"]` and `["a","b"]`. No implementation satisfies both.
- The code review HIGH is correct. The implementation returns `["b","a"]`, which violates the contract.
- The clean PASS only shows the code matches the task's tests. It says nothing about the contract. I have not run anything myself.
- Nobody authorized a contract revision, and the release cannot change the contract version. The user has not been told about the conflict. Shipping first-seen order would be an unauthorized breaking change to a public API. The reviewer's "silently revise the contract" is rejected for that reason.
- Autopilot lets the run take a recommendation without stopping, so I recommend the choice that does not break the published API. The choice is logged for the user to veto.

---

**`$RUN/triage-r1.md`**

Verdict: NEEDS_DECISION, routed as NEEDS_REWORK because the recommended choice needs a code change.

| Sev | Location | Req/Concern (reviewers) | Problem → Fix |
|---|---|---|---|
| HIGH | `labels.py::labels` | `api-v1.md#Labels` (code) vs `task.md` first-seen order | The code returns `["b","a"]` for `["b","a","b"]` and violates the contract. **recommended: keep ascending lexical order (the contract) — it avoids an unauthorized breaking change to a published API in a release that cannot bump the version, and it is reversible if the user chooses to revise the contract.** Behaviour that changes: `labels(values)` returns unique labels in ascending lexical order again. Pinning test: `test_labels.py::test_labels_unique_ascending` (new or changed) asserts `labels(["b","a","b"]) == ["a","b"]`. |

**Demoted to Notes:** none.

**Notes for the user (surface first):**
- `task.md` (first-seen order) conflicts with `api-v1.md#Labels` (ascending lexical order). You have not authorized a contract revision.
- Autopilot took the contract-preserving recommendation, so the requested behaviour is not delivered yet.
- To get first-seen order, authorize an `api-v1.md` revision and a version bump. Then the round needs a replan and a re-triage.
- Security and performance approved, and verification passed, but none of that covers the contract.

**Re-review set**
- code: re-run — always.
- security: carried — the fix is limited to ordering, with no parsing, validation or authorization change (APPROVED from the round-1 security review).
- perf: carried — the fix is not on a `hot path: yes` stream (APPROVED from the round-1 performance review).

**Rework count:** 1 of 3.

---

**`$RUN/briefs/impl-ws1-r2.md`**

# Implementer brief — WS-1 — round 2 (rework)

Inherited source: `$RUN/briefs/impl-ws1-r1.md` for scope, spec, forbiddens and verification commands. Read `$RUN/implementer-ws1-r1.md` for what the previous coder did.

## Findings to fix
- HIGH: `labels.py::labels` must follow `api-v1.md#Labels` and return unique labels in ascending lexical order. For example, `labels(["b","a","b"])` must return `["a","b"]`. Change only `labels.py` and `test_labels.py`, and leave the public signature and dependencies unchanged.
- Update any test that asserts first-seen order to assert the contract order. This is an authorized change and the reason is the contract, not a way to make the tests pass.
- Also check the empty and single-value paths.

## Verifier output
Omit. Verification passed in round 1.

## Test plan additions
Add `test_labels.py::test_labels_unique_ascending` asserting `["b","a","b"] → ["a","b"]`. Verify and state the final observed output.

rework cause: planning assumption. The task contradicts an active contract the planner did not reconcile. Evidence: `task.md` against `api-v1.md#Labels`.

## Report file
`$RUN/implementer-ws1-r2.md`

---

**Next step:** Dispatch the implementer with the rework brief above, then run the code review again. Show the user the conflict and the `decisions-log.md` entry first.

```
VERDICT: NEEDS_DECISION rows=1 list_gap=0 demoted=0 notes=4 docs_only=no decisions=1 rework_brief=$RUN/briefs/impl-ws1-r2.md rereview=code carried=security,perf
file: $RUN/triage-r1.md
```