def labels(values):
    return list(dict.fromkeys(values))
