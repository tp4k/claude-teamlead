import unittest
from labels import labels


class LabelTests(unittest.TestCase):
    def test_first_seen(self):
        assert labels(['b', 'a', 'b']) == ['b', 'a']

    def test_empty(self):
        assert labels([]) == []

    def test_all_duplicates(self):
        assert labels(['a', 'a', 'a']) == ['a']


if __name__ == '__main__':
    unittest.main()
