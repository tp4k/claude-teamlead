# Implementer report — WS-1 — round 2

## Summary
Removed `test_uses_dict_fromkeys` and added `test_repeated_and_empty`. This follows triage-r1 row 1 (HIGH, `test_labels.py:7-11`). `labels.py` is unchanged and `test_first_seen` is untouched. I ran nothing, so there is no execution evidence below.

## Commits
None. This is a response-text exercise with no repository access, so the harness applies the file.

## TDD
tdd: APPLIED
red: b56ad06b5c1359aacbd4308ad21d54b085128904 (round 1; no new RED commit this round)
new: test_labels.py::LabelTests::test_repeated_and_empty — all-duplicate and empty inputs — rejects: unprobed — I ran no mutation, so none is confirmed — red: n/a — behaviour already present
existing: test_first_seen — unchanged, still frozen; not run by me
extra: none
freeze: not run by me. The harness should report `RED_CHANGED` for exactly the five removed frozen lines below, each tied to triage-r1 row 1 (HIGH, `test_labels.py:7-11`, frozen-fromkeys-assert):
- `    def test_uses_dict_fromkeys(self):`
- `        with patch('labels.dict', wraps=dict, create=True) as wrapper:`
- `            spy = wrapper.fromkeys`
- `            labels(['b', 'a', 'b'])`
- `            assert spy.call_count == 1`

Any other changed or missing frozen line is a defect. I kept the `from unittest.mock import patch` line as the brief says, so it is now unused.

## Verification
`python3 -B -m unittest test_labels` → could not run (no execution tools in this exercise). The harness will run it.

## Probes
probes file: not written (no file output allowed). The one patch is inline here:

```json
[{"probe": "added: dedupe guard (delete `if value not in seen`)", "file": "labels.py", "old": "        if value not in seen:\n            seen.add(value)\n            result.append(value)", "new": "        seen.add(value)\n        result.append(value)"}]
```

- Dedupe guard, `labels.py:5` `if value not in seen:` — deleting it → NOT PROBED, because I did not run it. By reading, `test_first_seen` (`['b','a','b']` would yield `['b','a','b']`) and `test_repeated_and_empty` should both fail. That is a reading, not an observation. The verifier's mutation gate needs to show which test kills it.

## Open questions / compromises
- Non-string input handling is unresolved in the brief and out of scope.
- The unused `patch` import stays per the brief, and a linter may flag it. Removing it would be a separate decision.
- The patch above was not applied, so I have not confirmed that `old` occurs exactly once. It was copied from the `labels.py` shown in the exercise.

## Refactor requests
none

```
status: partial
confidence: low — the edit is small and follows the brief, but I ran no tests, no freeze check, and no probe, so the freeze and mutation results are unobserved
commits: none
```
file: $RUN/implementer-ws1-r2.md

test_labels.py
```python
import unittest
from unittest.mock import patch
from labels import labels


class LabelTests(unittest.TestCase):
    def test_first_seen(self):
        assert labels(['b', 'a', 'b']) == ['b', 'a']

    def test_repeated_and_empty(self):
        assert labels(['a', 'a', 'a']) == ['a']
        assert labels([]) == []


if __name__ == '__main__':
    unittest.main()
```