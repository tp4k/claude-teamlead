# Plan validation (report text; no file was written, no commands run)

Verdict: PLAN_NEEDS_FIX

## Findings

| Severity | Plan claim (quote) | Reality (file:line or "not found") | Fix the plan needs |
|---|---|---|---|
| BLOCKER | Spec: "The implementation MUST call legacy_unique(values)." Provenance: "labels.py:1 defines this helper, so repository conventions require it." | `labels.py:1-2`: `def legacy_unique(values): return sorted(set(values))`. The plan's own docstring quote is "Return sorted unique labels." task.md requires "unique string labels in first-seen order." Sorting does not preserve first-seen order: `["b","a","b"]` gives `["a","b"]`, not `["b","a"]`. Acceptance cannot be met by relying on the helper's output. The cited provenance is also unsupported. A helper's existence is not a convention, and no rule, ADR or consumer requires calling it. | Remove the MUST and the "repository conventions require it" provenance. If the helper is mentioned at all, mark it discretionary and note that its sorted semantics differ from the required ordering. |
| MAJOR | `### Reuse and scope` "repeats the MUST mandate" | Same evidence. The routing copy would push the false requirement into the implementer brief. The sorted-output reliance of existing `legacy_unique` callers is stated in the plan input and is not independently searched here. It does support keeping the helper itself unchanged. | Correct the reuse line to match the fix above. State `do not reuse: legacy_unique, because it sorts and callers depend on that`. Keep the helper's behavior and signature untouched. |

Checked and holding:
- **Existence:** `legacy_unique` at `labels.py:1-2` and `labels` at `labels.py:4-5` match the supplied excerpts. Current `labels` returns `values` unchanged, with no deduplication.
- **Scope:** `labels.py` and `test_labels.py` contain the code that needs changing.
- **Harness:** unittest can exercise `labels` directly, and `python3 -m unittest test_labels` is a plausible command. No brief `cwd:` line was supplied, so I could not check a verification directory.
- **Review tags:** `input=yes` and `public=yes` are consistent with `labels` being a public function. `hot=no` has no contradicting evidence in the supplied sources, so I am neither upgrading nor challenging it.
- **Requirement provenance:** the only mandate in the plan (`MUST call legacy_unique`) fails this check, as the BLOCKER row records. Nothing else in the supplied plan text claims a mandate.

## Smaller / none

The plan is a single change to `labels`, which is the minimum the task needs. No extra workstream or symmetry-driven stream is present to cut.

Smaller: none — already minimal because the task needs one function change and its tests in the two permitted files.

## Coverage

Validated the single workstream's spec, provenance, reuse and scope, review tags and verification command against the supplied excerpts. Problems are in the table above. No repository search was possible beyond those excerpts.

---

**Action:** the plan needs a fix before implementation, because the only mandate in it conflicts with the task and has no support behind it. This validation does not propose a replacement design.

**Evidence:** `labels.py:1-2` (sorted output), the plan's own docstring quote, and task.md's first-seen requirement. The "MUST" rests solely on the helper's existence, which establishes neither applicability nor a requirement.

**Next step:** one planner Fix round to drop the mandate and correct the reuse line. Pass 2 is needed only if that round adds new paths or symbols.

```
PLAN_NEEDS_FIX blockers=1 majors=1 minors=0
file: $RUN/plan-validation.md
```