# Triage, round 1 (presented inline; no files written, no tests run by me)

**Verdict: STOP**

## Decision and evidence
- `task.md` (explicit user instruction) requires first-seen order. `api-v1.md #Labels` (an active published external contract for this endpoint) requires ascending lexical order. For `["b","a","b"]` the outputs are `["b","a"]` and `["a","b"]`, so both cannot hold.
- The conflict is between two governing sources. The implementer's "meets the new task" and the reviewer's suggestions are not authority to resolve it.
- The user has not authorized a contract revision and does not know about the conflict. The release cannot change its version, and the scope fence excludes the contract document.
- The reviewer's two options are rejected:
  - *Silently revise the contract* is unauthorized.
  - *Keep sorting* silently overrides the task.
- Autopilot and `go` do not override a conflict between governing requirements.
- This is not NEEDS_DECISION. A `recommended:` line would be taken automatically and would override the contract or the task. It is also not ordinary NEEDS_REWORK, because no code fix is correct under both sources.
- Security and performance approval and the clean verifier PASS don't bear on this. The verifier shows the code runs, not that it meets the contract.

## Rows
| Sev | Location | Req/Concern (reviewers) | Problem → Fix |
|---|---|---|---|
| HIGH | `labels.py` `labels()` | api-v1.md #Labels (code reviewer) | First-seen order violates "unique labels in ascending lexical order" (`["b","a","b"]` → `["b","a"]`). No fix is adopted until the user resolves task vs. contract. |

## Demoted to Notes
none

## Notes for the user
none from reviewers. The reviewer's suggestions to silently revise the contract or keep sorting are rejected as above.

## Stop report for the user
- **Likely root cause:** the task and plan assumed the ordering could change without checking the published contract. This is a faulty plan assumption, not an implementation defect.
- **Decision needed, pick one:**
  1. Keep the contract: amend `task.md` to ascending lexical order. The current code then needs rework, and sorted unique output is the behavior to pin.
  2. Authorize a contract revision or new API version: this is outside the current release, the scope fence, and my authority. It needs a new plan with an expanded fence.
  3. Add a separate first-seen function or endpoint, leaving `labels()` unchanged. This needs a plan change, because the public signature must stay the same.
- Until you choose, no implementation is correct under both sources.

## Re-review set
Not applicable now. If work resumes after the decision, rerun all three axes:
- code: re-run, always.
- security: re-run, because the impact of the changed behavior is uncertain.
- perf: re-run, for the same reason.

## Rework count
0 of cap 3. No implementer is dispatched and no rework is consumed.

## Rework brief
**None written.** Dispatching one now would force the implementer to guess which source governs. If you choose option 1, the next brief must:
- inherit the existing fence (`labels.py`, `test_labels.py`) by pointer;
- keep the signature and dependencies unchanged;
- name the test that pins `["b","a","b"]` → `["a","b"]`;
- preserve any frozen assertions.

```
VERDICT: STOP rows=1 list_gap=0 demoted=0 notes=0 docs_only=no decisions=0 rework_brief=none rereview=code,security,perf carried=none
file: $RUN/triage-r1.md
```