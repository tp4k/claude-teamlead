# Plan validation

Verdict: PLAN_NEEDS_FIX

I treated this as pass 1, since the exercise gave no Fix log. I had no tools, so I checked only the artifacts quoted in the prompt. I ran no tests and did not read the repository. `plan-validation.md` is shown below rather than written to disk, as the exercise instructed.

## Findings

| Severity | Plan claim (quote) | Reality (file:line or "not found") | Fix the plan needs |
|---|---|---|---|
| BLOCKER | Spec and Reuse and scope: "The implementation MUST call `legacy_unique(values)`." | `labels.py:1-2`: `def legacy_unique(values): return sorted(set(values))`. The plan's own quoted docstring says "Return sorted unique labels." `task.md` requires unique labels in first-seen order. Sorting discards first-seen order, so for `["b","a","b"]` the helper returns `["a","b"]` where `["b","a"]` is required. The mandate cannot satisfy the acceptance criterion. The helper must also stay unchanged, because all current callers rely on its sorted output. | Remove the MUST mandate. Restate the reuse entry as `do not reuse: legacy_unique`, with the reason that it returns sorted output while the task needs first-seen order, and that its callers depend on sorting. |
| MINOR | Provenance: "labels.py:1 defines this helper, so repository conventions require it." | Not found. A helper's existence is not a convention. No rule, ADR or consumer requires helper calls. `labels.py:4-5` shows `labels(values)` currently returns `values` unchanged, with no helper call. | Drop the provenance claim, or cite a real rule. |

Checks that held:
- **Scope reachability:** `labels.py` and `test_labels.py` hold the code to change, and the plan's scope covers both.
- **Verification command:** `python3 -m unittest test_labels` matches the stated unittest harness, which can exercise `labels` directly. The prompt gave no `cwd:` line, so I could not check one.
- **Review tags:** `input=yes`, `hot=no` and `public=yes` all hold. `labels` is a public function and no spec or benchmark names a hot path. I made no downgrades.
- **Test inputs:** the plan's tests must use unsorted, duplicated input, such as `["b","a","b"]`. Sorted or already-ordered input cannot tell the wrong helper from correct behavior. This is a note on the plan's tests, not a finding.

## Smaller / none

The plan is already one function plus its tests, so no workstream or acceptance criterion can be dropped. The one "extra" element is the `legacy_unique` call, and the task contradicts it, so removing it is a factual correction rather than a scope cut.

Recommend: A — no cut exists to choose between.

Smaller: none — already minimal, since the change is confined to `labels()` and its tests, and the only removable item is the invalid helper mandate covered above.

## Coverage

I validated the single workstream's spec, provenance, reuse entry, verification command and review tags against the quoted `labels.py:1-5`.

## Next step

The planner makes one Fix round that removes the mandate and corrects the reuse entry. The remaining plan does not change.

```
PLAN_NEEDS_FIX blockers=1 majors=0 minors=1
file: $RUN/plan-validation.md
```