**Action:** Validation pass 1. I checked the plan's claims against the excerpts supplied in the task, with no tools and no test runs. The report below is inline and was not written to `$RUN/plan-validation.md`.

# Plan validation

Verdict: PLAN_NEEDS_FIX

## Findings

| Severity | Plan claim (quote) | Reality | Fix the plan needs |
|---|---|---|---|
| BLOCKER | "The implementation MUST call legacy_unique(values)." | `labels.py:1-2` is `def legacy_unique(values): return sorted(set(values))`, and the plan's own quoted docstring says "Return sorted unique labels." The task requires "unique string labels in first-seen order". Sorted output does not meet that order, so a mandatory call builds on a false premise. The existing callers rely on the sorted output and must stay unchanged, so the helper cannot be altered to fit. | Remove the MUST mandate from the Spec. Do not make helper use a requirement. |
| MAJOR | Provenance: "labels.py:1 defines this helper, so repository conventions require it." Reuse and scope repeats the MUST mandate. | The helper's existence is not a requirement. The task says nothing about helpers, and no rule or consumer requires calls to it. No project rules or ADRs exist. Reuse is also factually wrong: `legacy_unique` means sorted-unique, not first-seen-unique. | Delete the unsupported provenance. Correct `reuse:` / `do not reuse:` to state the helper's real meaning, which is sorted output relied on by existing callers. Correct every routing copy and brief that repeats the mandate. |

**Checked and holding:**
- **Review tags:** `input=yes`, `hot=no`, `public=yes` hold. `labels` is a public function, and nothing in the artifacts shows a hot path. I did not downgrade any tag.
- **Scope reachability:** `labels.py:4-5` is `def labels(values): return values`, so the code needing change is inside the permitted files.
- **Harness:** unittest can exercise `labels` directly. `python3 -m unittest test_labels` is a plausible command, but I saw no `cwd:` line or brief, so I could not check the working directory.
- **Test inputs:** a first-seen-order test needs inputs that differ from sorted order, or it cannot tell the wrong behavior from the right one. This is a factual feasibility note, not a design change.

## Smaller / none

The plan is one function plus its tests, and both files are explicitly in the task's scope. No cut exists that keeps a required feature.

Smaller: none — already minimal because the task requires exactly the `labels` behavior and its tests.

## Coverage

Validated the single workstream's Spec, provenance, Reuse and scope, review tags, and verification command, using only the supplied excerpts. Not checked: the briefs' `cwd:` lines, because none were provided.

PLAN_NEEDS_FIX blockers=1 majors=1 minors=0
file: not written (inline report only)

**Next step:** Fold both findings into the planner Fix round at step 6b, with no user question needed. Pass 2 runs only if that round returns `new_paths=yes`. Removing the mandate adds no new paths, so pass 2 is unlikely to be needed.