## Action
Planner Fix mode. Answer 1 ("go") is folded into Spec, Decisions taken, and the brief. Question 2 (case variants) stays open. No tests or commands were run. Paths come from the supplied artifacts and were not re-checked with `ls`.

## What "go" settles
- **Settled:** output order is first-seen, option a. Alphabetical is dropped.
- **Not settled:** `dict.fromkeys` is not binding. The operator approved the behavior, not the mechanism, so the mechanism stays discretionary in Reuse and scope.
- **Not settled:** case sensitivity. "go" did not address it.

## Spec (plan and brief, identical)
Source: `task.md`, verbatim task. "Return unique string labels in first-seen order. No new dependencies or public signature changes."

Binding, by authority:
- **First-seen order** is an explicit user instruction. It was reconfirmed by the operator's "go" on question 1 (a).
- **No new dependencies or public signature changes** is an explicit user instruction.
- **Edits only to `labels.py` and `test_labels.py`** is an explicit user instruction.

Unresolved assumption, not a requirement: case variants ("A" vs "a") count as distinct. This is exact-string equality, pending question 2.

## Reuse and scope
reuse: none found — no deduplication helper in `labels.py` or `test_labels.py` (per the supplied repo description).

Discretionary mechanism: `dict.fromkeys(values)` is recommended for concision, since dict preserves insertion order. An explicit seen-set loop is equally acceptable. Either must keep the existing return type of `labels()`. The implementer reads the current return type first and converts if needed, for example `list(...)`.

keep because: user's request (task.md).

## Decisions taken
1. Label order is first-seen, not alphabetical. Evidence: task.md wording, and operator "go" on question 1 (a).
2. Mechanism is left to the implementer; any approach meeting the behavior and scope fences is allowed. Evidence: both approaches satisfy first-seen for strings, and no helper or frozen test constrains the choice.
3. Case handling is provisional (exact equality) until question 2 is answered. It is carried as an assumption, not a decision.

## Brief excerpts (WS-1, round 1)
**Scope**
```scope
labels.py
test_labels.py
```

**Test plan**
- existing: current `test_labels.py` cases (contents not supplied). They are kept and must still pass.
- new: `test_labels.py::test_first_seen_order` — input `["b","a","b","c","a"]` gives `["b","a","c"]`. The input is chosen so sorted output `["a","b","c"]` fails.
- new: `test_labels.py::test_empty_input` — empty input gives empty output.
- Held out: no test pins case-variant behavior until question 2 is answered. The implementer must not add one.
- probe: later duplicate wins position — output follows last-seen order instead of first-seen.
- probe: output is sorted — alphabetical instead of first-seen.
- probe: empty input — raises or returns a non-empty result.

**Do not touch:** every file other than `labels.py` and `test_labels.py`. Also forbidden: new dependencies, signature changes, sorting, and case-folding or whitespace normalization unless question 2 is answered otherwise.

**Project forbiddens:** none supplied.

**Verification commands**

cwd: .
- `python3 -m unittest test_labels`

Python availability was not checked here. No `check:` line is needed for a Python-only task.

## Review axes
- attacker-controlled input: yes — the origin of `values` is unknown, so default to yes.
- hot path: no — nothing in the spec marks it as high-volume.
- public surface: yes — `labels()` is an exported function whose output behavior changes.

## Fix log
- answer 1: first-seen order → Spec and Decisions taken stated as fact. Mechanism is kept discretionary.
- answer 2: still pending → remains in `questions.md` (options: a) distinct, recommended; b) case-insensitive). Otherwise: b changes the dedupe key and adds a case test.

## Next step
The coordinator relays question 2.

PLAN_FIXED fixed=1 new_paths=no