Stage 1, reviewer, actual response:
## Review (code axis), round 1

**Verdict: NEEDS_REWORK**

**Coverage:** `labels.py` meets the behavioral spec: unique strings in first-seen order, same signature, no new dependencies, and only in-scope files. The failures are in the table below. I did not check `dict.fromkeys` conformance because the only authority for it is a recommendation.

### Probes
`list: 0 brief + 0 added; off-list clauses: 1; LIST_GAP: 0`

- First-seen dedupe guard, `if value not in seen` at `labels.py:5`: NOT PROBED. The verifier skipped mutation because the suite failed, and no mutation report or `probes-ws` file was supplied. By reading the tests, `test_labels::LabelTests::test_first_seen` would fail on three wrong implementations: no dedupe, `sorted(set(...))`, and last-seen order. That is a reading, not a probe result.

### Findings

| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| HIGH | `test_labels.py:8-11` (`test_uses_dict_fromkeys`, `assert spy.call_count == 1`) | Frozen RED asserts a discretionary mechanism | The test requires `dict.fromkeys`. The only authority for it is the brief's "recommended because concise". `task.md` requires unique first-seen labels, not a mechanism, and the `go` approval covered the behavioral plan. `labels.py` is a valid alternative within scope, and it fails the suite (verifier `.F`, exit 1). **Fix:** the next implementation attempt may change these frozen lines, paired with `RED_CHANGED` evidence citing this finding. Remove the `patch('labels.dict', …)` spy and the `call_count` assertion. Replace the test with behavioral assertions, such as `labels(['a','a','a']) == ['a']` and `labels([]) == []`. KEEP `test_first_seen` and its `== ['b','a']` assertion (line 14) unchanged. Do NOT change `labels.py` to satisfy the mechanism test. |
| MEDIUM | Verifier evidence (`tree:`, mutation) | Missing or mismatched evidence | The verifier recorded `tree:` as empty, not `CLEAN`, so a clean tree at `head: 89678d9c…` is not established. I cannot confirm that SHA against `git rev-parse HEAD` or `git status` in this exercise, and I did not invent a check. Mutation did not run, so there is no mutation report. **Fix:** request a fresh verification after rework with `tree: CLEAN`, the `head:` SHA, a passing suite, and a mutation report. The implementer must provide a probe patch that deletes the `if value not in seen` guard, and the report must show it killed by `test_first_seen`. |

### Notes
- Non-string input handling is unresolved in the brief. It is out of scope and not a defect.
- The RED run is valid: `test_first_seen` failed on behavior before implementation, not on import or syntax errors.
- `red_freeze.py` reported `RED_FROZEN` (13 lines). That is expected until the authorized change above, and then `RED_CHANGED` evidence must reference the HIGH finding.

### Verification
per verifier-r1: FAIL. `test_uses_dict_fromkeys` failed at `test_labels.py:11`. Freeze check: `RED_FROZEN`. I ran no commands myself.

### Next step
The implementer makes the test-only rework above and leaves `labels.py` as is. Then triage requests fresh verification: suite, clean tree, and mutation.

```
VERDICT: NEEDS_REWORK rows=2 notes=3
file: review-r1-code.md
```

Stage 2, triage, actual response:
## Triage: round 1 (`$RUN/triage-r1.md`)

**Verdict: NEEDS_REWORK.** Rework count after this round is 1 of 3. `docs_only=no`, because the fix changes a test.

### Rows
| Sev | Location | Req/Concern (code reviewer) | Problem → Fix |
|---|---|---|---|
| HIGH | `test_labels.py:7-11` (`test_uses_dict_fromkeys`, `assert spy.call_count == 1`) | The frozen RED test asserts a discretionary mechanism. | No governing authority requires `dict.fromkeys`. `task.md` requires unique labels in first-seen order. The brief only says "recommended because concise", and the `go` approval covered the behavioral plan. `labels.py` is a documented alternative that meets the behavior, and the suite fails only on the mechanism test (verifier exit 1, `.F`). **Fix:** remove that method and its `RED_CHANGED` lines. Add one behavioral test, `test_repeated_and_empty`, which asserts `labels(['a','a','a']) == ['a']` and `labels([]) == []`. **Behavior that changes:** the suite no longer rejects a correct non-`dict.fromkeys` implementation, so the existing `labels.py` is accepted. It is pinned by `test_labels.py::LabelTests::test_first_seen` (unchanged) and the new `test_repeated_and_empty`. |

The reviewer's MEDIUM row (empty `tree:`, mutation not run) is not a code defect. The mutation step was skipped because the suite failed. It becomes a verification requirement for round 2, listed in the Notes. It is not a finding.

### Demoted to Notes
none

### Notes for the user
- Handling of non-string inputs is unresolved in the brief and out of scope (strings only).
- `dict.fromkeys` stays a recommendation. Evidence: no authority beyond "recommended because concise". Round 2's verification must report `tree:` state and a mutation probe that deletes the `if value not in seen` guard, each as observed.
- The RED run was valid, and `red_freeze` reported `RED_FROZEN` (13 lines). The first-seen assertion at line 14 stays frozen.

### Re-review set
- code: re-run, always.
- security: no review in this round's inputs, so nothing to carry. The rework is test-only with no production change, so no re-run is needed.
- perf: same as security.

```decision-records
[{"id":"frozen-fromkeys-assert","revision":1,"action":"fix","reason":"Test asserts discretionary dict.fromkeys mechanism; no governing authority requires it","evidence":"task.md requires only unique first-seen labels; brief marks dict.fromkeys 'recommended because concise'; verifier: test_labels.py:11 assertion failed against a behaviorally correct labels.py"}]
```

## Rework brief (`$RUN/briefs/impl-ws1-r2.md`)

# Implementer brief — WS-1 — round 2 (rework)

Inherited source: `$RUN/briefs/impl-ws1-r1.md` (scope fence, project rules, verification commands). Read `$RUN/implementer-ws1-r1.md` for what the previous coder did. The active fence already allows `test_labels.py`, so no `## Scope` section is added.

## Spec
Authority: `task.md`, an explicit user instruction, applies to `labels(values)`. Return unique labels in first-seen order. The signature stays `labels(values)` and no new dependencies are allowed. Assumption: handling of non-string inputs is unresolved, and this work covers strings only. Adopted decision (triage r1): the suite must not require a specific mechanism, because no governing authority requires one.

## Reuse and scope
Reuse: `dict.fromkeys` is recommended because it is concise. It is discretionary, not mandatory, and the current `set` plus `list` implementation is an accepted alternative. The general `go` approved the behavioral plan, not the mechanism. Keep because `task.md` requires unique labels. Do not change `labels.py`.

## Findings to fix
1. HIGH, `test_labels.py:7-11`, `test_uses_dict_fromkeys` (`assert spy.call_count == 1`). Remove this method. It is the only frozen assertion you may change. The `unittest.mock` import line stays as is. Keep `test_first_seen` and its line-14 assertion unchanged, since it is the coverage to preserve. Behavior that changes: the suite accepts a correct implementation that does not use `dict.fromkeys`. It is pinned by `test_first_seen` and the new `test_repeated_and_empty`. In your report, give one `RED_CHANGED` line per removed frozen line, each citing this finding. Any other frozen-line change is a defect.

rework cause: planning assumption. The RED test froze a recommended mechanism. Evidence: the brief's "recommended because concise", and `test_labels.py:11` failing against behaviorally correct code.

## Verifier output
Read `$RUN/verifier-r1.md`. Failing command: `python3 -B -m unittest test_labels` exited 1, with the failure at `test_labels.py:11`.

## Test plan additions
`test_repeated_and_empty`: `labels(['a','a','a']) == ['a']` and `labels([]) == []`. Run the suite and state what you observe. Report a probe that deletes the `if value not in seen` guard and say which test kills it, as observed. Do not predict.

## Report file
`$RUN/implementer-ws1-r2.md`

```
VERDICT: NEEDS_REWORK rows=1 list_gap=0 demoted=0 notes=3 docs_only=no decisions=0 rework_brief=$RUN/briefs/impl-ws1-r2.md rereview=code carried=none
file: $RUN/triage-r1.md
```

Stage 3, implementer, actual response:
# Implementer report — WS-1 — round 2

## Summary
Removed `test_uses_dict_fromkeys` and added `test_repeated_and_empty`. This follows triage-r1 row 1 (HIGH, `test_labels.py:7-11`). `labels.py` is unchanged and `test_first_seen` is untouched. I ran nothing, so there is no execution evidence below.

## Commits
None. This is a response-text exercise with no repository access, so the harness applies the file.

## TDD
tdd: APPLIED
red: b56ad06b5c1359aacbd4308ad21d54b085128904 (round 1; no new RED commit this round)
new: test_labels.py::LabelTests::test_repeated_and_empty — all-duplicate and empty inputs — rejects: unprobed — I ran no mutation, so none is confirmed — red: n/a — behaviour already present
existing: test_first_seen — unchanged, still frozen; not run by me
extra: none
freeze: not run by me. The harness should report `RED_CHANGED` for exactly the five removed frozen lines below, each tied to triage-r1 row 1 (HIGH, `test_labels.py:7-11`, frozen-fromkeys-assert):
- `    def test_uses_dict_fromkeys(self):`
- `        with patch('labels.dict', wraps=dict, create=True) as wrapper:`
- `            spy = wrapper.fromkeys`
- `            labels(['b', 'a', 'b'])`
- `            assert spy.call_count == 1`

Any other changed or missing frozen line is a defect. I kept the `from unittest.mock import patch` line as the brief says, so it is now unused.

## Verification
`python3 -B -m unittest test_labels` → could not run (no execution tools in this exercise). The harness will run it.

## Probes
probes file: not written (no file output allowed). The one patch is inline here:

```json
[{"probe": "added: dedupe guard (delete `if value not in seen`)", "file": "labels.py", "old": "        if value not in seen:\n            seen.add(value)\n            result.append(value)", "new": "        seen.add(value)\n        result.append(value)"}]
```

- Dedupe guard, `labels.py:5` `if value not in seen:` — deleting it → NOT PROBED, because I did not run it. By reading, `test_first_seen` (`['b','a','b']` would yield `['b','a','b']`) and `test_repeated_and_empty` should both fail. That is a reading, not an observation. The verifier's mutation gate needs to show which test kills it.

## Open questions / compromises
- Non-string input handling is unresolved in the brief and out of scope.
- The unused `patch` import stays per the brief, and a linter may flag it. Removing it would be a separate decision.
- The patch above was not applied, so I have not confirmed that `old` occurs exactly once. It was copied from the `labels.py` shown in the exercise.

## Refactor requests
none

```
status: partial
confidence: low — the edit is small and follows the brief, but I ran no tests, no freeze check, and no probe, so the freeze and mutation results are unobserved
commits: none
```
file: $RUN/implementer-ws1-r2.md

test_labels.py
```python
import unittest
from unittest.mock import patch
from labels import labels


class LabelTests(unittest.TestCase):
    def test_first_seen(self):
        assert labels(['b', 'a', 'b']) == ['b', 'a']

    def test_repeated_and_empty(self):
        assert labels(['a', 'a', 'a']) == ['a']
        assert labels([]) == []


if __name__ == '__main__':
    unittest.main()
```

Stage 4, reviewer, actual response:
## Review (code axis), round 2 re-review

**Verdict: NEEDS_REWORK**

**Coverage:** I checked only the round-1 HIGH row and the lines changed by the rework. That row is resolved. One evidence gap remains (table below).

**Recovery of the HIGH row**
- The diff against `89678d9` touches only `test_labels.py`. `labels.py` is unchanged and the scope fence holds.
- `RED_CHANGED` lists 5 of 13 frozen lines. They are exactly the five lines of `test_uses_dict_fromkeys` that my round-1 HIGH finding authorized. The other 8 frozen lines are intact. The `RED_CHANGED` result is therefore authorized, and the implementer's report cites the finding for each line.
- I read the removed lines first. Only the mechanism assertion (`spy.call_count == 1`) and its patch scaffolding were removed. Behavioral coverage is preserved. `test_first_seen` is unchanged and still asserts `['b','a','b'] → ['b','a']`, the input the removed test used.
- Provenance is preserved. `dict.fromkeys` stays a recommendation with no test requiring it. Authority for the behavior remains `task.md`, and the `go` approval was not promoted to a mechanism requirement.
- The suite passes: `python3 -B -m unittest test_labels` exited 0, 2 tests OK.

### Probes
`list: 0 brief + 1 added (inline in implementer report, no probes file); off-list clauses: 1; LIST_GAP: 0`

- Dedupe guard (delete `if value not in seen`) → mutation at `labels.py:5` → NOT PROBED. The round-2 evidence has no mutation report, and the implementer wrote no `probes-ws1-r2.json`. By reading, the patch is on target and would fail `test_labels::LabelTests::test_first_seen` and `test_labels::LabelTests::test_repeated_and_empty`. That is a reading, not a probe result.

### Findings

| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| MEDIUM | verifier-r2 evidence (`tree:`, mutation); missing `$RUN/probes-ws1-r2.json` | Missing independent evidence | The suite now passes, so the mutation gate should have run. Triage-r1 required a guard-deletion probe and a stated tree state for round 2. The supplied evidence has no mutation report. `tree:` is again an empty string rather than `CLEAN`, and the recorded `head:` is `66449dd…`. I cannot compare it with `git rev-parse HEAD` because this exercise has no repository, and I ran no commands. Acceptance of `test_repeated_and_empty` as `red: n/a — behaviour already present` depends on a mutation failing that test, which is not shown. **Fix:** no change to `labels.py` or `test_labels.py`. (1) The implementer writes the guard-deletion patch from the inline JSON into `$RUN/probes-ws1-r2.json`, with `old` being the three lines inside the `for`. (2) Request fresh verification. It must record `tree: CLEAN` with `head:` matching shared HEAD, the passing suite, and a mutation report. That report must show the guard-deletion row killed, naming the killing `file::test_name`. KEEP everything else as is. |

### Notes
- The `from unittest.mock import patch` import is now unused. The brief said to keep it, so a linter may flag it. Removing it is a separate decision.
- Non-string input handling stays unresolved and out of scope.
- The implementer's `status: partial` and `confidence: low` come from running nothing. I relied on the harness evidence, not on that report.

### Verification
per `$RUN/verifier-r2.md`: PASS for the suite (exit 0). The mutation report and `tree: CLEAN` are missing, as the row above states. I ran no commands.

**Recovery status:** the code and test content is recovered and provenance is intact. Recovery is not complete until the fresh verification shows a killed probe and a clean tree. No other defects or constraint violations remain.

**Next step:** the implementer adds the probes file, triage requests re-verification, and I confirm the mutation row.

```
VERDICT: NEEDS_REWORK rows=1 notes=3
file: review-r2-code.md
```
(Intended path. This exercise is response-only, so nothing was written to disk.)