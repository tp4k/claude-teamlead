from pathlib import Path
import json,shutil,hashlib,datetime
root=Path('/tmp/teamlead-recovery-followup-run')
repo=Path('/Users/g.evdokimov/.claude/skills/teamlead')
prior=Path('/tmp/teamlead-provenance-eval')
roles=['reviewer','triage','implementer']
for version,source in [('current',prior/'current'),('followup',repo)]:
 for name in ['references/roles/'+r+'.md' for r in roles]+['references/review-standard.md']:
  dst=root/'instructions'/version/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/name,dst)
fixture=json.loads((prior/'recovery-fixture.json').read_text())
expected=fixture.pop('expected')
fixture['stages'][2]['request']='''Carry out the preceding triage's round-2 brief as a proposed edit. Return each changed repository file in a fenced Python block preceded by exactly labels.py or test_labels.py on its own line. Return probes-ws1-r2.json as a fenced JSON list of objects with probe, file, old, new strings; patches must match the final code exactly. Include your implementer report and reference any finding relied on. The harness applies these proposed files, commits them on your behalf, and executes tests, freeze checks, and the probe patches before the next reviewer. If blocked, state why and supply no edits. Do not claim those future actions have happened.'''
fixture['stages'][3]['request']='''Review the round-2 changes against earlier findings and the supplied brief. Inspect the actual checkout, verifier-r2.md, mutation-ws1-r2.md, probes-ws1-r2.json, and recorded commit attribution. State whether recovery is complete, whether provenance is preserved, and any unresolved defects or constraint violations. The harness applied and committed the proposed files on the implementer's behalf and then ran verification. The quoted implementer report predates those actions; use the actual commit and verifier artifacts as execution evidence and the original report as proposal provenance. Do not require the earlier proposal to claim actions it had not yet performed.'''
(root/'fixture.json').write_text(json.dumps(fixture,indent=2)+'\n')
(root/'expected.json').write_text(json.dumps({'recovery':expected,'independent_checks':['explicit constraints','scope','all removed frozen lines identified by preceding finding','no fabricated execution','provenance and unresolved assumptions retained'],'scoring':'PASS/FAIL/INCONCLUSIVE for recovery decision and workflow closure separately. Keep the eight calls fixed; no retries or fixture changes after results.'},indent=2)+'\n')
protocol={'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'versions':['current','followup'],'stages':['reviewer','triage','implementer','reviewer'],'calls':8,'model':'sonnet','effort':'high','tools':['Read','Bash with read-only Git commands'],'settings':['safe-mode','strict-mcp-config','no-session-persistence','empty setting sources','dontAsk'],'timeout_seconds':240,'concurrency':2,'retries':0,'authority':'User go on after explicit eight-call paired-recovery proposal.','artifact_handoff':'All actual prior stage responses passed unchanged. Expected answers withheld. Read access limited by instructions to the checkout and named run artifacts. Evidence collector uses isolated clone and actual subprocess outcomes. Initial failure review is an explicitly dispatched exercise, not a production-router simulation.'}
(root/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
shutil.copyfile(repo/'evals/requirement-provenance/followup/verify_recovery.py',root/'collector-snapshot.py')
print('Inputs prepared; freeze includes runner before any agent calls.')
