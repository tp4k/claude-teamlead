## Triage, round 1, WS-1

**Verdict: STOP.** No implementer rework brief is written.

**Action:** Two governing requirements conflict and I cannot reconcile them within scope. Autopilot and `go` do not authorize resolving this. The run halts for the user. The rework count stays 0 of 3, because a STOP dispatches nothing and consumes no rework.

### Conflict
| Source | Requirement | Authority |
|---|---|---|
| `task.md` | `labels(values)` returns labels in first-seen order. No signature change, no new dependencies. | Explicit user instruction |
| `api-v1.md#Labels` | `labels(values)` MUST return unique labels in ascending lexical order. | Active published external contract for this endpoint |

Evidence:
- For `["b","a","b"]` the implementation returns `["b","a"]`, which the contract forbids. Under the contract the result is `["a","b"]`.
- The implementer's claim that it "meets the new task" is true, but it doesn't resolve the conflict. Verification PASS and the security and performance approvals don't cover contract conformance.
- The release cannot change its version, so there is no sanctioned path to revise `api-v1`. The user has not authorized a contract revision and has not been told of this conflict.
- The task did not account for the contract. I record the cause as `rework cause: planning assumption`, with evidence from the two sources above.

### Reviewer suggestions: not adopted
- **"Silently revise the contract":** unauthorized, and it hides a breaking change from the user.
- **"Keep sorting":** this overrides the explicit task instruction, and the user hasn't chosen it.

Either choice would settle a conflict between governing sources by default, which STOP forbids. No row goes to Demoted to Notes: the finding is a genuine defect against a binding contract, not scope growth.

### Rows
| Sev | Location | Req/Concern (reviewers) | Problem → Fix |
|---|---|---|---|
| HIGH | `labels.py` `labels()` | api-v1.md#Labels (code) | First-seen order violates the MUST on ascending lexical order. Fix is blocked: it requires a user decision (see below). |

### Decision needed from the user
1. **Contract wins:** amend `task.md` so `labels()` keeps ascending lexical order. This is likely a no-op or a test-only change.
2. **Task wins:** explicitly authorize a revision of `api-v1`. This needs a versioning path, which the current release can't provide, so it is probably deferred.
3. **Other:** supply different instructions. Adding an opt-in parameter or a new public function is out of bounds here, because the signature must not change.

### Constraints preserved for any resumed run
- Edits only to `labels.py` and `test_labels.py`.
- No signature change and no new dependencies.
- No frozen assertions were described for this exercise, so none are touched.
- Nothing was executed by me. I rely only on the reported verifier PASS and the review findings.

### Re-review set if resumed
- code: re-run, always.
- security: carried (APPROVED from the round-1 review). Re-run if the decision changes production behavior on its axis.
- perf: carried (APPROVED from the round-1 review). Re-run if the fix touches a `hot path: yes` stream.

### Notes for the user
The user has not been told of this conflict, so it must be surfaced now. None of the review's own Notes were supplied.

### Rework count
0

```
VERDICT: STOP rows=1 list_gap=0 demoted=0 notes=0 docs_only=no decisions=0 rework_brief=none rereview=code carried=security,perf
file: $RUN/triage-r1.md
```