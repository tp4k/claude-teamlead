# Code review, round 1: `review-r1-code.md` (returned inline, no file written)

## Verdict
**NEEDS_REWORK**

## Coverage
Task.md's "unique labels in first-seen order" is not met (finding 1). The test plan does not cover order (finding 2). The scope, public-signature and no-new-dependency constraints show no defect in what was supplied.

## Probes
list: not supplied in the exercise; off-list clauses: 1; LIST_GAP: 1

- Verifier: all mutation rows killed, no list gaps. No row-level `file:line` or test citations were supplied, so I cannot match rows to tests. I record these as `NOT PROBED — row detail not provided`.
- First-seen ordering → no probe patch targets it → `[off-list]`. A realistic wrong implementation, `sorted(set(values))` at `labels.py:5`, passes every test because the only case is `["a","b","a"]`, where sorted and first-seen output coincide. This is a `LIST_GAP`.

## Findings

| Sev | Location | Req/Concern | Problem → Fix |
|---|---|---|---|
| HIGH | `labels.py:5` | task.md: unique labels in **first-seen order** | `sorted(set(values))` sorts the result. The verifier's caller-level probe shows `labels(["b","a","b"])` returns `["a","b"]`; the required output is `["b","a"]`. The change introduced this regression. The implementer followed the approved plan, but the plan's "sort before deduplication" contradicts the user's requirement. → Replace the body at `labels.py:5` with an order-preserving dedupe, e.g. `list(dict.fromkeys(values))`. This uses only the standard library. Keep the public signature unchanged. Do not call `legacy_unique`, which sorts. Do not edit `legacy_unique` either, because it is out of scope. |
| HIGH | `test_labels.py` (the existing `["a","b","a"]` test) | Observable acceptance / test plan | The sole test cannot distinguish sorted from first-seen output. `sorted(set(values))` passes it, so the suite PASS does not prove the requirement. → ADD a test, committed first and failing against the current code (RED), then GREEN after the fix: `assert labels(["b","a","b"]) == ["b","a"]`. Optionally add a three-element case such as `["c","a","c","b","a"] → ["c","a","b"]`. KEEP the existing `["a","b","a"] → ["a","b"]` assertion unchanged. No frozen assertion needs modification, so the diff should be additions only. Also ADD an order-clause probe patch to the probes file: remove or replace the order-preserving construct with `sorted(set(values))`. It must be killed by the new test. |

## Plan assumption and disposition
- **Plan:** the "sort before deduplication" recommendation is a faulty assumption. It conflicts with task.md, which is the authoritative request. Triage should correct the plan/spec so the order requirement stays and the sorting mechanism and `legacy_unique` reuse are dropped.
- **Operator "go":** it adopted the plan, but it does not promote a recommended mechanism to a requirement. No explicit user instruction, project rule or ADR requires sorting.
- **Why not STOP:** I see no conflict between governing requirements, only between a requirement and a discretionary recommendation. This is ordinary in-scope rework, limited to `labels.py` and `test_labels.py`.
- **Reuse:** departing from `legacy_unique` reuse is not itself a finding. The only defect is the observable ordering regression.

## Notes
- TDD evidence (RED hashes, `red_freeze.py` output, `## RED run`) was not supplied, so I made no TDD judgment. The rework must show the new test failing against `sorted(set(values))` in the verifier's `## RED run`.

## Verification
per `$RUN/verifier-r1.md`: PASS (clean tree, HEAD `fixture-head` matches snapshot). The PASS is contradicted on behavior by the verifier's own caller-level probe, which is the basis for finding 1. I ran nothing myself.

VERDICT: NEEDS_REWORK rows=2 notes=1
file: not written (inline exercise report; intended `review-r1-code.md`)