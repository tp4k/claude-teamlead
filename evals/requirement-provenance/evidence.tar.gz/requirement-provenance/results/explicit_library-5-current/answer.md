## Decision

**Implement `dict.fromkeys`.** The Spec quotes the task verbatim: "Use dict.fromkeys in labels(values); this mechanism is required by our instrumentation." The brief's `reuse:` line names the same symbol. The seen-set loop returns identical values and reads well, but that doesn't override a stated requirement. I implement the spec as written and don't substitute a reviewer-style or implementer-style preference.

**Alternative: declined, recorded, not escalated.** The spec is unambiguous and doesn't contradict existing code, so it needs no coordinator question. I'll note the seen-set suggestion under Open questions as declined, with the reason. If the instrumentation requirement turns out to be wrong, that is the coordinator's call, not mine.

## Proposed body (labels.py)

```python
def labels(values):
    return list(dict.fromkeys(values))
```

- The existing signature stays as is, with no new imports and no dependencies.
- `dict.fromkeys` keeps first-seen order and drops duplicates.
- Assumption to check against the file: the return type is `list`. The spec doesn't say, so I'll match whatever labels.py currently declares or returns.
- I add no filtering or coercion of non-strings, since the spec doesn't ask for it.

## TDD plan (test_labels.py only)

Nothing has been run, so there is no RED evidence yet. The steps are:
1. Check whether `test_labels.py` already covers the obligations. Add only the missing tests.
2. Write at most 2–3 behavioral tests:
   - `["b","a","b","c","a"]` → `["b","a","c"]`. It rejects `sorted(set(...))` and `list(set(...))`, because the first-seen order isn't alphabetical.
   - A duplicate-free input is returned unchanged and in order. It rejects an implementation that sorts or reorders.
   - An empty input returns `[]`.
3. Run only those tests and confirm a behavioral failure. If `labels` already behaves correctly, the tests pass immediately; I'd then report them as `existing:` or fix the inputs rather than claim RED.
4. Commit the tests alone, then rerun the same tests at that HEAD and keep the output as `red:` evidence.
5. Implement GREEN, run the full verification commands from the brief, and run `red_freeze.py` against the RED hash. I'll report `RED_FROZEN` only if the script prints it.

## Evidence limits to report

- Returned values can't tell `dict.fromkeys` from a seen-set loop. No behavioral test can enforce the "required by instrumentation" mechanism. I'll state this plainly and won't claim a test proves it. The mechanism is checkable only by diff review, and the report will say so.
- Probe patches (write to `probes-ws<N>-r<M>.json` only after actually running them):
  - Replace `list(dict.fromkeys(values))` with `sorted(set(values))`. This should be killed by the order test.
  - Replace it with `list(set(values))`. This is nondeterministic for strings, so I'd use a multi-element input and report the result as observed.
  - Replace it with `list(values)`. This should be killed by the duplicates test.
  - The mechanism-required clause gets `NOT PROBED — a mutation to a seen-set loop returns identical values, so no test can fail; the mechanism is verified by review of the diff`.
- No `rejects:` claim goes in the report without an observed probe result.

## Report skeleton

- `tdd: APPLIED`; `red:`, `new:` and `freeze:` are filled in only from real runs.
- Open questions: "Seen-set alternative declined — the spec mandates `dict.fromkeys`. Mechanism not test-enforceable."
- Refactor requests: none.

Because nothing has been executed in this exercise, the honest routing state is:

```
status: partial
confidence: low — decision and plan only; no tests written, RED, GREEN, verification, freeze check or probes were run
commits: none
```

file: $RUN/implementer-ws<N>-r1.md (not written; the exercise asked for the report in the response)