| file | line | op / probe | result |
|---|---|---|---|
| labels.py | 5 | added: delete the `if value not in seen` guard so duplicates are kept | KILLED |
| labels.py | 6 | added: never record a value as seen, so duplicates pass the guard | KILLED |
| labels.py | 8 | added: return labels sorted instead of in first-seen order | KILLED |

MUTATION: PASS killed=3 survived=0 invalid=0 unclassified=0 not_run=0 not_applied=0
