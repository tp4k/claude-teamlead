# Round 2 decision: replace the frozen mechanism assertion, not the behavior assertion

## Action

I would edit `test_labels.py::test_uses_dict_fromkeys`, specifically the `assert spy.call_count == 1` line. Nothing else frozen changes.

**Evidence:**
- Frozen lines may change only when a finding explicitly names the test as wrong. R1 HIGH does, and triage adopted it for this round.
- No task text, project rule, ADR or caller contract requires `dict.fromkeys`. The spec's behavior is "unique labels in first-seen order". The Reuse line is discretionary, and a general "go" doesn't make it binding.
- The seen-set loop already satisfies the spec. The spy assertion checks only that a helper ran.
- `test_first_seen` (`labels(["b","a","b"]) == ["b","a"]`) stays byte-for-byte unchanged, as R1 requires.

## Next steps (nothing below has been run)

1. Read the brief, the R1 review and triage, and the r1 report. Read `labels.py` and `test_labels.py` at HEAD.
2. Edit `test_labels.py` only:
   - Remove the spy and mock setup and the `call_count` assertion.
   - Remove any import that becomes unused because of this.
   - Add one behavioral duplicate-output test, for example `labels(["a","a","b","a","b"]) == ["a","b"]`.
   - The wrong implementations it rejects are no dedup, last-seen order and sorted order. I would confirm that by probing, not by prediction.
3. Leave `labels.py` untouched. The seen-set loop meets the behavior, and switching to `dict.fromkeys` is not needed. I would document the alternative in the report.
4. Make a separate commit written with `git commit -F <file under $RUN>`. This is a coverage commit, so its `red:` is `n/a — behaviour already present`. There is no new RED commit this round, and no new `red:` run is possible.
5. Run `red_freeze.py --repo <repo> <r1-red-hash>` with no run option and keep the output.
   - **Expected:** `RED_CHANGED`, listing only the removed spy-test lines. These are the `def` line, the spy setup and the `call_count` assertion.
   - **Required:** every listed line is mapped to the R1 HIGH row.
   - **Failure case:** any `test_first_seen` line in the output is a defect, and I would revert it.
6. Run the brief's verification commands from its stated working directory and record the real exit codes.
7. Probe the final tree and write `$RUN/probes-ws<N>-r2.json`. Copy each `old` from `labels.py` at HEAD and confirm it occurs exactly once.
   - **Probe patches:** delete the dedup guard, and make last-seen win.
   - **Check before `done`:** the new test fails on each probe.
   - **If a probe survives:** add a discriminating test and commit it separately.
8. Re-read the diff for false claims, such as comments that still mention `dict.fromkeys`. Confirm that test names match the runner output.

## Report excerpts (to be filled from real output)

```
## TDD
tdd: APPLIED
red: <r1-red-hash>
new: test_labels.py::<duplicate-output test> — repeated labels appear once, first-seen order — rejects: <probe result> — red: n/a — behaviour already present
existing: test_first_seen — ran / still green
extra: none
freeze: RED_CHANGED — <removed spy-test lines> — authorized by R1 HIGH (test_uses_dict_fromkeys / spy.call_count == 1 is a mechanism-only assertion with no governing authority); test_first_seen not listed

## Open questions / compromises
Brief's Reuse line recommends dict.fromkeys; kept the seen-set loop because it meets the spec and the recommendation is discretionary. The old call_count assertion contradicted the spec and was replaced per R1.
```

I'll write the final status block only after the evidence exists. Until then the status is `partial`, since I can't claim `done` without the verification, freeze and probe output.

## Would I have made this edit before R1 existed?

No. Without a finding naming the test as wrong, the frozen line stays. A discretionary Reuse suggestion doesn't authorize me to weaken my own RED test, because that would only show the test and the code agree.

In round 1, with the spy test failing as RED, I'd have made GREEN by using `dict.fromkeys` (in scope, behavior-preserving, and what the brief recommended). Alternatively I'd have raised an Open question that the test asserts a mechanism that nothing requires. I would not have edited the frozen assertion unilaterally.

R1's explicit finding is what makes the edit permissible now. The edit also stays minimal: the behavioral coverage is preserved and strengthened, not dropped.