## Action

I applied the operator's "go" to `plan.md` and the WS-1 brief. It settles the order decision only. It does not make `dict.fromkeys` binding, and the case-variant question stays open. Nothing was executed. I had no tools in this exercise, so paths come from the supplied artifacts, not from `ls`.

## What "go" settles

- **Settled:** the offered question was order, and "go" accepted recommended option a, first-seen order. This matches the verbatim task text, "first-seen order".
- **Not settled:** the mechanism. The plan recommended `dict.fromkeys` for concision, but nobody mandated it. A seen-set loop meets the task equally well, so the mechanism stays discretionary under Reuse.
- **Not settled:** case variants. That question was never offered, so "go" cannot answer it.

## Corrected plan.md / brief sections

### Spec
Source: `task.md` (verbatim task): "Return unique string labels in first-seen order. No new dependencies or public signature changes."

- **Binding (user instruction):** unique string labels, first-seen order, no new dependencies, no public signature changes. Only `labels.py` and `test_labels.py` may be edited.
- **Adopted behavioral decision:** order follows the input, not alphabetical. Source: the task text, plus the operator's "go" on question 1, option a.
- **Unresolved assumption (not a requirement):** case variants such as `"a"` and `"A"` are treated as distinct, pending question 2.
- **Unresolved assumption:** the return type is whatever `labels()` currently returns, presumably a list. The implementer must preserve it and must not return a bare dict.

### Reuse and scope
- reuse: none found. Searched `labels.py` and `test_labels.py`, and there is no existing deduplication helper. Recommended, not mandatory: `list(dict.fromkeys(values))`, because dict insertion order is preserved. A seen-set loop is an acceptable alternative that satisfies the behavior.
- do not reuse: `sorted(set(values))` as a dedupe shortcut, because it loses first-seen order.
- keep because: the user's request. It is the only stream, and it covers both files.

### Decisions taken
1. Label order is first-seen, not alphabetical. Evidence: `task.md` and operator "go" on question 1.
2. Mechanism left to the implementer. Evidence: the task constrains behavior, not mechanism, and "go" approved the behavior.
3. Case variants are provisionally distinct. This is not closed. See `questions.md` item 1.

### Test plan (brief excerpt)
- existing: none stated as relevant. The implementer should read `test_labels.py` and keep passing tests green. No assertions are frozen.
- new: `test_labels.py::test_first_seen_order_with_duplicates` — `["b","a","b","c","a"]` yields `["b","a","c"]`. This distinguishes alphabetical `["a","b","c"]` from last-seen `["b","c","a"]`.
- new: `test_labels.py::test_empty_input` — an empty input gives an empty result.
- new, assumption-dependent: `test_labels.py::test_case_variants_distinct` — `["a","A","a"]` yields `["a","A"]`. Mark it provisional until question 2 is answered.
- probe: first-seen order — the output is sorted alphabetically.
- probe: first-seen order — a duplicate moves the label to its last position.
- probe: uniqueness — a duplicate is kept.
- probe: case variants — the comparison case-folds, which collapses `"a"` and `"A"`.

### Review axes
- attacker-controlled input: yes — the origin of `values` is unknown, so I default to yes.
- hot path: no — nothing in the task or repo suggests one.
- public surface: yes — `labels()` is an exported function whose behavior changes, and I default to yes when uncertain.

### Brief scope block and verification
```scope
labels.py
test_labels.py
```
cwd: .
- `python -m unittest test_labels`

The `python` invocation is not confirmed with `which`. The brief also carries the Do-not-touch list (anti-scope: no dependencies, no signature changes, no other files). Project forbiddens: none apply.

## Fix log
- answer 1: first-seen order → Spec and Decisions updated. The mechanism stays non-binding.
- answer 2 (case variants): unanswered → assumption retained, labeled provisional.
- scope: none given.

## questions.md (remaining)
1. Do case variants (`"a"` vs `"A"`) count as distinct labels?
   options: a) distinct, case-sensitive; b) merge, case-insensitive
   recommended: a
   rests on: `task.md` says "unique string labels", and exact string equality is the default reading.
   otherwise: b changes WS-1 acceptance and replaces `test_case_variants_distinct`. It also requires choosing which spelling survives.

## Next step
Relay question 1 to the user. If it is answered, run another Fix round. If not, implementation can proceed under the labeled assumption.

```
PLAN_FIXED fixed=1 new_paths=no
```