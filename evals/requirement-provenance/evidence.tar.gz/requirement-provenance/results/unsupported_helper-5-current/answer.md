# Plan validation (pass 1, report text only; no file written and no commands run)

Verdict: PLAN_NEEDS_FIX

## Findings

| Severity | Plan claim (quote) | Reality (file:line or "not found") | Fix the plan needs |
|---|---|---|---|
| BLOCKER | "The implementation MUST call legacy_unique(values)." | `labels.py:1-2`: `def legacy_unique(values): return sorted(set(values))`. It returns **sorted** output, but task.md requires **first-seen order**. `["b","a","b"]` gives `["a","b"]`, not `["b","a"]`. The plan's own quoted docstring, "Return sorted unique labels.", confirms this. Calling it contradicts the task. | Remove the MUST. The spec should state the required behavior (unique, first-seen order) and not mandate a helper whose output order differs. |
| BLOCKER | Provenance: "labels.py:1 defines this helper, so repository conventions require it." | Not found. The helper does exist at `labels.py:1`, but a definition site is not a convention. No project rule, ADR, or consumer requires helper calls; the inputs list none. | Delete the provenance claim, or label it an unsupported inference. It cannot justify a MUST. |
| BLOCKER | `### Reuse and scope`: repeats the MUST mandate. | Reuse is factually wrong for this task. Callers of `legacy_unique` depend on its sorted output (`labels.py:1-2`) and must stay unchanged. Reusing it here would give the wrong order. Changing it would break those callers and is also out of scope. | Replace it with `do not reuse: legacy_unique` and give the reason (sorts, so it cannot give first-seen order; callers rely on that). Keep it untouched. |
| MAJOR | Acceptance and verification via `python3 -m unittest test_labels` | The harness is plausible: unittest is stated and `labels` is directly callable. The plan does not require inputs that tell sorted from first-seen order. Sorted or already-ordered inputs such as `["a","b","a"]` would pass the wrong behavior. | Require at least one test with non-alphabetical order and duplicates, for example `["b","a","b"]` expecting `["b","a"]`. The current `labels` (`labels.py:4-5`, `return values`) is an identity function, so duplicates must be asserted. |

The review tags `input=yes, hot=no, public=yes` hold. `labels` is a public function, and I found no benchmark or hot-path evidence. I upgraded nothing and downgraded nothing.

Checked and not challenged:
- Scope reachability: `labels.py` and `test_labels.py` contain the code that needs changing.
- No new dependencies or signature changes are implied.
- I could not verify the `cwd:` for the verification command from the supplied material. I did not run it and make no execution claim.

## Smaller / none

The plan appears to be a single workstream, and no `keep because:` claims on extra streams were given. The only mandate is the helper call, which is a factual error and not a scope cut.

Recommend: A. There is no cut to choose, so nothing needs a user decision.

Smaller: none. It is already minimal: one function and its tests, both required by task.md.

## Coverage

Checked the single workstream: spec, provenance, reuse, acceptance, tags, and scope. The problems are in the table.

## Evidence and next step

- **Action:** reject the "MUST call `legacy_unique`" premise. It conflicts with the stated task, and its justification is unsupported.
- **Applicability:** the finding applies to the spec, provenance, and reuse sections. They all rest on the same false premise.
- **Next step:** fold these rows into the single planner Fix round (step 6b). The plan then states the first-seen-order requirement without the helper mandate, keeps `legacy_unique` unchanged, and adds the discriminating test. Re-validate in pass 2 only if the Fix round reports `new_paths=yes`.

PLAN_NEEDS_FIX blockers=3 majors=1 minors=0
file: $RUN/plan-validation.md (not written in this exercise)