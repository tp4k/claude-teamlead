**Decision:** implement `dict.fromkeys`. Decline the seen-set loop.

**Why:** The Spec quotes the task verbatim: "Use dict.fromkeys in labels(values); this mechanism is required by our instrumentation." The brief's `reuse:` line names `dict.fromkeys`. The seen-set loop returns the same values, but it violates a stated requirement and I have no authority to reinterpret the spec. Readability does not outweigh a mechanism the spec marks as required. I treat the alternative as a hypothesis, and the spec already answers it. I will not reverse this without new evidence. If the instrumentation requirement is wrong, that is a question for the coordinator, not something to settle silently in code.

**Function body** (edit only `labels.py`; signature unchanged, no imports):

```python
def labels(values):
    return list(dict.fromkeys(values))
```

I have not seen `labels.py`. Before editing, I must check the existing signature, annotations and return type, and keep them as they are. If the current contract returns something other than `list`, I will adapt the wrapper and not change the signature. I add no string filtering, because the spec does not ask for it.

**TDD plan** (in `test_labels.py`, the only other file in the fence):
1. If `labels` does not exist, commit a scaffold first. It has the same signature and raises `NotImplementedError`.
2. Add 1–2 RED tests:
   - `labels(["b","a","b","c","a"]) == ["b","a","c"]`. It rejects `sorted(set(...))` and `list(set(...))`, which lose first-seen order.
   - `labels([]) == []`, only if the spec or existing tests do not already cover it. It rejects an implementation that mishandles empty input.
3. Confirm each test fails on behavior, not on an import error. Commit the tests alone, then run them once more at that RED commit and keep the output as the `red:` evidence.
4. Implement GREEN with the body above. Run `red_freeze.py` against the RED hash and require `RED_FROZEN`.

**Evidence limits to report:**
- A behavioral test cannot tell `dict.fromkeys` from the seen-set loop, because both give identical output. I will not claim the tests enforce the mechanism, and I will not add a test that asserts which helper ran.
- Mechanism compliance is checked by reading the diff and by the Spec quote, not by a mutation.
- Probe for the order criterion: replace `list(dict.fromkeys(values))` with `list(set(values))` and expect the order test to kill it. I have not run it.
- Probe for the mechanism: `NOT PROBED — a seen-set loop is behaviorally equivalent, so no test can reject it; the requirement is verified by inspection.`
- Probes file `probes-ws<N>-r1.json` would hold one patch: `old: return list(dict.fromkeys(values))`, `new: return list(set(values))`. I must check that `old` occurs exactly once at HEAD.

**Current state:** I have run no tests, made no commits, and written no files. This environment is not a git repository, so the commit, RED-freeze and `git status` steps cannot run here. Everything above is the plan and the decision, not observed results.

**Report skeleton for the coordinator:**

```
## Open questions / compromises
Seen-set alternative declined: the Spec requires dict.fromkeys. Tests cannot distinguish the two mechanisms; compliance rests on diff inspection.
Not a git repo here, so commits and red_freeze could not run.

status: partial
confidence: low — nothing executed; labels.py contract and existing tests unread; mutation and freeze checks pending
commits: none
```

file: $RUN/implementer-ws<N>-r1.md (not written in this exercise; contents are given above)