# Verifier — recovery evidence supplement

OUTCOME: PASS

## Snapshot

head: 66449ddba14dd643b6377a591db83fe3dfbcb5aa
tree: CLEAN

## Commit attribution

Original harness applied the agent's proposed file; this collector only verifies that existing commit in a clone.

commit 66449ddba14dd643b6377a591db83fe3dfbcb5aa
Author:     Evaluation <eval@example.test>
AuthorDate: Fri Oct 30 09:51:59 2026 +0400
Commit:     Evaluation <eval@example.test>
CommitDate: Fri Oct 30 09:51:59 2026 +0400

    Apply agent recovery

## RED run

none — round 2 has no new RED commit

## Tests

/Users/g.evdokimov/.pyenv/versions/3.12.4/bin/python3 -B -m unittest -v test_labels → exit 0
> test_first_seen (test_labels.LabelTests.test_first_seen) ... ok
> test_repeated_and_empty (test_labels.LabelTests.test_repeated_and_empty) ... ok
> 
> ----------------------------------------------------------------------
> Ran 2 tests in 0.000s
> 
> OK

## Freeze

/Users/g.evdokimov/.pyenv/versions/3.12.4/bin/python3 /Users/g.evdokimov/.claude/skills/teamlead/scripts/red_freeze.py --repo /private/var/folders/lv/7tkpk3bd09jdc9j_0n97fy780000gq/T/teamlead-provenance-followup-k66kngy3/revised/checkout b56ad06b5c1359aacbd4308ad21d54b085128904 → exit 1
> RED_CHANGED — 5 of 13 frozen lines missing at HEAD
> b56ad06b5 test_labels.py: def test_uses_dict_fromkeys(self):
> b56ad06b5 test_labels.py: with patch('labels.dict', wraps=dict, create=True) as wrapper:
> b56ad06b5 test_labels.py: spy = wrapper.fromkeys
> b56ad06b5 test_labels.py: labels(['b', 'a', 'b'])
> b56ad06b5 test_labels.py: assert spy.call_count == 1

## Mutation

/Users/g.evdokimov/.pyenv/versions/3.12.4/bin/python3 /Users/g.evdokimov/.claude/skills/teamlead/scripts/mutate.py --repo /private/var/folders/lv/7tkpk3bd09jdc9j_0n97fy780000gq/T/teamlead-provenance-followup-k66kngy3/revised/checkout --base 89678d9c83507c1ccd6250a96835ec8e0eda4ade --commits 66449ddba14dd643b6377a591db83fe3dfbcb5aa --cmd '/Users/g.evdokimov/.pyenv/versions/3.12.4/bin/python3 -B -m unittest -v test_labels' --probes /private/var/folders/lv/7tkpk3bd09jdc9j_0n97fy780000gq/T/teamlead-provenance-followup-k66kngy3/revised/probes-ws1-r2.json --max-generic 0 --out /private/var/folders/lv/7tkpk3bd09jdc9j_0n97fy780000gq/T/teamlead-provenance-followup-k66kngy3/revised/mutation-ws1-r2.md → exit 0
> KILLED  labels.py:5  probe=added: dedupe guard (delete `if value not in seen`)
> MUTATION: PASS killed=1 survived=0 invalid=0 unclassified=0 not_run=0 not_applied=0

## Observed probe failures

added: dedupe guard (delete `if value not in seen`)
> test_first_seen (test_labels.LabelTests.test_first_seen) ... FAIL
> test_repeated_and_empty (test_labels.LabelTests.test_repeated_and_empty) ... FAIL
> 
> ======================================================================
> FAIL: test_first_seen (test_labels.LabelTests.test_first_seen)
> ----------------------------------------------------------------------
> Traceback (most recent call last):
>   File "/private/var/folders/lv/7tkpk3bd09jdc9j_0n97fy780000gq/T/teamlead-provenance-followup-k66kngy3/revised/checkout/test_labels.py", line 8, in test_first_seen
>     assert labels(['b', 'a', 'b']) == ['b', 'a']
>            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
> AssertionError
> 
> ======================================================================
> FAIL: test_repeated_and_empty (test_labels.LabelTests.test_repeated_and_empty)
> ----------------------------------------------------------------------
> Traceback (most recent call last):
>   File "/private/var/folders/lv/7tkpk3bd09jdc9j_0n97fy780000gq/T/teamlead-provenance-followup-k66kngy3/revised/checkout/test_labels.py", line 11, in test_repeated_and_empty
>     assert labels(['a', 'a', 'a']) == ['a']
>            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
> AssertionError
> 
> ----------------------------------------------------------------------
> Ran 2 tests in 0.001s
> 
> FAILED (failures=2)

The reviewer must match any RED_CHANGED lines to the prior finding.
This supplement does not change the original agent verdicts.

OUTCOME: PASS
